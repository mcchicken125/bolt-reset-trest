/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Playfair Display"', 'serif'],
        body: ['Raleway', 'sans-serif'],
        primary: ['Raleway', 'sans-serif'],
      },
      colors: {
        barber: {
          primary: '#1a1a1a',
          secondary: '#1A3C1F',
          light: '#f5f5f5',
          dark: '#121212',
          accent: '#152f18',
        }
      },
    },
  },
  plugins: [],
};