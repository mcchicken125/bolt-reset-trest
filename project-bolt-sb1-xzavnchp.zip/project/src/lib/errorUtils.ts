// Enhanced error utilities with infinite loop prevention
export interface AppError extends Error {
  code?: string;
  status?: number;
  field?: string;
  timestamp?: string;
  userId?: string;
  context?: Record<string, any>;
  isLogged?: boolean; // Prevent duplicate logging
}

// Error codes for different types of errors
export const ERROR_CODES = {
  // Network errors
  NETWORK_ERROR: 'NETWORK_ERROR',
  TIMEOUT: 'TIMEOUT',
  OFFLINE: 'OFFLINE',
  
  // API errors
  API_ERROR: 'API_ERROR',
  UNAUTHORIZED: 'UNAUTHORIZED',
  FORBIDDEN: 'FORBIDDEN',
  NOT_FOUND: 'NOT_FOUND',
  SERVER_ERROR: 'SERVER_ERROR',
  
  // Form errors
  VALIDATION_ERROR: 'VALIDATION_ERROR',
  REQUIRED_FIELD: 'REQUIRED_FIELD',
  INVALID_EMAIL: 'INVALID_EMAIL',
  INVALID_PHONE: 'INVALID_PHONE',
  
  // Database errors
  DATABASE_ERROR: 'DATABASE_ERROR',
  RECORD_NOT_FOUND: 'RECORD_NOT_FOUND',
  DUPLICATE_ENTRY: 'DUPLICATE_ENTRY',
  
  // System errors
  CIRCUIT_BREAKER_OPEN: 'CIRCUIT_BREAKER_OPEN',
  RATE_LIMITED: 'RATE_LIMITED',
  
  // Generic errors
  UNKNOWN_ERROR: 'UNKNOWN_ERROR',
  CLIENT_ERROR: 'CLIENT_ERROR'
} as const;

// Create a custom error with additional context
export const createAppError = (
  message: string,
  code: string = ERROR_CODES.UNKNOWN_ERROR,
  status?: number,
  context?: Record<string, any>
): AppError => {
  const error = new Error(message) as AppError;
  error.code = code;
  error.status = status;
  error.timestamp = new Date().toISOString();
  error.context = context;
  error.isLogged = false;
  return error;
};

// Rate limiter to prevent spam operations
export class RateLimiter {
  private attempts = new Map<string, number[]>();
  
  isAllowed(key: string, maxAttempts: number = 5, windowMs: number = 60000): boolean {
    const now = Date.now();
    const windowStart = now - windowMs;
    
    // Clean old attempts
    if (this.attempts.has(key)) {
      const attempts = this.attempts.get(key)!.filter(time => time > windowStart);
      this.attempts.set(key, attempts);
    } else {
      this.attempts.set(key, []);
    }
    
    const attempts = this.attempts.get(key)!;
    
    if (attempts.length >= maxAttempts) {
      return false;
    }
    
    attempts.push(now);
    return true;
  }
  
  reset(key: string): void {
    this.attempts.delete(key);
  }
  
  clear(): void {
    this.attempts.clear();
  }
}

// Global rate limiter instance
export const globalRateLimiter = new RateLimiter();

// Network error handling with enhanced safeguards
export const withRetry = async <T>(
  fn: () => Promise<T>,
  maxRetries: number = 3,
  delay: number = 1000,
  backoffMultiplier: number = 2,
  shouldRetry?: (error: Error, attempt: number) => boolean
): Promise<T> => {
  let lastError: Error;
  
  // Prevent infinite retries
  const safeMaxRetries = Math.min(maxRetries, 10);
  
  for (let attempt = 0; attempt <= safeMaxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error as Error;
      
      // Check if we should retry this error
      if (shouldRetry && !shouldRetry(lastError, attempt)) {
        throw error;
      }
      
      // Don't retry on certain types of errors
      if (error instanceof Error) {
        const appError = error as AppError;
        if (appError.status && [400, 401, 403, 404, 422].includes(appError.status)) {
          throw error;
        }
        if (appError.code === ERROR_CODES.CIRCUIT_BREAKER_OPEN) {
          throw error;
        }
      }
      
      // If this was the last attempt, throw the error
      if (attempt === safeMaxRetries) {
        throw error;
      }
      
      // Wait before retrying with exponential backoff (capped at 30 seconds)
      const waitTime = Math.min(delay * Math.pow(backoffMultiplier, attempt), 30000);
      await new Promise(resolve => setTimeout(resolve, waitTime));
    }
  }
  
  throw lastError!;
};

// Timeout wrapper for promises with better error handling
export const withTimeout = <T>(
  promise: Promise<T>,
  timeoutMs: number = 30000,
  timeoutMessage: string = 'Request timed out'
): Promise<T> => {
  // Cap timeout to prevent indefinite waits
  const safeTimeout = Math.min(timeoutMs, 60000);
  
  return Promise.race([
    promise,
    new Promise<never>((_, reject) => {
      setTimeout(() => {
        reject(createAppError(timeoutMessage, ERROR_CODES.TIMEOUT, 408));
      }, safeTimeout);
    })
  ]);
};

// Enhanced error logger with circular reference protection
export class ErrorLogger {
  private static instance: ErrorLogger;
  private errors: AppError[] = [];
  private maxErrors = 100; // Prevent memory leaks
  private isLogging = false; // Prevent recursive logging

  static getInstance(): ErrorLogger {
    if (!ErrorLogger.instance) {
      ErrorLogger.instance = new ErrorLogger();
    }
    return ErrorLogger.instance;
  }

  log(error: Error | AppError, context?: Record<string, any>) {
    // Prevent recursive logging
    if (this.isLogging) {
      return;
    }
    
    try {
      this.isLogging = true;
      
      const appError = this.normalizeError(error, context);
      
      // Check if already logged to prevent duplicates
      if (appError.isLogged) {
        return;
      }
      
      appError.isLogged = true;
      this.errors.push(appError);
      
      // Prevent memory leaks by limiting stored errors
      if (this.errors.length > this.maxErrors) {
        this.errors = this.errors.slice(-this.maxErrors);
      }
      
      // Log to console in development (with circular reference protection)
      if (process.env.NODE_ENV === 'development') {
        console.error('Error logged:', this.serializeError(appError));
      }
      
      // Send to error tracking service (with safety checks)
      this.sendToErrorService(appError);
    } catch (loggingError) {
      // Prevent infinite loops in error logging
      console.error('Failed to log error:', loggingError);
    } finally {
      this.isLogging = false;
    }
  }

  private normalizeError(error: Error | AppError, context?: Record<string, any>): AppError {
    if (this.isAppError(error)) {
      return {
        ...error,
        context: { ...error.context, ...context }
      };
    }
    
    return createAppError(
      error.message,
      ERROR_CODES.UNKNOWN_ERROR,
      undefined,
      context
    );
  }

  private isAppError(error: Error): error is AppError {
    return 'code' in error;
  }

  private serializeError(error: AppError): any {
    // Safe serialization to prevent circular references
    try {
      return {
        message: error.message,
        code: error.code,
        status: error.status,
        timestamp: error.timestamp,
        context: this.safeStringify(error.context)
      };
    } catch {
      return {
        message: error.message,
        code: error.code,
        status: error.status,
        timestamp: error.timestamp
      };
    }
  }

  private safeStringify(obj: any): any {
    try {
      return JSON.parse(JSON.stringify(obj));
    } catch {
      return '[Circular Reference]';
    }
  }

  private async sendToErrorService(error: AppError) {
    try {
      // Rate limit error sending to prevent spam
      if (!globalRateLimiter.isAllowed('error-logging', 10, 60000)) {
        return;
      }
      
      // Store in session storage with safety checks
      const stored = sessionStorage.getItem('error_log');
      const errorLog = stored ? JSON.parse(stored) : [];
      
      errorLog.push({
        ...this.serializeError(error),
        stack: error.stack,
        timestamp: new Date().toISOString()
      });
      
      // Keep only last 50 errors to prevent storage bloat
      if (errorLog.length > 50) {
        errorLog.splice(0, errorLog.length - 50);
      }
      
      sessionStorage.setItem('error_log', JSON.stringify(errorLog));
    } catch (loggingError) {
      // Silently fail to prevent infinite loops
      console.warn('Failed to store error log:', loggingError);
    }
  }

  getErrors(): AppError[] {
    return [...this.errors];
  }

  clearErrors(): void {
    this.errors = [];
    try {
      sessionStorage.removeItem('error_log');
    } catch {
      // Silently fail
    }
  }
}

// Form validation utilities with safeguards
export const validateEmail = (email: string): string | null => {
  if (!email) return 'Email is required';
  
  // Prevent extremely long emails that could cause issues
  if (email.length > 254) return 'Email address is too long';
  
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return 'Please enter a valid email address';
  }
  return null;
};

export const validatePhone = (phone: string): string | null => {
  if (!phone) return null; // Phone is usually optional
  
  // Prevent extremely long phone numbers
  if (phone.length > 20) return 'Phone number is too long';
  
  if (!/^[\d\s\-\+\(\)]{10,}$/.test(phone.replace(/\s/g, ''))) {
    return 'Please enter a valid phone number';
  }
  return null;
};

export const validateRequired = (value: string, fieldName: string): string | null => {
  if (!value || !value.trim()) {
    return `${fieldName} is required`;
  }
  return null;
};

export const validateMinLength = (value: string, minLength: number, fieldName: string): string | null => {
  if (value && value.length < minLength) {
    return `${fieldName} must be at least ${minLength} characters long`;
  }
  return null;
};

export const validateMaxLength = (value: string, maxLength: number, fieldName: string): string | null => {
  if (value && value.length > maxLength) {
    return `${fieldName} must be no more than ${maxLength} characters long`;
  }
  return null;
};

// Enhanced sanitization utilities
export const sanitizeInput = (input: string): string => {
  if (!input || typeof input !== 'string') return '';
  
  return input
    .trim()
    .substring(0, 10000) // Prevent extremely long inputs
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '') // Remove script tags
    .replace(/[<>]/g, ''); // Remove angle brackets
};

export const sanitizeEmail = (email: string): string => {
  if (!email || typeof email !== 'string') return '';
  return email.trim().toLowerCase().substring(0, 254);
};

export const sanitizePhone = (phone: string): string => {
  if (!phone || typeof phone !== 'string') return '';
  return phone.replace(/[^\d\s\-\+\(\)]/g, '').substring(0, 20);
};