import { createClient } from '@supabase/supabase-js';
import { createAppError, ERROR_CODES, withRetry, withTimeout, ErrorLogger, globalRateLimiter } from './errorUtils';
import { circuitBreakers } from './circuitBreaker';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Enhanced validation with better error messages
function validateSupabaseConfig() {
  if (!supabaseUrl) {
    throw new Error('VITE_SUPABASE_URL is not defined. Please check your .env file and ensure it contains your Supabase project URL.');
  }
  
  if (!supabaseAnonKey) {
    throw new Error('VITE_SUPABASE_ANON_KEY is not defined. Please check your .env file and ensure it contains your Supabase anon key.');
  }

  // Check if values are still placeholders
  if (supabaseUrl.includes('your_supabase_url_here') || supabaseUrl === 'your_supabase_url_here') {
    throw new Error('VITE_SUPABASE_URL contains placeholder value. Please replace it with your actual Supabase project URL from your Supabase dashboard.');
  }

  if (supabaseAnonKey.includes('your_supabase_anon_key_here') || supabaseAnonKey === 'your_supabase_anon_key_here') {
    throw new Error('VITE_SUPABASE_ANON_KEY contains placeholder value. Please replace it with your actual Supabase anon key from your Supabase dashboard.');
  }

  // Basic URL format validation
  try {
    new URL(supabaseUrl);
  } catch {
    throw new Error(`VITE_SUPABASE_URL "${supabaseUrl}" is not a valid URL. Please check your Supabase project URL.`);
  }

  if (!supabaseUrl.includes('supabase.co') && !supabaseUrl.includes('localhost')) {
    console.warn('Supabase URL does not appear to be a standard Supabase URL. Please verify it is correct.');
  }
}

// Validate configuration on import with error handling
try {
  validateSupabaseConfig();
} catch (error) {
  console.error('Supabase configuration error:', error);
  // Create a mock client to prevent app crashes
  const mockClient = {
    from: () => ({
      insert: () => ({ select: () => ({ single: () => Promise.reject(error) }) }),
      select: () => ({ order: () => ({ eq: () => Promise.reject(error) }) }),
      update: () => ({ eq: () => ({ select: () => ({ single: () => Promise.reject(error) }) }) })
    })
  };
  throw error; // Still throw to prevent silent failures
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Enhanced types with error handling
export interface ContactMessage {
  id?: string;
  full_name: string;
  email: string;
  phone?: string;
  message: string;
  status?: 'pending' | 'responded' | 'resolved';
  ip_address?: string;
  user_agent?: string;
  created_at?: string;
  updated_at?: string;
}

export interface ContactFormData {
  fullName: string;
  email: string;
  phone?: string;
  message: string;
}

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  code?: string;
  message?: string;
}

// Enhanced database operations with comprehensive error handling
class SupabaseService {
  private errorLogger = ErrorLogger.getInstance();
  private healthCheckAttempts = 0;
  private maxHealthCheckAttempts = 5;
  private lastHealthCheck = 0;
  private healthCheckCooldown = 30000; // 30 seconds between health checks

  // Helper method to handle Supabase errors
  private handleError(error: any, operation: string): never {
    let appError;
    
    // Handle network/fetch errors specifically
    if (error?.name === 'TypeError' && error?.message?.includes('fetch')) {
      appError = createAppError(
        'Network connection failed. Please check your internet connection and Supabase configuration.',
        ERROR_CODES.NETWORK_ERROR,
        503,
        { 
          operation, 
          originalError: this.sanitizeError(error),
          supabaseUrl: supabaseUrl.substring(0, 30) + '...'
        }
      );
    } else if (error?.code) {
      switch (error.code) {
        case 'PGRST116':
          appError = createAppError(
            'Record not found',
            ERROR_CODES.RECORD_NOT_FOUND,
            404,
            { operation, originalError: this.sanitizeError(error) }
          );
          break;
        case '23505':
          appError = createAppError(
            'Duplicate entry',
            ERROR_CODES.DUPLICATE_ENTRY,
            409,
            { operation, originalError: this.sanitizeError(error) }
          );
          break;
        case 'PGRST301':
          appError = createAppError(
            'Unauthorized access. Please check your Supabase API key and RLS policies.',
            ERROR_CODES.UNAUTHORIZED,
            401,
            { operation, originalError: this.sanitizeError(error) }
          );
          break;
        default:
          appError = createAppError(
            error.message || 'Database operation failed',
            ERROR_CODES.DATABASE_ERROR,
            500,
            { operation, originalError: this.sanitizeError(error) }
          );
      }
    } else {
      appError = createAppError(
        error.message || 'Unknown database error',
        ERROR_CODES.DATABASE_ERROR,
        500,
        { operation, originalError: this.sanitizeError(error) }
      );
    }
    
    this.errorLogger.log(appError);
    throw appError;
  }

  // Sanitize error objects to prevent circular references
  private sanitizeError(error: any): any {
    try {
      return {
        message: error.message,
        code: error.code,
        status: error.status,
        name: error.name
      };
    } catch {
      return { message: 'Error details unavailable' };
    }
  }

  // Insert contact message with enhanced error handling and circuit breaker
  async insertContactMessage(data: Omit<ContactMessage, 'id' | 'created_at' | 'updated_at'>): Promise<ContactMessage> {
    // Rate limiting check
    if (!globalRateLimiter.isAllowed('contact-message', 3, 300000)) { // 3 messages per 5 minutes
      throw createAppError(
        'Too many messages sent recently. Please wait before sending another.',
        ERROR_CODES.RATE_LIMITED,
        429
      );
    }

    const operation = async () => {
      const { data: result, error } = await supabase
        .from('contact_messages')
        .insert([data])
        .select()
        .single();

      if (error) {
        this.handleError(error, 'insertContactMessage');
      }

      return result as ContactMessage;
    };

    try {
      return await circuitBreakers.database.execute(() =>
        withTimeout(
          withRetry(operation, 2, 1000), // Reduced retries to prevent long waits
          8000, // Reduced timeout
          'Contact message submission timed out'
        )
      );
    } catch (error) {
      if (error instanceof Error && (error as any).code) {
        throw error;
      }
      throw createAppError(
        'Failed to submit contact message',
        ERROR_CODES.API_ERROR,
        500,
        { originalError: this.sanitizeError(error) }
      );
    }
  }

  // Get contact messages with error handling and circuit breaker
  async getContactMessages(status?: string): Promise<ContactMessage[]> {
    const operation = async () => {
      let query = supabase
        .from('contact_messages')
        .select('*')
        .order('created_at', { ascending: false });

      if (status) {
        query = query.eq('status', status);
      }

      const { data, error } = await query;

      if (error) {
        this.handleError(error, 'getContactMessages');
      }

      return data as ContactMessage[];
    };

    try {
      return await circuitBreakers.database.execute(() =>
        withTimeout(
          withRetry(operation, 2, 1000),
          10000,
          'Failed to load contact messages'
        )
      );
    } catch (error) {
      if (error instanceof Error && (error as any).code) {
        throw error;
      }
      throw createAppError(
        'Failed to fetch contact messages',
        ERROR_CODES.API_ERROR,
        500,
        { originalError: this.sanitizeError(error) }
      );
    }
  }

  // Update message status with error handling and circuit breaker
  async updateMessageStatus(messageId: string, status: string): Promise<ContactMessage> {
    const operation = async () => {
      const { data, error } = await supabase
        .from('contact_messages')
        .update({ status })
        .eq('id', messageId)
        .select()
        .single();

      if (error) {
        this.handleError(error, 'updateMessageStatus');
      }

      return data as ContactMessage;
    };

    try {
      return await circuitBreakers.database.execute(() =>
        withTimeout(
          withRetry(operation, 2, 1000),
          8000,
          'Message status update timed out'
        )
      );
    } catch (error) {
      if (error instanceof Error && (error as any).code) {
        throw error;
      }
      throw createAppError(
        'Failed to update message status',
        ERROR_CODES.API_ERROR,
        500,
        { originalError: this.sanitizeError(error) }
      );
    }
  }

  // Enhanced health check with circuit breaker and cooldown
  async healthCheck(): Promise<boolean> {
    const now = Date.now();
    
    // Implement cooldown to prevent spamming health checks
    if (now - this.lastHealthCheck < this.healthCheckCooldown) {
      return circuitBreakers.database.getState() === 'CLOSED';
    }
    
    this.lastHealthCheck = now;

    // Check circuit breaker state first
    if (circuitBreakers.database.getState() === 'OPEN') {
      return false;
    }

    try {
      const result = await circuitBreakers.database.execute(async () => {
        const { error } = await Promise.race([
          supabase
            .from('contact_messages')
            .select('id')
            .limit(1),
          new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Health check timeout')), 3000)
          )
        ]) as any;

        if (error && error.code !== 'PGRST116') {
          throw new Error(`Health check failed: ${error.message}`);
        }

        return true;
      });

      this.healthCheckAttempts = 0; // Reset on success
      return result;
    } catch (error) {
      this.healthCheckAttempts++;
      
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      
      // Only log as critical error if we've exceeded max attempts
      if (this.healthCheckAttempts >= this.maxHealthCheckAttempts) {
        this.errorLogger.log(
          createAppError(
            `Database health check failed after ${this.maxHealthCheckAttempts} attempts`,
            ERROR_CODES.DATABASE_ERROR,
            503,
            { 
              error: errorMessage,
              attempts: this.healthCheckAttempts,
              circuitBreakerState: circuitBreakers.database.getState()
            }
          )
        );
      }
      
      return false;
    }
  }

  // Get circuit breaker states for debugging
  getCircuitBreakerStates() {
    return {
      database: circuitBreakers.database.getState(),
      network: circuitBreakers.network.getState(),
      api: circuitBreakers.api.getState()
    };
  }

  // Reset circuit breakers (for admin use)
  resetCircuitBreakers() {
    Object.values(circuitBreakers).forEach(cb => cb.reset());
    this.healthCheckAttempts = 0;
  }
}

export const supabaseService = new SupabaseService();

// Enhanced connection monitoring with safeguards against infinite loops
export class SupabaseConnectionMonitor {
  private static instance: SupabaseConnectionMonitor;
  private isConnected = true;
  private listeners: ((connected: boolean) => void)[] = [];
  private monitoringStarted = false;
  private checkInterval: number | null = null;
  private consecutiveFailures = 0;
  private maxConsecutiveFailures = 10; // Stop monitoring after too many failures
  private isDestroyed = false;

  static getInstance(): SupabaseConnectionMonitor {
    if (!SupabaseConnectionMonitor.instance) {
      SupabaseConnectionMonitor.instance = new SupabaseConnectionMonitor();
    }
    return SupabaseConnectionMonitor.instance;
  }

  startMonitoring() {
    if (this.monitoringStarted || this.isDestroyed) {
      return;
    }

    this.monitoringStarted = true;

    // Initial check with delay to allow app to initialize
    setTimeout(() => {
      if (!this.isDestroyed) {
        this.checkConnection();
      }
    }, 3000); // Increased initial delay

    // Check connection every 60 seconds (reduced frequency)
    this.checkInterval = window.setInterval(() => {
      if (this.isDestroyed) {
        this.stopMonitoring();
        return;
      }

      // Stop monitoring if too many consecutive failures
      if (this.consecutiveFailures >= this.maxConsecutiveFailures) {
        console.warn('Too many consecutive connection failures. Stopping connection monitoring.');
        this.stopMonitoring();
        return;
      }

      this.checkConnection();
    }, 60000); // Increased interval to reduce load
  }

  stopMonitoring() {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
    }
    this.monitoringStarted = false;
  }

  destroy() {
    this.stopMonitoring();
    this.listeners = [];
    this.isDestroyed = true;
  }

  private async checkConnection() {
    if (this.isDestroyed) {
      return;
    }

    try {
      const wasConnected = this.isConnected;
      
      // Use rate limiter to prevent spam
      if (!globalRateLimiter.isAllowed('health-check', 5, 60000)) {
        return; // Skip this check
      }

      this.isConnected = await supabaseService.healthCheck();
      
      if (this.isConnected) {
        this.consecutiveFailures = 0;
      } else {
        this.consecutiveFailures++;
      }
      
      if (wasConnected !== this.isConnected) {
        this.notifyListeners();
      }
    } catch (error) {
      this.consecutiveFailures++;
      
      if (this.isConnected) {
        this.isConnected = false;
        this.notifyListeners();
      }
    }
  }

  private notifyListeners() {
    if (this.isDestroyed) {
      return;
    }

    // Create a copy of listeners to prevent issues if list is modified during iteration
    const currentListeners = [...this.listeners];
    
    currentListeners.forEach(listener => {
      try {
        listener(this.isConnected);
      } catch (error) {
        console.warn('Error notifying connection listener:', error);
      }
    });
  }

  onConnectionChange(listener: (connected: boolean) => void) {
    if (this.isDestroyed) {
      return () => {}; // Return no-op function
    }

    // Prevent duplicate listeners
    if (this.listeners.includes(listener)) {
      return () => {};
    }

    this.listeners.push(listener);
    
    // Return unsubscribe function
    return () => {
      const index = this.listeners.indexOf(listener);
      if (index > -1) {
        this.listeners.splice(index, 1);
      }
    };
  }

  getConnectionStatus(): boolean {
    return this.isConnected;
  }

  getMonitoringStats() {
    return {
      isMonitoring: this.monitoringStarted,
      consecutiveFailures: this.consecutiveFailures,
      listenerCount: this.listeners.length,
      isDestroyed: this.isDestroyed
    };
  }
}

// Clean up connection monitor when page unloads
if (typeof window !== 'undefined') {
  window.addEventListener('beforeunload', () => {
    SupabaseConnectionMonitor.getInstance().destroy();
  });
}