import { supabaseService, ContactFormData, ContactMessage, ApiResponse } from './enhancedSupabase';
import { 
  validateEmail, 
  validatePhone, 
  validateRequired, 
  validateMinLength,
  validateMaxLength,
  sanitizeInput, 
  sanitizeEmail, 
  sanitizePhone,
  createAppError,
  ERROR_CODES,
  ErrorLogger
} from './errorUtils';

interface FormValidationResult {
  isValid: boolean;
  errors: Array<{ field: string; message: string }>;
}

export class ContactFormService {
  private errorLogger = ErrorLogger.getInstance();

  // Comprehensive form validation
  private validateForm(data: ContactFormData): FormValidationResult {
    const errors: Array<{ field: string; message: string }> = [];

    // Validate full name
    const nameError = validateRequired(data.fullName, 'Full name');
    if (nameError) {
      errors.push({ field: 'fullName', message: nameError });
    } else {
      const lengthError = validateMinLength(data.fullName, 2, 'Full name') ||
                         validateMaxLength(data.fullName, 100, 'Full name');
      if (lengthError) {
        errors.push({ field: 'fullName', message: lengthError });
      }
    }

    // Validate email
    const emailError = validateEmail(data.email);
    if (emailError) {
      errors.push({ field: 'email', message: emailError });
    }

    // Validate phone (optional)
    if (data.phone) {
      const phoneError = validatePhone(data.phone);
      if (phoneError) {
        errors.push({ field: 'phone', message: phoneError });
      }
    }

    // Validate message
    const messageError = validateRequired(data.message, 'Message');
    if (messageError) {
      errors.push({ field: 'message', message: messageError });
    } else {
      const lengthError = validateMinLength(data.message, 10, 'Message') ||
                         validateMaxLength(data.message, 2000, 'Message');
      if (lengthError) {
        errors.push({ field: 'message', message: lengthError });
      }
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  // Sanitize form data
  private sanitizeFormData(data: ContactFormData): ContactFormData {
    return {
      fullName: sanitizeInput(data.fullName),
      email: sanitizeEmail(data.email),
      phone: data.phone ? sanitizePhone(data.phone) : undefined,
      message: sanitizeInput(data.message)
    };
  }

  // Get client information safely
  private getClientInfo(): { ip: string; userAgent: string } {
    try {
      return {
        ip: 'client-ip', // In production, get from server
        userAgent: navigator.userAgent || 'unknown'
      };
    } catch (error) {
      return {
        ip: 'unknown',
        userAgent: 'unknown'
      };
    }
  }

  // Rate limiting check (simple client-side implementation)
  private checkRateLimit(): boolean {
    try {
      const lastSubmission = localStorage.getItem('lastMessageSubmission');
      if (lastSubmission) {
        const timeDiff = Date.now() - parseInt(lastSubmission);
        if (timeDiff < 60000) { // 1 minute cooldown
          return false;
        }
      }
      return true;
    } catch (error) {
      // If localStorage is not available, allow submission
      return true;
    }
  }

  // Update rate limiting
  private updateRateLimit(): void {
    try {
      localStorage.setItem('lastMessageSubmission', Date.now().toString());
    } catch (error) {
      // Silently fail if localStorage is not available
    }
  }

  // Main submission method
  async submitMessage(formData: ContactFormData): Promise<ApiResponse<ContactMessage>> {
    try {
      // Check rate limiting
      if (!this.checkRateLimit()) {
        throw createAppError(
          'Please wait at least 1 minute between message submissions',
          ERROR_CODES.VALIDATION_ERROR,
          429
        );
      }

      // Sanitize input data
      const sanitizedData = this.sanitizeFormData(formData);

      // Validate form data
      const validation = this.validateForm(sanitizedData);
      if (!validation.isValid) {
        throw createAppError(
          'Please correct the form errors',
          ERROR_CODES.VALIDATION_ERROR,
          400,
          { errors: validation.errors }
        );
      }

      // Get client information
      const clientInfo = this.getClientInfo();

      // Prepare data for database
      const messageData: Omit<ContactMessage, 'id' | 'created_at' | 'updated_at'> = {
        full_name: sanitizedData.fullName,
        email: sanitizedData.email,
        phone: sanitizedData.phone || null,
        message: sanitizedData.message,
        status: 'pending',
        ip_address: clientInfo.ip,
        user_agent: clientInfo.userAgent
      };

      // Submit to database
      const result = await supabaseService.insertContactMessage(messageData);

      // Update rate limiting
      this.updateRateLimit();

      return {
        success: true,
        data: result,
        message: 'Message sent successfully! We\'ll get back to you within 24 hours.'
      };

    } catch (error) {
      const appError = error as any;
      
      // Log error
      this.errorLogger.log(appError, { 
        operation: 'submitMessage',
        formData: { ...formData, message: '[REDACTED]' } // Don't log full message for privacy
      });

      // Return user-friendly error response
      return {
        success: false,
        error: appError.message || 'Failed to send message',
        code: appError.code || ERROR_CODES.UNKNOWN_ERROR,
        message: this.getUserFriendlyErrorMessage(appError)
      };
    }
  }

  // Convert technical errors to user-friendly messages
  private getUserFriendlyErrorMessage(error: any): string {
    switch (error.code) {
      case ERROR_CODES.VALIDATION_ERROR:
        return 'Please check your form and correct any errors.';
      case ERROR_CODES.NETWORK_ERROR:
      case ERROR_CODES.TIMEOUT:
        return 'Network error. Please check your connection and try again.';
      case ERROR_CODES.DATABASE_ERROR:
        return 'We\'re experiencing technical difficulties. Please try again later or call us directly.';
      case ERROR_CODES.DUPLICATE_ENTRY:
        return 'You\'ve already sent a message recently. Please wait before sending another.';
      default:
        return 'Something went wrong. Please try again or contact us directly at (843) 789-4430.';
    }
  }

  // Get form validation errors in a structured format
  async validateFormOnly(formData: ContactFormData): Promise<FormValidationResult> {
    const sanitizedData = this.sanitizeFormData(formData);
    return this.validateForm(sanitizedData);
  }
}

// Export singleton instance
export const contactFormService = new ContactFormService();

// Legacy function for backward compatibility
export const Send_message = (formData: ContactFormData) => {
  return contactFormService.submitMessage(formData);
};

// Additional utility functions
export const getContactMessages = async (status?: string) => {
  try {
    const messages = await supabaseService.getContactMessages(status);
    return { success: true, data: messages };
  } catch (error) {
    const appError = error as any;
    return {
      success: false,
      error: appError.message || 'Failed to fetch messages',
      code: appError.code || ERROR_CODES.UNKNOWN_ERROR
    };
  }
};

export const updateMessageStatus = async (messageId: string, status: string) => {
  try {
    const result = await supabaseService.updateMessageStatus(messageId, status);
    return { success: true, data: result };
  } catch (error) {
    const appError = error as any;
    return {
      success: false,
      error: appError.message || 'Failed to update message status',
      code: appError.code || ERROR_CODES.UNKNOWN_ERROR
    };
  }
};