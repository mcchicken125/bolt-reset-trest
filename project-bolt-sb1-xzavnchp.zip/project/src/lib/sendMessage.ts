import { supabase, ContactMessage, ContactFormData } from './supabase';

interface SendMessageResponse {
  success: boolean;
  message: string;
  data?: ContactMessage;
  error?: string;
}

// Helper function to get client IP (basic implementation)
const getClientIP = (): string => {
  // In a real application, you'd get this from your server
  // For now, we'll use a placeholder
  return 'client-ip';
};

// Helper function to get user agent
const getUserAgent = (): string => {
  return navigator.userAgent || 'unknown';
};

// Validate email format
const isValidEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

// Validate form data
const validateFormData = (data: ContactFormData): string[] => {
  const errors: string[] = [];

  if (!data.fullName?.trim()) {
    errors.push('Full name is required');
  }

  if (!data.email?.trim()) {
    errors.push('Email address is required');
  } else if (!isValidEmail(data.email)) {
    errors.push('Please enter a valid email address');
  }

  if (!data.message?.trim()) {
    errors.push('Message is required');
  }

  if (data.phone && data.phone.trim()) {
    const phoneRegex = /^[\d\s\-\+\(\)]{10,}$/;
    if (!phoneRegex.test(data.phone.replace(/\s/g, ''))) {
      errors.push('Please enter a valid phone number');
    }
  }

  return errors;
};

// Sanitize input data
const sanitizeFormData = (data: ContactFormData): ContactFormData => {
  return {
    fullName: data.fullName?.trim() || '',
    email: data.email?.trim().toLowerCase() || '',
    phone: data.phone?.trim() || undefined,
    message: data.message?.trim() || ''
  };
};

/**
 * Send message function - Main function to handle contact form submissions
 * @param formData - The contact form data
 * @returns Promise with success/error response
 */
export const Send_message = async (formData: ContactFormData): Promise<SendMessageResponse> => {
  try {
    // Sanitize input data
    const sanitizedData = sanitizeFormData(formData);

    // Validate form data
    const validationErrors = validateFormData(sanitizedData);
    if (validationErrors.length > 0) {
      return {
        success: false,
        message: 'Validation failed',
        error: validationErrors.join(', ')
      };
    }

    // Prepare data for database
    const messageData: Omit<ContactMessage, 'id' | 'created_at' | 'updated_at'> = {
      full_name: sanitizedData.fullName,
      email: sanitizedData.email,
      phone: sanitizedData.phone || null,
      message: sanitizedData.message,
      status: 'pending',
      ip_address: getClientIP(),
      user_agent: getUserAgent()
    };

    // Insert into Supabase
    const { data, error } = await supabase
      .from('contact_messages')
      .insert([messageData])
      .select()
      .single();

    if (error) {
      console.error('Supabase error:', error);
      return {
        success: false,
        message: 'Failed to send message',
        error: error.message
      };
    }

    // Success response
    return {
      success: true,
      message: 'Message sent successfully! We\'ll get back to you within 24 hours.',
      data: data as ContactMessage
    };

  } catch (error) {
    console.error('Send_message error:', error);
    return {
      success: false,
      message: 'An unexpected error occurred',
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
};

/**
 * Get all contact messages (for admin use)
 * @param status - Optional filter by status
 * @returns Promise with messages array
 */
export const getContactMessages = async (status?: 'pending' | 'responded' | 'resolved') => {
  try {
    let query = supabase
      .from('contact_messages')
      .select('*')
      .order('created_at', { ascending: false });

    if (status) {
      query = query.eq('status', status);
    }

    const { data, error } = await query;

    if (error) {
      throw new Error(error.message);
    }

    return {
      success: true,
      data: data as ContactMessage[]
    };
  } catch (error) {
    console.error('Error fetching messages:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
};

/**
 * Update message status (for admin use)
 * @param messageId - The message ID
 * @param status - New status
 * @returns Promise with success/error response
 */
export const updateMessageStatus = async (
  messageId: string, 
  status: 'pending' | 'responded' | 'resolved'
) => {
  try {
    const { data, error } = await supabase
      .from('contact_messages')
      .update({ status })
      .eq('id', messageId)
      .select()
      .single();

    if (error) {
      throw new Error(error.message);
    }

    return {
      success: true,
      data: data as ContactMessage
    };
  } catch (error) {
    console.error('Error updating message status:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
};