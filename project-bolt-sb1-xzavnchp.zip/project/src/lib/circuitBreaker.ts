// Circuit breaker pattern to prevent infinite retries and cascading failures
export class CircuitBreaker {
  private failures = 0;
  private nextAttempt = Date.now();
  private state: 'CLOSED' | 'OPEN' | 'HALF_OPEN' = 'CLOSED';

  constructor(
    private readonly maxFailures = 5,
    private readonly timeout = 60000, // 1 minute
    private readonly resetTimeout = 300000 // 5 minutes
  ) {}

  async execute<T>(operation: () => Promise<T>): Promise<T> {
    if (this.state === 'OPEN') {
      if (Date.now() < this.nextAttempt) {
        throw new Error('Circuit breaker is OPEN - operation blocked');
      }
      this.state = 'HALF_OPEN';
    }

    try {
      const result = await Promise.race([
        operation(),
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error('Operation timeout')), this.timeout)
        )
      ]);

      this.onSuccess();
      return result;
    } catch (error) {
      this.onFailure();
      throw error;
    }
  }

  private onSuccess() {
    this.failures = 0;
    this.state = 'CLOSED';
  }

  private onFailure() {
    this.failures++;
    if (this.failures >= this.maxFailures) {
      this.state = 'OPEN';
      this.nextAttempt = Date.now() + this.resetTimeout;
    }
  }

  getState() {
    return this.state;
  }

  reset() {
    this.failures = 0;
    this.state = 'CLOSED';
    this.nextAttempt = Date.now();
  }
}

// Global circuit breakers for different operations
export const circuitBreakers = {
  database: new CircuitBreaker(3, 10000, 300000), // 3 failures, 10s timeout, 5min reset
  network: new CircuitBreaker(5, 5000, 60000),    // 5 failures, 5s timeout, 1min reset
  api: new CircuitBreaker(4, 15000, 180000)       // 4 failures, 15s timeout, 3min reset
};