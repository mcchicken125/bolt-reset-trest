import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw, Home } from 'lucide-react';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
  onError?: (error: Error, errorInfo: ErrorInfo) => void;
  level?: 'global' | 'component' | 'page'; // Different error boundary levels
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
  errorId: string;
  retryCount: number;
}

export class ErrorBoundary extends Component<Props, State> {
  private maxRetries = 3;
  private retryTimeout: number | null = null;
  private errorLoggingInProgress = false;

  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
      errorId: '',
      retryCount: 0
    };
  }

  static getDerivedStateFromError(error: Error): Partial<State> {
    return {
      hasError: true,
      error,
      errorId: Date.now().toString(36) + Math.random().toString(36).substr(2)
    };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // Prevent infinite error loops
    if (this.errorLoggingInProgress) {
      return;
    }

    this.errorLoggingInProgress = true;

    try {
      this.setState({
        error,
        errorInfo
      });

      // Log error to console in development with safeguards
      if (process.env.NODE_ENV === 'development') {
        console.group('🚨 Error Boundary Caught an Error');
        console.error('Error:', error);
        console.error('Error Info:', errorInfo);
        console.error('Component Stack:', errorInfo.componentStack);
        console.error('Props Level:', this.props.level || 'component');
        console.groupEnd();
      }

      // Call custom error handler if provided (with error handling)
      if (this.props.onError) {
        try {
          this.props.onError(error, errorInfo);
        } catch (handlerError) {
          console.error('Error in custom error handler:', handlerError);
        }
      }

      // Log to external service in production (with error handling)
      this.logErrorToService(error, errorInfo);
    } catch (catchError) {
      console.error('Error in componentDidCatch:', catchError);
    } finally {
      this.errorLoggingInProgress = false;
    }
  }

  private logErrorToService = (error: Error, errorInfo: ErrorInfo) => {
    try {
      // Rate limit error reporting to prevent spam
      const lastReportTime = sessionStorage.getItem('lastErrorReport');
      const now = Date.now();
      
      if (lastReportTime && now - parseInt(lastReportTime) < 30000) {
        return; // Don't report more than once per 30 seconds
      }

      const errorData = {
        message: error.message,
        stack: error.stack,
        componentStack: errorInfo.componentStack,
        timestamp: new Date().toISOString(),
        userAgent: navigator.userAgent,
        url: window.location.href,
        errorId: this.state.errorId,
        level: this.props.level || 'component',
        retryCount: this.state.retryCount
      };

      // Store the error report time
      sessionStorage.setItem('lastErrorReport', now.toString());

      // For now, just log to console and session storage
      console.log('Error logged:', errorData);
      
      // Store in session storage with size limits
      try {
        const existingLogs = sessionStorage.getItem('errorBoundaryLogs');
        const logs = existingLogs ? JSON.parse(existingLogs) : [];
        logs.push(errorData);
        
        // Keep only last 10 errors to prevent storage bloat
        if (logs.length > 10) {
          logs.splice(0, logs.length - 10);
        }
        
        sessionStorage.setItem('errorBoundaryLogs', JSON.stringify(logs));
      } catch (storageError) {
        console.warn('Failed to store error log:', storageError);
      }
      
    } catch (loggingError) {
      console.error('Failed to log error:', loggingError);
    }
  };

  private handleRetry = () => {
    if (this.state.retryCount >= this.maxRetries) {
      return;
    }

    // Clear any existing timeout
    if (this.retryTimeout) {
      clearTimeout(this.retryTimeout);
    }

    // Add a small delay before retry to prevent rapid retries
    this.retryTimeout = window.setTimeout(() => {
      this.setState(prevState => ({
        hasError: false,
        error: null,
        errorInfo: null,
        errorId: '',
        retryCount: prevState.retryCount + 1
      }));
    }, 1000);
  };

  private handleReload = () => {
    // Clear error boundary logs before reload
    try {
      sessionStorage.removeItem('errorBoundaryLogs');
      sessionStorage.removeItem('lastErrorReport');
    } catch {
      // Ignore storage errors
    }
    
    window.location.reload();
  };

  private handleGoHome = () => {
    // Clear error boundary logs
    try {
      sessionStorage.removeItem('errorBoundaryLogs');
      sessionStorage.removeItem('lastErrorReport');
    } catch {
      // Ignore storage errors
    }
    
    window.location.href = '#home';
    window.location.reload();
  };

  componentWillUnmount() {
    // Clean up timeout on unmount
    if (this.retryTimeout) {
      clearTimeout(this.retryTimeout);
    }
  }

  render() {
    if (this.state.hasError) {
      // Use custom fallback if provided
      if (this.props.fallback) {
        return this.props.fallback;
      }

      // Different UI based on error boundary level
      const isGlobalError = this.props.level === 'global';
      const isPageError = this.props.level === 'page';

      return (
        <div className={`${
          isGlobalError ? 'min-h-screen' : isPageError ? 'min-h-96' : 'min-h-48'
        } bg-gray-50 flex items-center justify-center p-4`}>
          <div className={`${
            isGlobalError ? 'max-w-md' : 'max-w-sm'
          } w-full bg-white rounded-lg shadow-lg p-6 text-center`}>
            <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-6 h-6 text-red-600" />
            </div>
            
            <h1 className={`${
              isGlobalError ? 'text-xl' : 'text-lg'
            } font-bold text-gray-900 mb-3`}>
              {isGlobalError ? 'Application Error' : 'Something went wrong'}
            </h1>
            
            <p className="text-gray-600 mb-4 text-sm">
              {isGlobalError 
                ? 'The application encountered an unexpected error.' 
                : 'This section encountered an error.'}
            </p>

            {process.env.NODE_ENV === 'development' && this.state.error && (
              <details className="mb-4 text-left">
                <summary className="cursor-pointer text-xs text-gray-500 mb-2">
                  Error Details (Development)
                </summary>
                <div className="bg-gray-100 p-3 rounded text-xs font-mono text-gray-700 overflow-auto max-h-24">
                  <div className="font-bold mb-1">Error:</div>
                  <div className="mb-2">{this.state.error.message}</div>
                  {this.state.error.stack && (
                    <>
                      <div className="font-bold mb-1">Stack (truncated):</div>
                      <pre className="whitespace-pre-wrap">
                        {this.state.error.stack.substring(0, 500)}
                        {this.state.error.stack.length > 500 ? '...' : ''}
                      </pre>
                    </>
                  )}
                </div>
              </details>
            )}

            <div className="space-y-2">
              {this.state.retryCount < this.maxRetries && (
                <button
                  onClick={this.handleRetry}
                  className="w-full flex items-center justify-center gap-2 px-3 py-2 bg-[#1A3C1F] text-white rounded-md hover:bg-[#152f18] transition-colors text-sm"
                >
                  <RefreshCw className="w-4 h-4" />
                  Try Again ({this.maxRetries - this.state.retryCount} left)
                </button>
              )}
              
              {isGlobalError && (
                <>
                  <button
                    onClick={this.handleReload}
                    className="w-full flex items-center justify-center gap-2 px-3 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors text-sm"
                  >
                    <RefreshCw className="w-4 h-4" />
                    Reload Page
                  </button>
                  
                  <button
                    onClick={this.handleGoHome}
                    className="w-full flex items-center justify-center gap-2 px-3 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors text-sm"
                  >
                    <Home className="w-4 h-4" />
                    Go Home
                  </button>
                </>
              )}
            </div>

            <div className="mt-4 pt-4 border-t border-gray-200">
              <p className="text-xs text-gray-500">
                Error ID: {this.state.errorId}
              </p>
              {isGlobalError && (
                <p className="text-xs text-gray-500 mt-1">
                  Need help? Call{' '}
                  <a 
                    href="tel:+18437894430" 
                    className="text-[#1A3C1F] hover:underline"
                  >
                    (843) 789-4430
                  </a>
                </p>
              )}
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

// Hook for handling async errors in functional components with safeguards
export const useErrorHandler = () => {
  const [error, setError] = React.useState<Error | null>(null);
  const errorTimeoutRef = React.useRef<number | null>(null);

  const handleError = React.useCallback((error: Error) => {
    // Prevent rapid error setting
    if (errorTimeoutRef.current) {
      clearTimeout(errorTimeoutRef.current);
    }

    errorTimeoutRef.current = window.setTimeout(() => {
      setError(error);
      console.error('Async error caught:', error);
    }, 100);
  }, []);

  const clearError = React.useCallback(() => {
    if (errorTimeoutRef.current) {
      clearTimeout(errorTimeoutRef.current);
    }
    setError(null);
  }, []);

  React.useEffect(() => {
    if (error) {
      throw error; // This will be caught by ErrorBoundary
    }
  }, [error]);

  // Cleanup timeout on unmount
  React.useEffect(() => {
    return () => {
      if (errorTimeoutRef.current) {
        clearTimeout(errorTimeoutRef.current);
      }
    };
  }, []);

  return { handleError, clearError, error };
};

// Higher-order component for wrapping components with error boundary
export const withErrorBoundary = <P extends object>(
  Component: React.ComponentType<P>,
  fallback?: ReactNode,
  level: Props['level'] = 'component'
) => {
  const WrappedComponent = (props: P) => (
    <ErrorBoundary fallback={fallback} level={level}>
      <Component {...props} />
    </ErrorBoundary>
  );

  WrappedComponent.displayName = `withErrorBoundary(${Component.displayName || Component.name})`;
  return WrappedComponent;
};