import React, { useState } from 'react';
import { Mail, Phone, MapPin, Clock, CheckCircle, AlertCircle } from 'lucide-react';
import { MetaTags } from './MetaTags';
import { contactFormService, ContactFormData } from '../lib/enhancedSendMessage';
import { FormErrorHandler, FieldError, SuccessMessage, LoadingState } from './FormErrorHandler';
import { useErrorHandler } from './ErrorBoundary';

export const ContactPage = () => {
  const [formData, setFormData] = useState<ContactFormData>({
    fullName: '',
    email: '',
    phone: '',
    message: ''
  });
  
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [touchedFields, setTouchedFields] = useState<Record<string, boolean>>({});
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitResult, setSubmitResult] = useState<{
    type: 'success' | 'error' | null;
    message: string;
  }>({ type: null, message: '' });

  const { handleError } = useErrorHandler();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear field error when user starts typing
    if (fieldErrors[name]) {
      setFieldErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
    
    // Clear global status when user modifies form
    if (submitResult.type) {
      setSubmitResult({ type: null, message: '' });
    }
  };

  const handleFieldBlur = async (e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name } = e.target;
    setTouchedFields(prev => ({ ...prev, [name]: true }));
    
    // Validate single field
    try {
      const validation = await contactFormService.validateFormOnly(formData);
      const fieldError = validation.errors.find(error => error.field === name);
      
      if (fieldError) {
        setFieldErrors(prev => ({ ...prev, [name]: fieldError.message }));
      }
    } catch (error) {
      // Silently handle validation errors
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!termsAccepted) {
      setSubmitResult({
        type: 'error',
        message: 'Please agree to the terms of service before submitting.'
      });
      return;
    }

    setIsSubmitting(true);
    setSubmitResult({ type: null, message: '' });
    setFieldErrors({});

    try {
      const result = await contactFormService.submitMessage(formData);
      
      if (result.success) {
        setSubmitResult({
          type: 'success',
          message: result.message || 'Message sent successfully!'
        });
        
        // Reset form on success
        setFormData({
          fullName: '',
          email: '',
          phone: '',
          message: ''
        });
        setTermsAccepted(false);
        setTouchedFields({});
      } else {
        // Handle validation errors
        if (result.code === 'VALIDATION_ERROR' && result.error) {
          try {
            const errorData = JSON.parse(result.error);
            if (errorData.errors && Array.isArray(errorData.errors)) {
              const newFieldErrors: Record<string, string> = {};
              errorData.errors.forEach((error: any) => {
                if (error.field && error.message) {
                  newFieldErrors[error.field] = error.message;
                }
              });
              setFieldErrors(newFieldErrors);
            }
          } catch {
            // If we can't parse validation errors, show general message
            setSubmitResult({
              type: 'error',
              message: result.message || result.error || 'Please check your form for errors.'
            });
          }
        } else {
          setSubmitResult({
            type: 'error',
            message: result.message || result.error || 'Failed to send message. Please try again.'
          });
        }
      }
    } catch (error) {
      handleError(error as Error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-white">
      <MetaTags
        title="Contact Us"
        description="Get in touch with Change Up Cuts Barbershop and Beauty Center. Book appointments, find our location, and connect with our team. Walk-ins welcome!"
        keywords="contact barbershop, book appointment, Charleston salon location, barber contacts"
        type="business.business"
        image="https://i.postimg.cc/J4Y1qzf1/googlemaps.png"
        twitterCard="summary_large_image"
        canonicalPath="/contact"
      />
      
      {/* Hero Section */}
      <section 
        className="relative min-h-[70vh] flex items-center justify-center"
        style={{
          backgroundImage: 'url("https://i.postimg.cc/sgs5tj3z/Third.webp")',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: window.innerWidth >= 768 ? 'fixed' : 'scroll'
        }}
        role="banner"
        aria-label="Contact page hero section with barbershop background"
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/70 to-black/80" aria-hidden="true"></div>
        
        <div className="relative z-10 container mx-auto px-4 pt-24 text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold text-white mb-6 leading-tight">
            Contact Us
          </h1>
          <div className="w-16 md:w-24 h-1 bg-[#1A3C1F] mx-auto mb-8" aria-hidden="true"></div>
          <p className="text-lg md:text-xl text-white/90 max-w-2xl mx-auto mb-8 leading-relaxed">
            Get in touch with us for appointments, questions, or feedback
          </p>
        </div>

        <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-black/50 to-transparent" aria-hidden="true"></div>
      </section>

      {/* Contact Information Section */}
      <section className="py-12 md:py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Contact Methods */}
              <div className="bg-white p-8 rounded-xl shadow-lg border border-gray-100 hover:shadow-2xl transition-all duration-500 ease-out group hover:scale-[1.02] hover:border-[#1A3C1F]/20 relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-[#1A3C1F]/0 via-[#1A3C1F]/0 to-[#1A3C1F]/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" aria-hidden="true"></div>
                <div className="absolute -inset-1 bg-gradient-to-r from-[#1A3C1F]/10 via-[#1A3C1F]/5 to-[#1A3C1F]/10 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-sm" aria-hidden="true"></div>
                
                <div className="text-center relative z-10">
                  <div className="w-16 h-16 bg-[#1A3C1F]/10 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-[#1A3C1F]/20 transition-colors duration-300 group-hover:shadow-lg group-hover:shadow-[#1A3C1F]/20">
                    <Phone className="w-8 h-8 text-[#1A3C1F] group-hover:scale-110 transition-transform duration-300" aria-hidden="true" />
                  </div>
                  <h3 className="text-xl font-bold mb-4 group-hover:text-[#1A3C1F] transition-colors duration-300">Call Us</h3>
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm text-gray-500 mb-1">Barbershop</p>
                      <a 
                        href="tel:+18437894430" 
                        className="text-lg font-medium text-[#1A3C1F] hover:text-[#152f18] transition-colors"
                        aria-label="Call barbershop at (843) 789-4430"
                      >
                        (843) 789-4430
                      </a>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 mb-1">Beauty Center</p>
                      <a 
                        href="tel:+18437894360" 
                        className="text-lg font-medium text-[#1A3C1F] hover:text-[#152f18] transition-colors"
                        aria-label="Call beauty center at (843) 789-4360"
                      >
                        (843) 789-4360
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              {/* Email */}
              <div className="bg-white p-8 rounded-xl shadow-lg border border-gray-100 hover:shadow-2xl transition-all duration-500 ease-out group hover:scale-[1.02] hover:border-[#1A3C1F]/20 relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-[#1A3C1F]/0 via-[#1A3C1F]/0 to-[#1A3C1F]/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" aria-hidden="true"></div>
                <div className="absolute -inset-1 bg-gradient-to-r from-[#1A3C1F]/10 via-[#1A3C1F]/5 to-[#1A3C1F]/10 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-sm" aria-hidden="true"></div>
                
                <div className="text-center relative z-10">
                  <div className="w-16 h-16 bg-[#1A3C1F]/10 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-[#1A3C1F]/20 transition-colors duration-300 group-hover:shadow-lg group-hover:shadow-[#1A3C1F]/20">
                    <Mail className="w-8 h-8 text-[#1A3C1F] group-hover:scale-110 transition-transform duration-300" aria-hidden="true" />
                  </div>
                  <h3 className="text-xl font-bold mb-4 group-hover:text-[#1A3C1F] transition-colors duration-300">Email Us</h3>
                  <a 
                    href="mailto:info@changeupcuts.com" 
                    className="text-lg font-medium text-[#1A3C1F] hover:text-[#152f18] transition-colors"
                    aria-label="Send email to info@changeupcuts.com"
                  >
                    info@changeupcuts.com
                  </a>
                  <p className="text-gray-500 text-sm mt-2">
                    We'll get back to you within 24 hours
                  </p>
                </div>
              </div>

              {/* Location */}
              <div className="bg-white p-8 rounded-xl shadow-lg border border-gray-100 hover:shadow-2xl transition-all duration-500 ease-out group hover:scale-[1.02] hover:border-[#1A3C1F]/20 relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-[#1A3C1F]/0 via-[#1A3C1F]/0 to-[#1A3C1F]/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" aria-hidden="true"></div>
                <div className="absolute -inset-1 bg-gradient-to-r from-[#1A3C1F]/10 via-[#1A3C1F]/5 to-[#1A3C1F]/10 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-sm" aria-hidden="true"></div>
                
                <div className="text-center relative z-10">
                  <div className="w-16 h-16 bg-[#1A3C1F]/10 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-[#1A3C1F]/20 transition-colors duration-300 group-hover:shadow-lg group-hover:shadow-[#1A3C1F]/20">
                    <MapPin className="w-8 h-8 text-[#1A3C1F] group-hover:scale-110 transition-transform duration-300" aria-hidden="true" />
                  </div>
                  <h3 className="text-xl font-bold mb-4 group-hover:text-[#1A3C1F] transition-colors duration-300">Visit Us</h3>
                  <a 
                    href="https://www.google.com/maps/place/Change+Up+Cuts+Barbershop+%26+Beauty+Center/@32.9044054,-80.0203215,17.05z/data=!4m6!3m5!1s0x88fe636c08e7b0a3:0x80d92ec6413760e4!8m2!3d32.904006!4d-80.0181136!16s%2Fg%2F11q8vcl_gr?entry=ttu&g_ep=EgoyMDI1MDYwNC4wIKXMDSoASAFQAw%3D%3D"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#1A3C1F] hover:text-[#152f18] transition-colors"
                    aria-label="View our location on Google Maps - opens in new window"
                  >
                    <p className="font-medium">5900 Rivers Avenue</p>
                    <p className="font-medium">Suite D-4</p>
                    <p className="font-medium">North Charleston, SC 29406</p>
                  </a>
                  <p className="text-gray-500 text-sm mt-2">
                    Click for directions
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Hours and Contact Form Section */}
      <section className="py-12 md:py-16 bg-gray-50 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-gray-50 via-gray-50 to-gray-100/50" aria-hidden="true"></div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {/* Hours */}
              <div className="space-y-8">
                <h2 className="text-3xl font-bold mb-8 text-center lg:text-left">Hours of Operation</h2>
                <div className="space-y-6">
                  {/* Barbershop Hours */}
                  <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-xl transition-all duration-500 ease-out group hover:scale-[1.02] border border-gray-100 hover:border-[#1A3C1F]/20 relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-[#1A3C1F]/0 via-[#1A3C1F]/0 to-[#1A3C1F]/3 opacity-0 group-hover:opacity-100 transition-opacity duration-500" aria-hidden="true"></div>
                    <div className="absolute -inset-1 bg-gradient-to-r from-[#1A3C1F]/5 via-[#1A3C1F]/3 to-[#1A3C1F]/5 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-sm" aria-hidden="true"></div>
                    
                    <div className="relative z-10">
                      <div className="flex items-center mb-4">
                        <div className="w-10 h-10 bg-[#1A3C1F]/10 rounded-full flex items-center justify-center mr-3 group-hover:bg-[#1A3C1F]/20 transition-colors duration-300 group-hover:shadow-md group-hover:shadow-[#1A3C1F]/20">
                          <Clock className="w-6 h-6 text-[#1A3C1F] group-hover:scale-110 transition-transform duration-300" aria-hidden="true" />
                        </div>
                        <h3 className="text-xl font-bold group-hover:text-[#1A3C1F] transition-colors duration-300">Barbershop</h3>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center py-1 px-2 rounded hover:bg-gray-50 transition-colors duration-200">
                          <span className="font-medium">Monday - Thursday</span>
                          <span className="text-gray-600">10:00 AM - 7:30 PM</span>
                        </div>
                        <div className="flex justify-between items-center py-1 px-2 rounded hover:bg-gray-50 transition-colors duration-200">
                          <span className="font-medium">Friday - Saturday</span>
                          <span className="text-gray-600">9:00 AM - 8:00 PM</span>
                        </div>
                        <div className="flex justify-between items-center py-1 px-2 rounded hover:bg-gray-50 transition-colors duration-200">
                          <span className="font-medium">Sunday</span>
                          <span className="text-gray-600">9:00 AM - 4:00 PM</span>
                        </div>
                      </div>
                      <div className="mt-4 text-center">
                        <span className="inline-block px-4 py-2 bg-[#1A3C1F]/10 text-[#1A3C1F] text-sm font-medium rounded-full group-hover:bg-[#1A3C1F]/20 transition-colors duration-300 group-hover:shadow-sm">
                          Walk-ins Welcome
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Beauty Center Hours */}
                  <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-xl transition-all duration-500 ease-out group hover:scale-[1.02] border border-gray-100 hover:border-[#1A3C1F]/20 relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-[#1A3C1F]/0 via-[#1A3C1F]/0 to-[#1A3C1F]/3 opacity-0 group-hover:opacity-100 transition-opacity duration-500" aria-hidden="true"></div>
                    <div className="absolute -inset-1 bg-gradient-to-r from-[#1A3C1F]/5 via-[#1A3C1F]/3 to-[#1A3C1F]/5 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-sm" aria-hidden="true"></div>
                    
                    <div className="relative z-10">
                      <div className="flex items-center mb-4">
                        <div className="w-10 h-10 bg-[#1A3C1F]/10 rounded-full flex items-center justify-center mr-3 group-hover:bg-[#1A3C1F]/20 transition-colors duration-300 group-hover:shadow-md group-hover:shadow-[#1A3C1F]/20">
                          <Clock className="w-6 h-6 text-[#1A3C1F] group-hover:scale-110 transition-transform duration-300" aria-hidden="true" />
                        </div>
                        <h3 className="text-xl font-bold group-hover:text-[#1A3C1F] transition-colors duration-300">Beauty Center</h3>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center py-1 px-2 rounded hover:bg-gray-50 transition-colors duration-200">
                          <span className="font-medium">Monday - Thursday</span>
                          <span className="text-gray-600">10:00 AM - 5:00 PM</span>
                        </div>
                        <div className="flex justify-between items-center py-1 px-2 rounded hover:bg-gray-50 transition-colors duration-200">
                          <span className="font-medium">Friday - Saturday</span>
                          <span className="text-gray-600">9:00 AM - 6:00 PM</span>
                        </div>
                        <div className="flex justify-between items-center py-1 px-2 rounded hover:bg-gray-50 transition-colors duration-200">
                          <span className="font-medium">Sunday</span>
                          <span className="text-gray-600">CLOSED</span>
                        </div>
                      </div>
                      <div className="mt-4 text-center">
                        <span className="inline-block px-4 py-2 bg-[#1A3C1F]/10 text-[#1A3C1F] text-sm font-medium rounded-full group-hover:bg-[#1A3C1F]/20 transition-colors duration-300 group-hover:shadow-sm">
                          Walk-ins Welcome
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Contact Form */}
              <div>
                <h2 className="text-3xl font-bold mb-8 text-center lg:text-left">Send us a Message</h2>
                <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300 border border-gray-100">
                  
                  {/* Success Message */}
                  {submitResult.type === 'success' && (
                    <SuccessMessage
                      message={submitResult.message}
                      onClose={() => setSubmitResult({ type: null, message: '' })}
                    />
                  )}

                  {/* Global Error Message */}
                  {submitResult.type === 'error' && (
                    <div className="mb-6 p-4 rounded-lg bg-red-50 border border-red-200 flex items-start gap-3">
                      <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                      <p className="text-sm font-medium text-red-800">{submitResult.message}</p>
                    </div>
                  )}

                  <form className="space-y-6" onSubmit={handleSubmit}>
                    <div className="group">
                      <label htmlFor="fullName" className="block text-sm font-medium text-gray-700 mb-2 group-focus-within:text-[#1A3C1F] transition-colors duration-200">
                        Full Name *
                      </label>
                      <input
                        type="text"
                        id="fullName"
                        name="fullName"
                        value={formData.fullName}
                        onChange={handleInputChange}
                        onBlur={handleFieldBlur}
                        required
                        className={`w-full px-4 py-3 bg-white border rounded-lg focus:ring-2 focus:ring-[#1A3C1F] focus:border-[#1A3C1F] text-gray-900 transition-all duration-300 hover:border-gray-400 hover:shadow-sm focus:shadow-md ${
                          fieldErrors.fullName ? 'border-red-500' : 'border-gray-300'
                        }`}
                        placeholder="Your full name"
                        aria-describedby="name-description"
                      />
                      <FieldError error={fieldErrors.fullName} touched={touchedFields.fullName} />
                      <span id="name-description" className="sr-only">Enter your full name for contact purposes</span>
                    </div>
                    
                    <div className="group">
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2 group-focus-within:text-[#1A3C1F] transition-colors duration-200">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        onBlur={handleFieldBlur}
                        required
                        className={`w-full px-4 py-3 bg-white border rounded-lg focus:ring-2 focus:ring-[#1A3C1F] focus:border-[#1A3C1F] text-gray-900 transition-all duration-300 hover:border-gray-400 hover:shadow-sm focus:shadow-md ${
                          fieldErrors.email ? 'border-red-500' : 'border-gray-300'
                        }`}
                        placeholder="your.email@example.com"
                        aria-describedby="email-description"
                      />
                      <FieldError error={fieldErrors.email} touched={touchedFields.email} />
                      <span id="email-description" className="sr-only">Enter your email address for our response</span>
                    </div>
                    
                    <div className="group">
                      <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2 group-focus-within:text-[#1A3C1F] transition-colors duration-200">
                        Phone Number (Optional)
                      </label>
                      <input
                        type="tel"
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        onBlur={handleFieldBlur}
                        className={`w-full px-4 py-3 bg-white border rounded-lg focus:ring-2 focus:ring-[#1A3C1F] focus:border-[#1A3C1F] text-gray-900 transition-all duration-300 hover:border-gray-400 hover:shadow-sm focus:shadow-md ${
                          fieldErrors.phone ? 'border-red-500' : 'border-gray-300'
                        }`}
                        placeholder="(843) 555-0123"
                        aria-describedby="phone-description"
                      />
                      <FieldError error={fieldErrors.phone} touched={touchedFields.phone} />
                      <span id="phone-description" className="sr-only">Enter your phone number for phone contact (optional)</span>
                    </div>
                    
                    <div className="group">
                      <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2 group-focus-within:text-[#1A3C1F] transition-colors duration-200">
                        Message *
                      </label>
                      <textarea
                        id="message"
                        name="message"
                        rows={5}
                        value={formData.message}
                        onChange={handleInputChange}
                        onBlur={handleFieldBlur}
                        required
                        className={`w-full px-4 py-3 bg-white border rounded-lg focus:ring-2 focus:ring-[#1A3C1F] focus:border-[#1A3C1F] text-gray-900 resize-none transition-all duration-300 hover:border-gray-400 hover:shadow-sm focus:shadow-md ${
                          fieldErrors.message ? 'border-red-500' : 'border-gray-300'
                        }`}
                        placeholder="Tell us about your needs or ask any questions..."
                        aria-describedby="message-description"
                      ></textarea>
                      <FieldError error={fieldErrors.message} touched={touchedFields.message} />
                      <span id="message-description" className="sr-only">Enter your message or questions about our services</span>
                    </div>
                    
                    {/* Terms Agreement Checkbox */}
                    <div className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg border border-gray-200 hover:border-[#1A3C1F]/30 transition-colors duration-200">
                      <div className="relative flex items-center">
                        <input
                          type="checkbox"
                          id="terms"
                          checked={termsAccepted}
                          onChange={(e) => setTermsAccepted(e.target.checked)}
                          className="h-5 w-5 bg-white border-2 border-gray-300 rounded text-[#1A3C1F] focus:ring-2 focus:ring-[#1A3C1F] focus:ring-offset-2 hover:border-[#1A3C1F] transition-all duration-200 cursor-pointer checked:bg-[#1A3C1F] checked:border-[#1A3C1F]"
                          required
                        />
                      </div>
                      <label htmlFor="terms" className="text-sm text-gray-700 leading-relaxed cursor-pointer flex-1">
                        I agree to the{' '}
                        <a 
                          href="#terms" 
                          className="text-[#1A3C1F] hover:text-[#152f18] underline decoration-2 underline-offset-2 transition-colors duration-200 font-medium"
                        >
                          Terms of Service
                        </a>
                        {' '}and{' '}
                        <a 
                          href="#privacy" 
                          className="text-[#1A3C1F] hover:text-[#152f18] underline decoration-2 underline-offset-2 transition-colors duration-200 font-medium"
                        >
                          Privacy Policy
                        </a>
                        . <span className="text-red-500 font-medium">*</span>
                      </label>
                    </div>
                    
                    {/* Submit Button */}
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full bg-[#1A3C1F] text-white py-3 px-6 rounded-lg hover:bg-[#152f18] transition-all duration-300 font-medium text-lg shadow-md hover:shadow-lg hover:scale-[1.02] active:scale-[0.98] relative overflow-hidden group disabled:opacity-50 disabled:cursor-not-allowed"
                      aria-describedby="submit-description"
                    >
                      <span className="relative z-10 flex items-center justify-center gap-2">
                        {isSubmitting ? (
                          <>
                            <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                            Sending Message...
                          </>
                        ) : (
                          <>
                            <Mail className="w-5 h-5" />
                            Send Message
                          </>
                        )}
                      </span>
                      <div className="absolute inset-0 bg-gradient-to-r from-[#152f18] to-[#1A3C1F] opacity-0 group-hover:opacity-100 transition-opacity duration-300" aria-hidden="true"></div>
                    </button>
                    <span id="submit-description" className="sr-only">Click to send your message to Change Up Cuts</span>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="py-12 md:py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Visit Our Location</h2>
            <p className="text-gray-600 text-lg mb-12 max-w-2xl mx-auto">
              We're conveniently located in North Charleston. Click the map to get directions and plan your visit!
            </p>
            
            <div className="relative">
              <a 
                href="https://www.google.com/maps/place/Change+Up+Cuts+Barbershop+%26+Beauty+Center/@32.9044054,-80.0203215,17.05z/data=!4m6!3m5!1s0x88fe636c08e7b0a3:0x80d92ec6413760e4!8m2!3d32.904006!4d-80.0181136!16s%2Fg%2F11q8vcl_gr?entry=ttu&g_ep=EgoyMDI1MDYwNC4wIKXMDSoASAFQAw%3D%3D"
                target="_blank"
                rel="noopener noreferrer"
                className="block w-full h-[400px] md:h-[500px] rounded-xl bg-cover bg-center transition-all duration-300 hover:shadow-2xl hover:scale-[1.01] cursor-pointer group relative overflow-hidden shadow-lg"
                style={{
                  backgroundImage: 'url("https://i.postimg.cc/7hLFGgYS/Screenshot-2025-06-07-6-53-31-PM.png")'
                }}
                aria-label="Interactive map showing Change Up Cuts location in North Charleston - click to open in Google Maps"
              >
                {/* Hover overlay */}
                <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <div className="bg-white/95 px-6 py-4 rounded-lg shadow-xl transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                    <p className="text-gray-800 font-medium flex items-center text-lg">
                      <MapPin className="w-5 h-5 mr-3 text-[#1A3C1F]" aria-hidden="true" />
                      Click for directions
                    </p>
                  </div>
                </div>
              </a>
            </div>

            {/* Quick Info Below Map */}
            <div className="mt-8 bg-gray-50 rounded-xl p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
                <div>
                  <h4 className="font-bold text-gray-900 mb-2">Address</h4>
                  <p className="text-gray-600">5900 Rivers Avenue, Suite D-4<br />North Charleston, SC 29406</p>
                </div>
                <div>
                  <h4 className="font-bold text-gray-900 mb-2">Parking</h4>
                  <p className="text-gray-600">Free parking available<br />in front of the building</p>
                </div>
                <div>
                  <h4 className="font-bold text-gray-900 mb-2">Accessibility</h4>
                  <p className="text-gray-600">Wheelchair accessible<br />entrance and facilities</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-[#1A3C1F] py-16" role="region" aria-labelledby="cta-heading">
        <div className="container mx-auto px-4 text-center">
          <h2 id="cta-heading" className="text-3xl md:text-4xl text-white font-bold mb-6">Ready to Book Your Appointment?</h2>
          <p className="text-lg text-white/90 mb-8 max-w-2xl mx-auto">
            Don't wait - schedule your appointment today and experience the Change Up Cuts difference.
          </p>
          <a 
            href="https://getsquire.com/booking/book/change-up-cuts-barbershop-and-beauty-center-north-charleston/barber/any/services"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block px-8 py-4 bg-[#D2B48C] text-black text-lg font-medium hover:bg-[#C19A6B] transition-all rounded-lg shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
            aria-label="Schedule appointment online - opens in new window"
          >
            Schedule Appointment
          </a>
        </div>
      </section>
    </div>
  );
};