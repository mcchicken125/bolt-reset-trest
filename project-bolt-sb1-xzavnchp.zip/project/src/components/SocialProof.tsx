import React from 'react';
import { Star, Users, Award, TrendingUp } from 'lucide-react';

export const SocialProof = () => {
  const stats = [
    {
      icon: Users,
      value: "2,500+",
      label: "Happy Clients",
      description: "Served since 2021"
    },
    {
      icon: Star,
      value: "5.0",
      label: "Average Rating",
      description: "Based on 50+ reviews"
    },
    {
      icon: Award,
      value: "3+",
      label: "Years Experience",
      description: "Professional excellence"
    },
    {
      icon: TrendingUp,
      value: "100%",
      label: "Client Satisfaction",
      description: "Guaranteed results"
    }
  ];

  const socialLogos = [
    {
      name: "Charleston City Paper",
      logo: "https://i.postimg.cc/66kGZF8m/citypaper.png",
      description: "Featured in local business coverage"
    },
    {
      name: "The Post and Courier",
      logo: "https://i.postimg.cc/sfY3nLn8/PC-1.png",
      description: "Highlighted in community news"
    },
    {
      name: "WCSC Live 5 News",
      logo: "https://i.postimg.cc/W1CRpmWg/wcbs.png",
      description: "Featured in local business segment"
    }
  ];

  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        {/* Social Stats */}
        <div className="mb-16">
          <h3 className="text-center text-2xl font-bold mb-8 text-gray-900">
            Trusted by the Charleston Community
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, index) => (
              <div key={index} className="text-center group">
                <div className="w-16 h-16 bg-[#1A3C1F]/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#1A3C1F]/20 transition-colors duration-300">
                  <stat.icon className="w-8 h-8 text-[#1A3C1F]" />
                </div>
                <div className="text-3xl font-bold text-[#1A3C1F] mb-1">{stat.value}</div>
                <div className="font-semibold text-gray-900 mb-1">{stat.label}</div>
                <div className="text-sm text-gray-600">{stat.description}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Media Mentions */}
        <div className="text-center">
          <h4 className="text-lg font-semibold mb-6 text-gray-700">
            As Featured In
          </h4>
          <div className="flex justify-center items-center gap-8 flex-wrap opacity-60">
            {socialLogos.map((media, index) => (
              <div key={index} className="group cursor-pointer">
                <img
                  src={media.logo}
                  alt={`${media.name} logo`}
                  className="h-12 object-contain grayscale group-hover:grayscale-0 transition-all duration-300"
                  title={media.description}
                />
              </div>
            ))}
          </div>
        </div>

        {/* Social Media CTA */}
        <div className="mt-12 text-center">
          <div className="bg-gradient-to-r from-[#1A3C1F]/5 to-[#1A3C1F]/10 rounded-xl p-8 max-w-2xl mx-auto">
            <h4 className="text-xl font-bold mb-4 text-gray-900">
              Follow Us for Daily Inspiration
            </h4>
            <p className="text-gray-600 mb-6">
              See our latest work, behind-the-scenes content, and stay updated with special offers.
            </p>
            <div className="flex justify-center gap-4">
              <a
                href="https://www.facebook.com/changeupcuts"
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
              >
                Facebook
              </a>
              <a
                href="https://www.instagram.com/changeupcuts"
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-2 bg-pink-600 text-white rounded-lg hover:bg-pink-700 transition-colors font-medium"
              >
                Instagram
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};