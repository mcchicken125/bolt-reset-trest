import React from 'react';
import { Scissors, Bean, SprayCan, Coffee } from 'lucide-react';

export const Services = () => {
  return (
    <section id="services" className="bg-black text-white py-24">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-6xl md:text-7xl font-display font-bold mb-6">Barbershop</h2>
          <div className="w-24 h-1 bg-[#1A3C1F] mx-auto mb-8"></div>
          <p className="text-gray-300 text-lg max-w-3xl mx-auto">
            Experience excellence with our range of professional barbering services. Each service includes a consultation to ensure you get exactly what you want.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-24">
          <div className="bg-[#111] p-8 rounded-lg">
            <Scissors className="w-12 h-12 text-[#1A3C1F] mb-6" />
            <h3 className="text-3xl font-bold mb-4">Classic Haircut</h3>
            <p className="text-gray-300 mb-8 text-lg">
              Traditional haircut with clippers and scissors for a clean, timeless look.
            </p>
            <div className="flex justify-between items-center">
              <span className="text-4xl font-bold">$28</span>
              <a href="#booking" className="text-[#1A3C1F] hover:text-[#1A3C1F]/80 transition-colors text-lg">Book Now</a>
            </div>
          </div>

          <div className="bg-[#111] p-8 rounded-lg">
            <Bean className="w-12 h-12 text-[#1A3C1F] mb-6" />
            <h3 className="text-3xl font-bold mb-4">Beard Trim</h3>
            <p className="text-gray-300 mb-8 text-lg">
              Precision beard shaping and trimming to enhance your facial features.
            </p>
            <div className="flex justify-between items-center">
              <span className="text-4xl font-bold">$15</span>
              <a href="#booking" className="text-[#1A3C1F] hover:text-[#1A3C1F]/80 transition-colors text-lg">Book Now</a>
            </div>
          </div>

          <div className="bg-[#111] p-8 rounded-lg">
            <SprayCan className="w-12 h-12 text-[#1A3C1F] mb-6" />
            <h3 className="text-3xl font-bold mb-4">Hot Towel Shave</h3>
            <p className="text-gray-300 mb-8 text-lg">
              Luxurious straight razor shave with hot towel treatment for the smoothest finish.
            </p>
            <div className="flex justify-between items-center">
              <span className="text-4xl font-bold">$35</span>
              <a href="#booking" className="text-[#1A3C1F] hover:text-[#1A3C1F]/80 transition-colors text-lg">Book Now</a>
            </div>
          </div>

          <div className="bg-[#111] p-8 rounded-lg">
            <Coffee className="w-12 h-12 text-[#1A3C1F] mb-6" />
            <h3 className="text-3xl font-bold mb-4">Full Service</h3>
            <p className="text-gray-300 mb-8 text-lg">
              Complete package including haircut, beard trim, and styling with premium products.
            </p>
            <div className="flex justify-between items-center">
              <span className="text-4xl font-bold">$45</span>
              <a href="#booking" className="text-[#1A3C1F] hover:text-[#1A3C1F]/80 transition-colors text-lg">Book Now</a>
            </div>
          </div>
        </div>

        <div className="text-center">
          <h3 className="text-5xl font-bold mb-16">Additional Services</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-16 gap-y-8 max-w-5xl mx-auto">
            <div className="flex justify-between border-b border-white/10 py-4">
              <span className="text-gray-300 text-lg">Hair Coloring</span>
              <span className="font-bold text-2xl">$45+</span>
            </div>
            <div className="flex justify-between border-b border-white/10 py-4">
              <span className="text-gray-300 text-lg">Hot Towel Treatment</span>
              <span className="font-bold text-2xl">$15</span>
            </div>
            <div className="flex justify-between border-b border-white/10 py-4">
              <span className="text-gray-300 text-lg">Kid's Haircut (Under 12)</span>
              <span className="font-bold text-2xl">$20</span>
            </div>
            <div className="flex justify-between border-b border-white/10 py-4">
              <span className="text-gray-300 text-lg">Scalp Treatment</span>
              <span className="font-bold text-2xl">$25</span>
            </div>
            <div className="flex justify-between border-b border-white/10 py-4">
              <span className="text-gray-300 text-lg">Senior Cut (65+)</span>
              <span className="font-bold text-2xl">$22</span>
            </div>
            <div className="flex justify-between border-b border-white/10 py-4">
              <span className="text-gray-300 text-lg">Facial</span>
              <span className="font-bold text-2xl">$30</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};