import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const storeContent = {
  title: "About Us.",
  description: "Our mission is to redefine men's grooming with precision cuts, global styles, and a culture of respect. Every client should feel at home, and every barber should feel empowered to create."
};

const reviews = [
  {
    id: 1,
    name: 'Adrian Serna',
    initials: 'AS',
    date: 'April, 2025',
    rating: 5,
    text: 'They all are really great babers',
  },
  {
    id: 2,
    name: 'Jerry Moore',
    initials: 'JM',
    date: 'May 18, 2025',
    rating: 5,
    text: 'One of the best haircuts and service. Awesome!',
  },
  {
    id: 3,
    name: 'Justin Stas',
    initials: 'JS',
    date: 'Apr 25, 2025',
    rating: 5,
    text: 'Best barber shop Ive been to in the Charleston Area',
  },
  {
    id: 4,
    name: 'Brett Denaux',
    initials: 'BD',
    date: 'Apr 25, 2025',
    rating: 5,
    text: 'Was great, affordable and friendly.',
  },
  {
    id: 5,
    name: 'Nikki Whitaker',
    initials: 'NW',
    date: 'April, 2025',
    rating: 5,
    text: 'Thank you, Change Up Cuts. I always recieve the best care and quality cuts when I visit.',
  },
  {
    id: 6,
    name: 'Michael Renfroe',
    initials: 'MR',
    date: 'May, 2025',
    rating: 5,
    text: 'An amazing place to get your hair cut, I highly recommend it especially if you"re in the military.',
  },
  {
    id: 7,
    name: 'Tyrone Crocker',
    initials: 'TC',
    date: 'Apr 8, 2025',
    rating: 5,
    text: 'Always a Great Experience. Front Desk Crew Always accommodating and Fransico cant miss. Perfect cut every time.',
  },
];

export const StoreInfo = () => {
  const [currentReview, setCurrentReview] = useState(0);
  const [isHovering, setIsHovering] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 1024);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [nextReview, setNextReview] = useState(0);
  const [touchStart, setTouchStart] = useState(0);
  const [touchEnd, setTouchEnd] = useState(0);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 1024);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    if (isHovering) return;
    
    const interval = setInterval(() => {
      handleReviewChange((currentReview + 1) % reviews.length);
    }, 5000); // Increased to 5 seconds for better UX

    return () => clearInterval(interval);
  }, [currentReview, isHovering]);

  const handleReviewChange = (newIndex: number) => {
    if (newIndex === currentReview || isTransitioning) return;
    
    setIsTransitioning(true);
    setNextReview(newIndex);
    
    // Staggered transition timing
    setTimeout(() => {
      setCurrentReview(newIndex);
      setTimeout(() => {
        setIsTransitioning(false);
      }, 100);
    }, 200);
  };

  const nextReviewHandler = () => {
    const newIndex = (currentReview + 1) % reviews.length;
    handleReviewChange(newIndex);
  };

  const prevReviewHandler = () => {
    const newIndex = (currentReview - 1 + reviews.length) % reviews.length;
    handleReviewChange(newIndex);
  };

  // Touch handlers for mobile swiping
  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.targetTouches[0].clientX);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    
    const distance = touchStart - touchEnd;
    const minSwipeDistance = 50;

    if (Math.abs(distance) > minSwipeDistance) {
      if (distance > 0) {
        // Swiped left - next review
        nextReviewHandler();
      } else {
        // Swiped right - previous review
        prevReviewHandler();
      }
    }

    setTouchStart(0);
    setTouchEnd(0);
  };

  const darkGradient = isMobile
    ? 'linear-gradient(to left, rgba(26,26,26,1) 0%, rgba(26,26,26,0.56) 40%, rgba(26,26,26,0) 100%)'
    : 'linear-gradient(to left, rgba(26,26,26,1) 0%, rgba(26,26,26,0.8) 40%, rgba(26,26,26,0) 100%)';

  const lightGradient = isMobile
    ? 'linear-gradient(to right, rgba(255,255,255,1) 0%, rgba(255,255,255,0.56) 40%, rgba(255,255,255,0) 100%)'
    : 'linear-gradient(to right, rgba(255,255,255,1) 0%, rgba(255,255,255,0.8) 40%, rgba(255,255,255,0) 100%)';

  return (
    <>
      <section className="min-h-[60vh] flex bg-[#1A1A1A]">
        <div className="flex flex-col lg:flex-row w-full">
          <div className="relative w-full lg:w-1/2 min-h-[450px] lg:min-h-full overflow-hidden">
            <div 
              className="absolute inset-0 z-10"
              style={{
                background: darkGradient
              }}
            ></div>
            <div 
              className="absolute inset-0"
              style={{
                backgroundImage: `url('https://i.postimg.cc/sgs5tj3z/Third.webp')`,
                backgroundPosition: 'center',
                backgroundSize: 'cover',
                backgroundRepeat: 'no-repeat',
                filter: 'grayscale(100%)'
              }}
            ></div>
          </div>
          <div className="w-full lg:w-1/2 p-12 flex items-center">
            <div>
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold mb-6 text-white">
                {storeContent.title}
              </h2>
              <p className="text-gray-300 text-lg md:text-xl leading-relaxed mb-8">
                {storeContent.description}
              </p>
              <a 
                href="#about" 
                className="inline-block px-6 py-3 bg-[#D2B48C] text-black font-medium hover:bg-[#C19A6B] transition-colors rounded"
              >
                Learn About Us
              </a>
            </div>
          </div>
        </div>
      </section>

      <section className="min-h-[60vh] flex bg-white">
        <div className="flex flex-col lg:flex-row w-full">
          <div className="w-full lg:w-1/2 p-12 flex items-center">
            <div>
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold mb-6">Our Services</h2>
              <p className="text-gray-700 text-lg md:text-xl leading-relaxed mb-8">
                Experience excellence with our comprehensive range of premium barbering services. From classic cuts to modern styles, we've got you covered.
              </p>
              <a 
                href="#services" 
                className="btn bg-[#1A3C1F] text-white hover:bg-[#152f18] inline-block px-6 py-3 rounded"
              >
                View Services
              </a>
            </div>
          </div>
          <div className="relative w-full lg:w-1/2 min-h-[450px] lg:min-h-full overflow-hidden">
            <div 
              className="absolute inset-0 z-10"
              style={{
                background: lightGradient
              }}
            ></div>
            <div 
              className="absolute inset-0"
              style={{
                backgroundImage: `url('https://i.postimg.cc/hj5qbZwp/IMG-9408.jpg')`,
                backgroundPosition: 'center',
                backgroundSize: 'cover',
                backgroundRepeat: 'no-repeat',
                filter: 'grayscale(100%)'
              }}
            ></div>
          </div>
        </div>
      </section>

      <section className="min-h-[60vh] flex bg-[#1A1A1A] border-t border-gray-800">
        <div className="flex flex-col lg:flex-row w-full">
          <div className="relative w-full lg:w-1/2 min-h-[450px] lg:min-h-full overflow-hidden">
            <div 
              className="absolute inset-0 z-10"
              style={{
                background: darkGradient
              }}
            ></div>
            <div 
              className="absolute inset-0"
              style={{
                backgroundImage: `url('https://i.postimg.cc/9McRYN63/DSC01318-copia-1.jpg')`,
                backgroundPosition: 'center',
                backgroundSize: 'cover',
                backgroundRepeat: 'no-repeat',
                filter: 'grayscale(100%)'
              }}
            ></div>
          </div>
          <div className="w-full lg:w-1/2 p-12 flex items-center">
            <div>
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold mb-6 text-white">Style Gallery</h2>
              <p className="text-gray-300 text-lg md:text-xl leading-relaxed mb-8">
                Every style in our gallery reflects the latest trends and expert craftsmanship.
              </p>
              <a 
                href="#gallery" 
                className="btn bg-[#D2B48C] text-black hover:bg-[#C19A6B] inline-block px-6 py-3 rounded"
              >
                View Gallery
              </a>
            </div>
          </div>
        </div>
      </section>

      <section className="min-h-[60vh] flex bg-white border-t border-gray-100">
        <div className="flex flex-col lg:flex-row w-full">
          {/* Reviews Container - Mobile Optimized */}
          <div className="w-full lg:w-1/2 px-4 py-8 sm:px-6 sm:py-10 md:px-8 md:py-12 lg:px-12 lg:py-12 flex items-center">
            <div className="w-full max-w-lg mx-auto lg:max-w-none">
              {/* Title - Responsive Typography */}
              <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-display font-bold mb-6 lg:mb-8 text-center lg:text-left">
                Our Reviews
              </h2>
              
              {/* Reviews Carousel Container - Mobile Optimized */}
              <div 
                className="relative overflow-hidden touch-pan-y"
                style={{ 
                  height: isMobile ? '340px' : '300px'
                }}
                onMouseEnter={() => setIsHovering(true)}
                onMouseLeave={() => setIsHovering(false)}
                onTouchStart={handleTouchStart}
                onTouchMove={handleTouchMove}
                onTouchEnd={handleTouchEnd}
              >
                {/* Navigation Buttons - Enhanced for Mobile */}
                <button 
                  onClick={prevReviewHandler}
                  disabled={isTransitioning}
                  className={`absolute left-0 top-1/2 -translate-y-1/2 -translate-x-2 sm:-translate-x-4 z-20 p-2 sm:p-3 rounded-full bg-white shadow-lg hover:bg-gray-50 transition-all duration-300 ease-out group disabled:opacity-50 disabled:cursor-not-allowed ${
                    isMobile || isHovering ? 'opacity-100 scale-100' : 'opacity-0 scale-90 md:opacity-0'
                  } hover:shadow-xl hover:scale-110 active:scale-95 touch-manipulation`}
                  aria-label="Previous review"
                >
                  <ChevronLeft className="w-4 h-4 sm:w-5 sm:h-5 text-gray-600 group-hover:text-[#1A3C1F] transition-colors duration-200" />
                </button>
                
                <button 
                  onClick={nextReviewHandler}
                  disabled={isTransitioning}
                  className={`absolute right-0 top-1/2 -translate-y-1/2 translate-x-2 sm:translate-x-4 z-20 p-2 sm:p-3 rounded-full bg-white shadow-lg hover:bg-gray-50 transition-all duration-300 ease-out group disabled:opacity-50 disabled:cursor-not-allowed ${
                    isMobile || isHovering ? 'opacity-100 scale-100' : 'opacity-0 scale-90 md:opacity-0'
                  } hover:shadow-xl hover:scale-110 active:scale-95 touch-manipulation`}
                  aria-label="Next review"
                >
                  <ChevronRight className="w-4 h-4 sm:w-5 sm:h-5 text-gray-600 group-hover:text-[#1A3C1F] transition-colors duration-200" />
                </button>

                {/* Reviews Container - Mobile Optimized */}
                <div className="relative w-full h-full px-6 sm:px-8 md:px-10 lg:px-0">
                  {reviews.map((review, index) => {
                    const isActive = index === currentReview;
                    const isNext = index === nextReview && isTransitioning;
                    const isPrev = index === (currentReview - 1 + reviews.length) % reviews.length;
                    const isAfterNext = index === (currentReview + 1) % reviews.length;
                    
                    return (
                      <div
                        key={review.id}
                        className={`absolute inset-0 transition-all duration-700 ease-[cubic-bezier(0.4,0,0.2,1)] ${
                          isActive && !isTransitioning
                            ? 'opacity-100 translate-x-0 scale-100 z-10' 
                            : isNext && isTransitioning
                            ? 'opacity-0 translate-x-8 scale-95 z-5'
                            : isPrev
                            ? 'opacity-0 -translate-x-8 scale-95 z-5'
                            : isAfterNext
                            ? 'opacity-0 translate-x-12 scale-90 z-0'
                            : 'opacity-0 translate-x-16 scale-90 z-0'
                        }`}
                        style={{
                          transitionDelay: isActive ? '0ms' : '100ms'
                        }}
                      >
                        {/* Review Card - Mobile Optimized */}
                        <div className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-500 ease-out h-full border border-gray-100 hover:border-[#1A3C1F]/20 group hover:scale-[1.02] relative overflow-hidden">
                          {/* Subtle background animation */}
                          <div className="absolute inset-0 bg-gradient-to-br from-[#1A3C1F]/0 via-[#1A3C1F]/0 to-[#1A3C1F]/2 opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
                          
                          {/* Card Content - Mobile Responsive */}
                          <div className="relative z-10 p-4 sm:p-5 md:p-6 h-full flex flex-col">
                            {/* Header with avatar and info */}
                            <div className={`flex items-center gap-3 sm:gap-4 mb-3 sm:mb-4 transition-all duration-500 ease-out ${
                              isActive ? 'translate-y-0 opacity-100' : 'translate-y-2 opacity-0'
                            }`}
                            style={{ transitionDelay: isActive ? '200ms' : '0ms' }}>
                              <div className="w-10 h-10 sm:w-12 sm:h-12 bg-[#1A3C1F] rounded-full flex items-center justify-center text-white font-bold text-sm sm:text-lg shadow-md group-hover:shadow-lg group-hover:scale-110 transition-all duration-300 flex-shrink-0">
                                {review.initials}
                              </div>
                              <div className="min-w-0 flex-1">
                                <div className="font-semibold text-gray-900 text-base sm:text-lg group-hover:text-[#1A3C1F] transition-colors duration-300 truncate">
                                  {review.name}
                                </div>
                                <div className="text-xs sm:text-sm text-gray-700">
                                  {review.date}
                                </div>
                              </div>
                            </div>
                            
                            {/* Rating */}
                            <div className={`flex items-center mb-3 sm:mb-4 transition-all duration-500 ease-out ${
                              isActive ? 'translate-y-0 opacity-100' : 'translate-y-2 opacity-0'
                            }`}
                            style={{ transitionDelay: isActive ? '300ms' : '0ms' }}>
                              <div className="text-[#1A3C1F] font-bold text-lg sm:text-xl mr-2 sm:mr-3 group-hover:scale-110 transition-transform duration-300">
                                {review.rating}.0
                              </div>
                              <div className="flex text-yellow-400 gap-0.5 sm:gap-1">
                                {[...Array(5)].map((_, i) => (
                                  <span 
                                    key={i} 
                                    className="text-base sm:text-lg group-hover:scale-110 transition-transform duration-300"
                                    style={{ transitionDelay: `${50 * i}ms` }}
                                  >
                                    ★
                                  </span>
                                ))}
                              </div>
                              <img 
                                src="https://www.google.com/favicon.ico" 
                                alt="Google" 
                                className="w-4 h-4 sm:w-5 sm:h-5 ml-2 sm:ml-3 opacity-70 group-hover:opacity-100 transition-opacity duration-300 flex-shrink-0" 
                              />
                            </div>
                            
                            {/* Review text - Flexible height */}
                            <div className={`flex-1 transition-all duration-500 ease-out ${
                              isActive ? 'translate-y-0 opacity-100' : 'translate-y-2 opacity-0'
                            }`}
                            style={{ transitionDelay: isActive ? '400ms' : '0ms' }}>
                              <p className="text-gray-700 text-sm sm:text-base md:text-lg leading-relaxed mb-3 sm:mb-4 group-hover:text-gray-900 transition-colors duration-300 line-clamp-4 sm:line-clamp-none">
                                "{review.text}"
                              </p>
                              <div className="text-xs text-gray-600 group-hover:text-gray-700 transition-colors duration-300 mt-auto">
                                powered by Google
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
              
              {/* Enhanced Dots Navigation - Mobile Optimized */}
              <div className="flex justify-center mt-6 sm:mt-8 space-x-2 sm:space-x-3 px-4">
                {reviews.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => handleReviewChange(index)}
                    disabled={isTransitioning}
                    className={`relative transition-all duration-500 ease-out hover:scale-125 disabled:cursor-not-allowed touch-manipulation ${
                      index === currentReview 
                        ? 'w-6 sm:w-8 h-2.5 sm:h-3 bg-[#1A3C1F] rounded-full shadow-lg' 
                        : 'w-2.5 sm:w-3 h-2.5 sm:h-3 bg-gray-600 rounded-full hover:bg-gray-700'
                    }`}
                    aria-label={`Go to review ${index + 1}`}
                  >
                    {index === currentReview && (
                      <div className="absolute inset-0 bg-[#1A3C1F] rounded-full animate-pulse opacity-30"></div>
                    )}
                  </button>
                ))}
              </div>

              {/* Mobile Swipe Hint */}
              {isMobile && (
                <div className="text-center mt-4">
                  <p className="text-xs text-gray-600">Swipe left or right to browse reviews</p>
                </div>
              )}
            </div>
          </div>
          
          {/* Image Section - Hidden on mobile for better focus */}
          <div className="relative w-full lg:w-1/2 min-h-[300px] lg:min-h-full overflow-hidden hidden lg:block">
            <div 
              className="absolute inset-0 z-10"
              style={{
                background: lightGradient
              }}
            ></div>
            <div 
              className="absolute inset-0"
              style={{
                backgroundImage: `url('https://i.postimg.cc/fLs2jDWw/DSC01360-1.jpg')`,
                backgroundPosition: 'center',
                backgroundSize: 'cover',
                backgroundRepeat: 'no-repeat',
                filter: 'grayscale(100%)'
              }}
            ></div>
          </div>
        </div>
      </section>
    </>
  );
};