import React from 'react';
import { MapPin, Phone, Clock, Mail } from 'lucide-react';

export const Contact = () => {
  const barbershopHours = [
    { day: 'Monday - Thursday', hours: '10:00 AM - 7:30 PM' },
    { day: 'Friday - Saturday', hours: '9:00 AM - 8:00 PM' },
    { day: 'Sunday', hours: '9:00 AM - 4:00 PM' },
  ];

  const beautyCenterHours = [
    { day: 'Monday - Thursday', hours: '10:00 AM - 5:00 PM' },
    { day: 'Friday - Saturday', hours: '9:00 AM - 6:00 PM' },
    { day: 'Sunday', hours: 'CLOSED' },
  ];

  return (
    <section id="contact" className="section bg-white">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="section-title font-display text-barber-primary">Contact & Location</h2>
          <div className="w-24 h-1 bg-barber-secondary mx-auto my-4"></div>
          <p className="section-subtitle text-gray-700 max-w-2xl mx-auto">
            Visit us at our shop or get in touch to book your appointment. Walk-ins are always welcome!
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <div className="rounded-lg overflow-hidden h-64 md:h-full">
              <div className="w-full h-full bg-gray-300 flex items-center justify-center">
                <div className="text-center p-8">
                  <MapPin className="w-12 h-12 text-barber-secondary mx-auto mb-4" />
                  <p className="font-medium text-gray-800">
                    Map will be displayed here
                  </p>
                  <a 
                    href="https://www.google.com/maps/place/Change+Up+Cuts+Barbershop+%26+Beauty+Center/@32.904714,-80.0197043,17.76z/data=!4m15!1m8!3m7!1s0x88fe638293e4cc43:0xf2a2e771d0f0acbb!2s5900+Rivers+Ave+Suite+D-4,+North+Charleston,+SC+29406!3b1!8m2!3d32.9049645!4d-80.0181646!16s%2Fg%2F11pvcvbq4y!3m5!1s0x88fe636c08e7b0a3:0x80d92ec6413760e4!8m2!3d32.904006!4d-80.0181136!16s%2Fg%2F11q8vcl_gr?entry=ttu&g_ep=EgoyMDI1MDYwMi4wIKXMDSoASAFQAw%3D%3D"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-gray-700 mt-2 hover:text-barber-secondary transition-colors"
                  >
                    5900 Rivers Avenue, Suite D-4, North Charleston, SC 29406
                  </a>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-8">
            <div id="booking" className="p-6 border border-gray-200 rounded-lg">
              <h3 className="text-2xl font-display font-bold mb-4">Book Your Appointment</h3>
              <p className="mb-6 text-gray-700">
                Choose your preferred time and service. Online booking ensures you'll get the slot that works for you.
              </p>
              <a
                href="https://getsquire.com/booking/book/change-up-cuts-barbershop-and-beauty-center-north-charleston/barber/any/services"
                target="_blank"
                rel="noopener noreferrer"
                className="block w-full py-3 bg-barber-secondary hover:bg-barber-accent text-center text-white font-bold rounded transition-colors"
              >
                Book Online
              </a>
              <div className="text-center mt-4 text-gray-700">
                <p>Barbershop: <a href="tel:+18437894430" className="text-barber-secondary font-medium">(843) 789-4430</a></p>
                <p>Beauty Center: <a href="tel:+18437894360" className="text-barber-secondary font-medium">(843) 789-4360</a></p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex items-start space-x-4">
                <div className="rounded-full bg-barber-secondary/10 p-3">
                  <MapPin className="h-6 w-6 text-barber-secondary" />
                </div>
                <div>
                  <h3 className="font-bold text-lg mb-1">Address</h3>
                  <a 
                    href="https://www.google.com/maps/place/Change+Up+Cuts+Barbershop+%26+Beauty+Center/@32.904714,-80.0197043,17.76z/data=!4m15!1m8!3m7!1s0x88fe638293e4cc43:0xf2a2e771d0f0acbb!2s5900+Rivers+Ave+Suite+D-4,+North+Charleston,+SC+29406!3b1!8m2!3d32.9049645!4d-80.0181646!16s%2Fg%2F11pvcvbq4y!3m5!1s0x88fe636c08e7b0a3:0x80d92ec6413760e4!8m2!3d32.904006!4d-80.0181136!16s%2Fg%2F11q8vcl_gr?entry=ttu&g_ep=EgoyMDI1MDYwMi4wIKXMDSoASAFQAw%3D%3D"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-700 hover:text-barber-secondary transition-colors"
                  >
                    5900 Rivers Avenue <br />
                    Suite D-4 <br />
                    North Charleston, SC 29406
                  </a>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="rounded-full bg-barber-secondary/10 p-3">
                  <Phone className="h-6 w-6 text-barber-secondary" />
                </div>
                <div>
                  <h3 className="font-bold text-lg mb-1">Contact</h3>
                  <p className="text-gray-700">
                    Barbershop:<br />
                    <a href="tel:+18437894430" className="hover:text-barber-secondary">(843) 789-4430</a>
                  </p>
                  <p className="text-gray-700 mt-2">
                    Beauty Center:<br />
                    <a href="tel:+18437894360" className="hover:text-barber-secondary">(843) 789-4360</a>
                  </p>
                  <p className="text-gray-700 mt-2">
                    <a href="mailto:info@changeupcuts.com" className="hover:text-barber-secondary">info@changeupcuts.com</a>
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="border border-gray-200 rounded-lg overflow-hidden">
                <div className="flex items-center space-x-4 p-4 border-b border-gray-200 bg-gray-50">
                  <Clock className="h-5 w-5 text-barber-secondary" />
                  <h3 className="font-bold">Barbershop Hours</h3>
                </div>
                <div className="divide-y divide-gray-200">
                  {barbershopHours.map((item, index) => (
                    <div key={index} className="flex justify-between py-2 px-4">
                      <span className="font-medium">{item.day}</span>
                      <span>{item.hours}</span>
                    </div>
                  ))}
                  <div className="py-2 px-4 bg-barber-secondary/5 text-center text-sm font-medium text-barber-secondary">
                    Walk-ins Always Welcome
                  </div>
                </div>
              </div>

              <div className="border border-gray-200 rounded-lg overflow-hidden">
                <div className="flex items-center space-x-4 p-4 border-b border-gray-200 bg-gray-50">
                  <Clock className="h-5 w-5 text-barber-secondary" />
                  <h3 className="font-bold">Beauty Center Hours</h3>
                </div>
                <div className="divide-y divide-gray-200">
                  {beautyCenterHours.map((item, index) => (
                    <div key={index} className="flex justify-between py-2 px-4">
                      <span className="font-medium">{item.day}</span>
                      <span>{item.hours}</span>
                    </div>
                  ))}
                  <div className="py-2 px-4 bg-barber-secondary/5 text-center text-sm font-medium text-barber-secondary">
                    Walk-ins Always Welcome
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};