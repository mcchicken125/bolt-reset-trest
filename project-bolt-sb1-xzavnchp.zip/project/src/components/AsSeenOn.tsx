import React from 'react';

export const AsSeenOn = () => {
  const logos = [
    {
      src: "https://i.postimg.cc/Mph0pXyv/NENE-1.png",
      alt: "Nene Media Spanish language news outlet logo - featured Change Up Cuts in community business spotlight",
      link: "https://nuestroestado.com/latino-feidin-santana-opens-new-business-with-a-community-centered-vision/"
    },
    {
      src: "https://i.postimg.cc/x1K8Ldwk/informador-1.png",
      alt: "El Informador Hispanic community newspaper logo - covered Change Up Cuts opening and community impact",
      link: "https://www.elinformador.us/breaking-news/change-up-cuts-mas-que-un-cambio-de-estilo-es-un-espacio-que-opta-por-un-impacto-social/?fbclid=IwAR1m0A-6-4pvKdaCB8xzxxc1YDAqha53ilekJ8IyoM0Zt_q4hNL-GiYxKww"
    },
    {
      src: "https://i.postimg.cc/66kGZF8m/citypaper.png",
      alt: "Charleston City Paper local news publication logo - featured Change Up Cuts in business and community coverage",
      link: "https://charlestoncitypaper.com/feidin-santanas-new-barbershop-about-restoring-community-6-years-after-filming-shooting-of-walter-scott/"
    },
    {
      src: "https://i.postimg.cc/sfY3nLn8/PC-1.png",
      alt: "The Post and Courier Charleston's primary newspaper logo - covered Change Up Cuts business opening and community involvement"
    },
    {
      src: "https://i.postimg.cc/W1CRpmWg/wcbs.png",
      alt: "WCSC Live 5 News Charleston television station logo - featured Change Up Cuts in local business news segment",
      link: "https://www.live5news.com/2021/06/12/man-opens-new-community-space-barber-shop-n-charleston/"
    }
  ];

  return (
    <section 
      className="bg-[#1A1A1A] py-12 pb-8" 
      role="region" 
      aria-labelledby="media-heading"
    >
      <div className="container mx-auto px-4">
        <h2 id="media-heading" className="text-center text-4xl text-gray-300 mb-10">
          As Seen On
        </h2>
        
        <div 
          className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8 place-items-center"
          role="list"
          aria-label="Media outlets that have featured Change Up Cuts"
        >
          {logos.map((logo, index) => (
            <div 
              key={index} 
              className="w-full max-w-[150px] h-16 md:h-20 opacity-70 hover:opacity-100 transition-opacity"
              role="listitem"
            >
              {logo.link ? (
                <a 
                  href={logo.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full h-full hover:scale-105 transition-transform"
                  aria-label={`Read article: ${logo.alt} - opens in new window`}
                >
                  <img
                    src={logo.src}
                    alt={logo.alt}
                    className="w-full h-full object-contain"
                    loading="lazy"
                  />
                </a>
              ) : (
                <img
                  src={logo.src}
                  alt={logo.alt}
                  className="w-full h-full object-contain"
                  loading="lazy"
                />
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};