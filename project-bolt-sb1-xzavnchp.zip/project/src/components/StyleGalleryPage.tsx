import React, { useState, useEffect } from 'react';
import { Filter, Grid, List } from 'lucide-react';
import { MetaTags } from './MetaTags';

export const StyleGalleryPage = () => {
  const [filter, setFilter] = useState('all');
  const [viewMode, setViewMode] = useState<'grid' | 'masonry'>('grid');
  const [selectedImage, setSelectedImage] = useState<number | null>(null);

  const galleryImages = [
    {
      id: 1,
      url: 'https://i.postimg.cc/nzT9Qrk9/one.webp',
      alt: 'Professional beard styling and haircut combination',
      category: 'beards',
      title: 'Beard & Hair Combo',
      description: 'Complete grooming package featuring precision haircut with expert beard styling'
    },
    {
      id: 2,
      url: 'https://i.postimg.cc/QxKVj0RT/two.webp',
      alt: 'Precision fade haircut being performed',
      category: 'fades',
      title: 'Precision Fade Execution',
      description: 'Expert barber demonstrating advanced fade cutting technique with attention to detail'
    },
    {
      id: 3,
      url: 'https://i.postimg.cc/k5N5v8dk/kidcut.webp',
      alt: 'Creative children\'s haircut with modern styling',
      category: 'kids',
      title: 'Creative Kids Cuts',
      description: 'Fun and stylish haircuts designed specifically for children with patience and care'
    },
    {
      id: 4,
      url: 'https://i.postimg.cc/fTKpC8m9/one.webp',
      alt: 'Professional beard trimming and shaping service',
      category: 'beards',
      title: 'Professional Beard Grooming',
      description: 'Expert beard trimming, shaping, and styling to complement your facial features'
    },
    {
      id: 5,
      url: 'https://i.postimg.cc/13X6MyR9/fade.jpg',
      alt: 'Classic low fade haircut technique',
      category: 'fades',
      title: 'Classic Low Fade',
      description: 'Timeless low fade technique that creates clean, professional lines'
    },
    {
      id: 6,
      url: 'https://i.postimg.cc/vZv8NMZp/Second1.webp',
      alt: 'Detailed haircut finishing work',
      category: 'haircuts',
      title: 'Precision Detailing',
      description: 'Meticulous finishing touches that make the difference in every haircut'
    },
    {
      id: 7,
      url: 'https://i.postimg.cc/bJrSxwnK/4.webp',
      alt: 'Professional hair coloring and highlighting service',
      category: 'coloring',
      title: 'Hair Color & Highlights',
      description: 'Professional hair coloring services with custom color matching and highlighting'
    },
    {
      id: 8,
      url: 'https://i.postimg.cc/pd45BtBr/10.webp',
      alt: 'Beauty salon hair styling service',
      category: 'beauty',
      title: 'Hair Styling Services',
      description: 'Professional hair styling for special occasions and everyday elegance'
    },
    {
      id: 9,
      url: 'https://i.postimg.cc/cCvqPznr/white.webp',
      alt: 'Multicultural barbering expertise',
      category: 'haircuts',
      title: 'Multicultural Expertise',
      description: 'Skilled in cutting and styling all hair types and textures from diverse backgrounds'
    },
    {
      id: 10,
      url: 'https://i.postimg.cc/sgs5tj3z/Third.webp',
      alt: 'Professional gentleman\'s haircut service',
      category: 'haircuts',
      title: 'Gentleman\'s Classic Cut',
      description: 'Traditional and modern haircuts tailored for the professional gentleman'
    },
    {
      id: 11,
      url: 'https://i.postimg.cc/xCcvt6nb/Fourth.webp',
      alt: 'Precision fade haircut being performed',
      category: 'fades',
      title: 'Precision Fade Execution',
      description: 'Traditional and modern haircuts tailored for the professional gentleman'
    },
    {
      id: 12,
      url: 'https://i.postimg.cc/fLs2jDWw/DSC01360_1.jpg',
      alt: 'Master barber showcasing traditional barbering skills',
      category: 'traditional',
      title: 'Traditional Barbering',
      description: 'Classic barbering techniques passed down through generations of master barbers'
    }
  ];

  const categories = [
    { id: 'all', label: 'All Services', count: galleryImages.length },
    { id: 'haircuts', label: 'Haircuts', count: galleryImages.filter(img => img.category === 'haircuts').length },
    { id: 'fades', label: 'Fades & Tapers', count: galleryImages.filter(img => img.category === 'fades').length },
    { id: 'beards', label: 'Beard Grooming', count: galleryImages.filter(img => img.category === 'beards').length },
    { id: 'kids', label: 'Kids Cuts', count: galleryImages.filter(img => img.category === 'kids').length },
    { id: 'beauty', label: 'Beauty Services', count: galleryImages.filter(img => img.category === 'beauty').length },
    { id: 'coloring', label: 'Hair Coloring', count: galleryImages.filter(img => img.category === 'coloring').length },
    { id: 'traditional', label: 'Traditional Cuts', count: galleryImages.filter(img => img.category === 'traditional').length }
  ];

  const filteredImages = filter === 'all' 
    ? galleryImages 
    : galleryImages.filter(img => img.category === filter);

  const openLightbox = (imageId: number) => {
    setSelectedImage(imageId);
    document.body.style.overflow = 'hidden';
  };

  const closeLightbox = () => {
    setSelectedImage(null);
    document.body.style.overflow = '';
  };

  const navigateLightbox = (direction: 'prev' | 'next') => {
    if (selectedImage === null) return;
    
    const currentIndex = filteredImages.findIndex(img => img.id === selectedImage);
    let newIndex;
    
    if (direction === 'prev') {
      newIndex = currentIndex > 0 ? currentIndex - 1 : filteredImages.length - 1;
    } else {
      newIndex = currentIndex < filteredImages.length - 1 ? currentIndex + 1 : 0;
    }
    
    setSelectedImage(filteredImages[newIndex].id);
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (selectedImage === null) return;
      
      switch (e.key) {
        case 'Escape':
          closeLightbox();
          break;
        case 'ArrowLeft':
          navigateLightbox('prev');
          break;
        case 'ArrowRight':
          navigateLightbox('next');
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedImage]);

  const selectedImageData = selectedImage ? galleryImages.find(img => img.id === selectedImage) : null;

  return (
    <div className="bg-white">
      <MetaTags
        title="Style Gallery"
        description="Browse our comprehensive gallery of haircuts, styles, and grooming services. See the quality craftsmanship and diverse expertise of Change Up Cuts Barbershop and Beauty Center."
        keywords="haircut gallery, barbershop styles, fade cuts, beard grooming, Charleston barber gallery, hair styling examples, hair coloring, traditional barbering"
        type="article"
        image="https://i.postimg.cc/xCcvt6nb/Fourth.webp"
        twitterCard="summary_large_image"
        author="Change Up Cuts Team"
        publishedTime="2021-07-01T00:00:00Z"
        modifiedTime={new Date().toISOString()}
        canonicalPath="/gallery"
      />
      
      {/* Hero Section */}
      <section 
        className="relative min-h-[60vh] md:min-h-[70vh] flex items-center justify-center"
        style={{
          backgroundImage: 'url("https://i.postimg.cc/sgs5tj3z/Third.webp")',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: window.innerWidth < 768 ? 'scroll' : 'fixed'
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/70 to-black/80"></div>
        
        <div className="relative z-10 container mx-auto px-6 pt-16 md:pt-20 text-center">
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-display font-bold text-white mb-4 md:mb-6 leading-tight">
            Style Gallery
          </h1>
          <p className="text-lg md:text-xl lg:text-2xl text-white/90 max-w-3xl mx-auto mb-6 md:mb-8 leading-relaxed px-4">
            Discover our craftsmanship through our comprehensive gallery of cuts, styles, and transformations
          </p>
          <div className="w-16 md:w-24 h-1 bg-[#1A3C1F] mx-auto"></div>
          <p className="text-white/70 text-base md:text-lg mt-8 md:mt-12 tracking-wide font-light">¡HABLAMOS ESPAÑOL!</p>
        </div>
      </section>

      {/* Gallery Controls */}
      <section className="py-8 md:py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-col gap-6 mb-6 md:mb-8">
            {/* Category Filters */}
            <div className="w-full">
              <div className="flex flex-wrap justify-center gap-2 md:gap-3">
                {categories.map(category => (
                  <button
                    key={category.id}
                    onClick={() => setFilter(category.id)}
                    className={`px-3 py-2 md:px-4 md:py-2 rounded-full text-xs md:text-sm font-medium transition-all duration-300 whitespace-nowrap ${
                      filter === category.id
                        ? 'bg-[#1A3C1F] text-white shadow-lg'
                        : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200'
                    }`}
                  >
                    {category.label} ({category.count})
                  </button>
                ))}
              </div>
            </div>

            {/* View Mode Toggle - Hidden on mobile, shown on larger screens */}
            <div className="hidden md:flex items-center justify-center gap-4">
              <span className="text-gray-600 font-medium">View:</span>
              <div className="flex bg-white rounded-lg border border-gray-200 p-1">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2 rounded transition-colors ${
                    viewMode === 'grid' ? 'bg-[#1A3C1F] text-white' : 'text-gray-600 hover:text-[#1A3C1F]'
                  }`}
                >
                  <Grid className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setViewMode('masonry')}
                  className={`p-2 rounded transition-colors ${
                    viewMode === 'masonry' ? 'bg-[#1A3C1F] text-white' : 'text-gray-600 hover:text-[#1A3C1F]'
                  }`}
                >
                  <List className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Results Count */}
          <div className="text-center mb-6 md:mb-8">
            <p className="text-gray-600 text-sm md:text-base px-4">
              Showing {filteredImages.length} {filteredImages.length === 1 ? 'style' : 'styles'}
              {filter !== 'all' && ` in ${categories.find(c => c.id === filter)?.label}`}
            </p>
          </div>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="py-8 md:py-12">
        <div className="container mx-auto px-4">
          <div className={`grid gap-4 md:gap-6 ${
            viewMode === 'grid' 
              ? 'grid-cols-2 md:grid-cols-3 lg:grid-cols-4' 
              : 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'
          }`}>
            {filteredImages.map((image, index) => (
              <div 
                key={image.id}
                className={`group relative overflow-hidden rounded-lg bg-white shadow-md hover:shadow-xl transition-all duration-500 cursor-pointer touch-manipulation ${
                  viewMode === 'masonry' && index % 3 === 1 ? 'lg:mt-8' : ''
                }`}
                onClick={() => openLightbox(image.id)}
              >
                <div className={`relative overflow-hidden ${
                  viewMode === 'grid' ? 'aspect-square' : 'aspect-[4/5]'
                }`}>
                  <img 
                    src={image.url} 
                    alt={image.alt}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  
                  {/* Overlay Content - Better mobile visibility */}
                  <div className="absolute bottom-0 left-0 right-0 p-3 md:p-4 text-white transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                    <h3 className="font-bold text-sm md:text-lg mb-1">{image.title}</h3>
                    <p className="text-xs md:text-sm text-white/90 line-clamp-2">{image.description}</p>
                  </div>

                  {/* Category Badge - Mobile optimized */}
                  <div className="absolute top-2 md:top-3 left-2 md:left-3 px-2 py-1 bg-[#1A3C1F]/90 text-white text-xs font-medium rounded-full backdrop-blur-sm">
                    {categories.find(c => c.id === image.category)?.label}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredImages.length === 0 && (
            <div className="text-center py-12 md:py-16 px-4">
              <Filter className="w-12 md:w-16 h-12 md:h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg md:text-xl font-bold text-gray-600 mb-2">No styles found</h3>
              <p className="text-gray-500 text-sm md:text-base">Try selecting a different category to see more styles.</p>
            </div>
          )}
        </div>
      </section>

      {/* Lightbox - Mobile optimized */}
      {selectedImage && selectedImageData && (
        <div className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-2 md:p-4">
          <button
            onClick={closeLightbox}
            className="absolute top-4 right-4 text-white hover:text-gray-300 text-3xl md:text-2xl z-10 w-10 h-10 md:w-auto md:h-auto flex items-center justify-center"
          >
            ✕
          </button>
          
          <button
            onClick={() => navigateLightbox('prev')}
            className="absolute left-2 md:left-4 top-1/2 -translate-y-1/2 text-white hover:text-gray-300 text-4xl md:text-3xl z-10 w-12 h-12 md:w-auto md:h-auto flex items-center justify-center bg-black/30 md:bg-transparent rounded-full md:rounded-none"
          >
            ‹
          </button>
          
          <button
            onClick={() => navigateLightbox('next')}
            className="absolute right-2 md:right-4 top-1/2 -translate-y-1/2 text-white hover:text-gray-300 text-4xl md:text-3xl z-10 w-12 h-12 md:w-auto md:h-auto flex items-center justify-center bg-black/30 md:bg-transparent rounded-full md:rounded-none"
          >
            ›
          </button>

          <div className="max-w-full md:max-w-4xl max-h-full flex flex-col items-center px-4">
            <img
              src={selectedImageData.url}
              alt={selectedImageData.alt}
              className="max-w-full max-h-[70vh] md:max-h-[80vh] object-contain"
            />
            <div className="text-center mt-3 md:mt-4 text-white max-w-lg md:max-w-none px-2">
              <h3 className="text-lg md:text-xl font-bold mb-1 md:mb-2">{selectedImageData.title}</h3>
              <p className="text-gray-300 text-sm md:text-base">{selectedImageData.description}</p>
            </div>
          </div>
        </div>
      )}

      {/* CTA Section */}
      <section className="bg-[#1A3C1F] py-12 md:py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl lg:text-5xl text-white font-bold mb-6 md:mb-8 px-4">Ready for Your Style Transformation?</h2>
          <p className="text-lg md:text-xl text-white/90 mb-6 md:mb-8 max-w-2xl mx-auto px-4">
            Book your appointment today and let our expert team create your perfect look.
          </p>
          <a 
            href="https://getsquire.com/booking/book/change-up-cuts-barbershop-and-beauty-center-north-charleston/barber/any/services"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block px-6 md:px-8 py-3 md:py-4 bg-[#D2B48C] text-black text-base md:text-lg font-medium hover:bg-[#C19A6B] transition-all rounded-md shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 touch-manipulation"
          >
            Book Now
          </a>
        </div>
      </section>
    </div>
  );
};