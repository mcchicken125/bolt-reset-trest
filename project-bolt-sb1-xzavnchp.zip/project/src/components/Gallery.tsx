import React, { useState } from 'react';

const galleryImages = [
  {
    id: 1,
    url: 'https://images.pexels.com/photos/2061820/pexels-photo-2061820.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    alt: 'Classic mens haircut',
    category: 'haircut'
  },
  {
    id: 2,
    url: 'https://images.pexels.com/photos/1805600/pexels-photo-1805600.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    alt: 'Beard trim',
    category: 'beard'
  },
  {
    id: 3,
    url: 'https://images.pexels.com/photos/1319461/pexels-photo-1319461.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    alt: 'Modern fade haircut',
    category: 'haircut'
  },
  {
    id: 4,
    url: 'https://images.pexels.com/photos/3998429/pexels-photo-3998429.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    alt: 'Barber working on client',
    category: 'service'
  },
  {
    id: 5,
    url: 'https://images.pexels.com/photos/3998414/pexels-photo-3998414.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    alt: 'Hair styling',
    category: 'haircut'
  },
  {
    id: 6,
    url: 'https://images.pexels.com/photos/2068198/pexels-photo-2068198.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    alt: 'Detailed haircut',
    category: 'haircut'
  },
  {
    id: 7,
    url: 'https://images.pexels.com/photos/997333/pexels-photo-997333.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    alt: 'Barbershop interior',
    category: 'shop'
  },
  {
    id: 8,
    url: 'https://images.pexels.com/photos/2034522/pexels-photo-2034522.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    alt: 'Straight razor shave',
    category: 'service'
  },
];

export const Gallery = () => {
  const [filter, setFilter] = useState('all');
  
  const filteredImages = filter === 'all' 
    ? galleryImages 
    : galleryImages.filter(img => img.category === filter);

  return (
    <section id="gallery" className="section bg-white">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="section-title font-display text-barber-primary">Our Work</h2>
          <div className="w-24 h-1 bg-barber-secondary mx-auto my-4"></div>
          <p className="section-subtitle text-gray-700 max-w-2xl mx-auto">
            Browse our gallery of haircuts and styles. We take pride in our craft and the satisfaction of our clients.
          </p>
        </div>

        <div className="flex justify-center mb-8 space-x-2 flex-wrap">
          <button
            onClick={() => setFilter('all')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              filter === 'all' 
                ? 'bg-barber-secondary text-white' 
                : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilter('haircut')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              filter === 'haircut' 
                ? 'bg-barber-secondary text-white' 
                : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
            }`}
          >
            Haircuts
          </button>
          <button
            onClick={() => setFilter('beard')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              filter === 'beard' 
                ? 'bg-barber-secondary text-white' 
                : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
            }`}
          >
            Beard Trims
          </button>
          <button
            onClick={() => setFilter('service')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              filter === 'service' 
                ? 'bg-barber-secondary text-white' 
                : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
            }`}
          >
            Services
          </button>
          <button
            onClick={() => setFilter('shop')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              filter === 'shop' 
                ? 'bg-barber-secondary text-white' 
                : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
            }`}
          >
            Shop
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {filteredImages.map((image) => (
            <div 
              key={image.id} 
              className="relative group overflow-hidden rounded-lg aspect-square"
            >
              <img 
                src={image.url} 
                alt={image.alt}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                <div className="p-4 w-full">
                  <p className="text-white font-medium">{image.alt}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-10">
          <a 
            href="#booking" 
            className="btn btn-primary"
          >
            Book Your Appointment
          </a>
        </div>
      </div>
    </section>
  );
};