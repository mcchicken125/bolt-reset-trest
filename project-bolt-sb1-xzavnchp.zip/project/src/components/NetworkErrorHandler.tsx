import React, { useState, useEffect, useRef } from 'react';
import { Wifi, WifiOff, RefreshCw, AlertTriangle } from 'lucide-react';

interface NetworkErrorHandlerProps {
  children: React.ReactNode;
}

export const NetworkErrorHandler: React.FC<NetworkErrorHandlerProps> = ({ children }) => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [showOfflineMessage, setShowOfflineMessage] = useState(false);
  const [reconnectAttempts, setReconnectAttempts] = useState(0);
  const [lastOfflineTime, setLastOfflineTime] = useState<number | null>(null);
  const reconnectTimeoutRef = useRef<number | null>(null);
  const offlineTimeoutRef = useRef<number | null>(null);

  const maxReconnectAttempts = 5;
  const reconnectDelay = 5000; // 5 seconds

  useEffect(() => {
    const handleOnline = () => {
      console.log('Network: Online');
      setIsOnline(true);
      setShowOfflineMessage(false);
      setReconnectAttempts(0);
      setLastOfflineTime(null);
      
      // Clear any pending timeouts
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
        reconnectTimeoutRef.current = null;
      }
      if (offlineTimeoutRef.current) {
        clearTimeout(offlineTimeoutRef.current);
        offlineTimeoutRef.current = null;
      }
    };

    const handleOffline = () => {
      console.log('Network: Offline');
      setIsOnline(false);
      setLastOfflineTime(Date.now());
      
      // Show offline message after a short delay to avoid flashing
      offlineTimeoutRef.current = window.setTimeout(() => {
        setShowOfflineMessage(true);
      }, 2000);
    };

    // Enhanced online/offline detection
    const checkConnection = async () => {
      try {
        // Try to fetch a small resource to verify actual connectivity
        const response = await fetch('/favicon.ico', {
          method: 'HEAD',
          cache: 'no-cache'
        });
        return response.ok;
      } catch {
        return false;
      }
    };

    // Periodic connection check
    const connectionCheckInterval = setInterval(async () => {
      const actuallyOnline = await checkConnection();
      
      if (actuallyOnline !== isOnline) {
        if (actuallyOnline) {
          handleOnline();
        } else {
          handleOffline();
        }
      }
    }, 10000); // Check every 10 seconds

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Cleanup function
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(connectionCheckInterval);
      
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (offlineTimeoutRef.current) {
        clearTimeout(offlineTimeoutRef.current);
      }
    };
  }, [isOnline]);

  const handleRetry = () => {
    if (reconnectAttempts >= maxReconnectAttempts) {
      window.location.reload();
      return;
    }

    setReconnectAttempts(prev => prev + 1);
    
    // Show attempting to reconnect
    setShowOfflineMessage(false);
    
    reconnectTimeoutRef.current = window.setTimeout(() => {
      // Check if we're actually online
      if (navigator.onLine) {
        setIsOnline(true);
        setShowOfflineMessage(false);
        setReconnectAttempts(0);
      } else {
        setShowOfflineMessage(true);
      }
    }, reconnectDelay);
  };

  const getOfflineDuration = () => {
    if (!lastOfflineTime) return '';
    
    const duration = Math.floor((Date.now() - lastOfflineTime) / 1000);
    if (duration < 60) return `${duration}s`;
    if (duration < 3600) return `${Math.floor(duration / 60)}m`;
    return `${Math.floor(duration / 3600)}h`;
  };

  // Show full offline screen for extended offline periods or critical failures
  if (showOfflineMessage && (!isOnline || reconnectAttempts >= maxReconnectAttempts)) {
    return (
      <div className="fixed inset-0 bg-white z-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full text-center">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
            {reconnectAttempts >= maxReconnectAttempts ? (
              <AlertTriangle className="w-8 h-8 text-red-600" />
            ) : (
              <WifiOff className="w-8 h-8 text-gray-600" />
            )}
          </div>
          
          <h1 className="text-2xl font-bold text-gray-900 mb-4">
            {reconnectAttempts >= maxReconnectAttempts 
              ? 'Connection Failed' 
              : 'No Internet Connection'
            }
          </h1>
          
          <p className="text-gray-600 mb-6">
            {reconnectAttempts >= maxReconnectAttempts 
              ? 'Unable to establish a stable connection after multiple attempts.'
              : 'Please check your internet connection and try again.'
            }
          </p>

          {lastOfflineTime && (
            <p className="text-sm text-gray-500 mb-6">
              Offline for: {getOfflineDuration()}
            </p>
          )}

          <button
            onClick={handleRetry}
            disabled={reconnectAttempts > 0 && reconnectAttempts < maxReconnectAttempts}
            className="inline-flex items-center gap-2 px-6 py-3 bg-[#1A3C1F] text-white rounded-lg hover:bg-[#152f18] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <RefreshCw className={`w-4 h-4 ${reconnectAttempts > 0 && reconnectAttempts < maxReconnectAttempts ? 'animate-spin' : ''}`} />
            {reconnectAttempts >= maxReconnectAttempts 
              ? 'Reload Page' 
              : reconnectAttempts > 0 
                ? `Retrying... (${reconnectAttempts}/${maxReconnectAttempts})`
                : 'Try Again'
            }
          </button>

          <div className="mt-8 p-4 bg-gray-50 rounded-lg">
            <h3 className="font-semibold text-gray-900 mb-2">While you wait:</h3>
            <div className="text-sm text-gray-600 space-y-1">
              <p>📞 Call us: <a href="tel:+18437894430" className="text-[#1A3C1F]">(843) 789-4430</a></p>
              <p>📍 5900 Rivers Avenue, Suite D-4, North Charleston, SC</p>
              <p>🕒 Walk-ins welcome during business hours</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      {children}
      
      {/* Subtle Online/Offline Status Indicator */}
      <div className={`fixed top-4 right-4 z-40 transition-all duration-500 ${
        !isOnline ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-2 pointer-events-none'
      }`}>
        <div className="bg-red-500 text-white px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 text-sm">
          <WifiOff className="w-4 h-4" />
          <span>Offline{lastOfflineTime ? ` (${getOfflineDuration()})` : ''}</span>
          {reconnectAttempts > 0 && (
            <span className="text-xs opacity-75">
              Retrying {reconnectAttempts}/{maxReconnectAttempts}
            </span>
          )}
        </div>
      </div>

      {/* Connection restored indicator */}
      {isOnline && reconnectAttempts > 0 && (
        <div className="fixed top-4 right-4 z-40 animate-pulse">
          <div className="bg-green-500 text-white px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 text-sm">
            <Wifi className="w-4 h-4" />
            Connection Restored
          </div>
        </div>
      )}
    </>
  );
};