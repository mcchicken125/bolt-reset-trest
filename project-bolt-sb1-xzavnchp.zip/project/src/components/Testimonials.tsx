import React, { useState, useEffect } from 'react';

const testimonials = [
  {
    id: 1,
    name: 'Thomas Wright',
    image: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    quote: 'Best haircut I\'ve ever had. James really takes the time to understand what you want and delivers every time. The hot towel treatment is a must-try!',
    rating: 5
  },
  {
    id: 2,
    name: 'Marcus Johnson',
    image: 'https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    quote: 'I\'ve been coming here for over 2 years now and wouldn\'t go anywhere else. Michael is my go-to barber and he never disappoints. Great atmosphere too!',
    rating: 5
  },
  {
    id: 3,
    name: 'Kevin Anderson',
    image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    quote: 'Found this place after moving to the area and I\'m so glad I did. Professional service, great conversations, and I always leave looking sharp.',
    rating: 5
  },
  {
    id: 4,
    name: 'Chris Peterson',
    image: 'https://images.pexels.com/photos/775358/pexels-photo-775358.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    quote: 'David gave me the best beard trim I\'ve ever had. The attention to detail and styling advice was exactly what I needed. Highly recommend!',
    rating: 4
  },
];

export const Testimonials = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveIndex((current) => (current + 1) % testimonials.length);
    }, 6000);
    
    return () => clearInterval(interval);
  }, []);

  const handleDotClick = (index: number) => {
    setActiveIndex(index);
  };

  return (
    <section className="section bg-barber-dark text-white relative">
      <div className="absolute inset-0 bg-texture bg-cover bg-center opacity-10"></div>
      <div className="container relative z-10">
        <div className="text-center mb-12">
          <h2 className="section-title font-display text-white">What Our Clients Say</h2>
          <div className="w-24 h-1 bg-barber-secondary mx-auto my-4"></div>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="relative h-[420px] md:h-[320px]">
            {testimonials.map((testimonial, index) => (
              <div
                key={testimonial.id}
                className={`absolute inset-0 transition-all duration-700 ${
                  index === activeIndex 
                    ? 'opacity-100 translate-x-0' 
                    : 'opacity-0 translate-x-24 pointer-events-none'
                }`}
              >
                <div className="bg-barber-dark/50 backdrop-blur-sm border border-barber-secondary/20 p-8 rounded-lg">
                  <div className="flex flex-col md:flex-row gap-6 items-center md:items-start">
                    <div className="shrink-0">
                      <img
                        src={testimonial.image}
                        alt={testimonial.name}
                        className="w-20 h-20 rounded-full object-cover border-2 border-barber-secondary"
                      />
                    </div>
                    <div>
                      <div className="flex mb-2">
                        {[...Array(5)].map((_, i) => (
                          <svg
                            key={i}
                            className={`w-5 h-5 ${
                              i < testimonial.rating ? 'text-barber-secondary' : 'text-gray-300'
                            }`}
                            fill="currentColor"
                            viewBox="0 0 20 20"
                          >
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                          </svg>
                        ))}
                      </div>
                      <blockquote className="text-lg italic text-gray-200 mb-4">
                        "{testimonial.quote}"
                      </blockquote>
                      <cite className="font-bold text-white block">
                        {testimonial.name}
                      </cite>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex justify-center mt-8 space-x-2">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => handleDotClick(index)}
                className={`w-3 h-3 rounded-full transition-colors ${
                  index === activeIndex ? 'bg-barber-secondary' : 'bg-gray-300'
                }`}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        </div>

        <div className="text-center mt-12">
          <a 
            href="https://g.page/review" 
            target="_blank" 
            rel="noopener noreferrer"
            className="btn bg-transparent border-2 border-barber-secondary text-barber-secondary hover:bg-barber-secondary/10 transition-all"
          >
            Leave a Review
          </a>
        </div>
      </div>
    </section>
  );
};