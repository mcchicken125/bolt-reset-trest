import React from 'react';
import { ExternalLink, MapPin, Phone, Clock } from 'lucide-react';
import { MetaTags } from './MetaTags';

export const HtmlSitemap = () => {
  const mainPages = [
    {
      title: 'Home',
      url: '#home',
      description: 'Welcome to Change Up Cuts - Premier Multicultural Barbershop & Beauty Center'
    },
    {
      title: 'About Us',
      url: '#about',
      description: 'Learn about our story, mission, and commitment to multicultural grooming excellence'
    },
    {
      title: 'Barbershop Services',
      url: '#services',
      description: 'Professional barbering services including haircuts, fades, beard grooming, and styling'
    },
    {
      title: 'Beauty Center',
      url: '#careers',
      description: 'Luxury beauty treatments, hair styling, coloring, and professional makeup services'
    },
    {
      title: 'Style Gallery',
      url: '#gallery',
      description: 'Browse our comprehensive gallery of haircuts, styles, and grooming transformations'
    },
    {
      title: 'Contact Us',
      url: '#contact',
      description: 'Get in touch, book appointments, find our location, and connect with our team'
    }
  ];

  const legalPages = [
    {
      title: 'Privacy Policy',
      url: '#privacy',
      description: 'How we collect, use, and protect your personal information'
    },
    {
      title: 'Terms of Service',
      url: '#terms',
      description: 'Terms and conditions for using our services and website'
    }
  ];

  const services = [
    'Gentleman\'s Haircuts',
    'Modern Fades',
    'Kids Cuts',
    'Beard Trimming & Grooming',
    'Hot Towel Shaves',
    'Hair Styling',
    'Hair Coloring & Highlights',
    'Beauty Treatments',
    'Makeup Services'
  ];

  const businessInfo = {
    address: '5900 Rivers Avenue, Suite D-4, North Charleston, SC 29406',
    phone: '(843) 789-4430',
    beautyPhone: '(843) 789-4360',
    email: 'info@changeupcuts.com',
    hours: {
      barbershop: [
        'Monday - Thursday: 10:00 AM - 7:30 PM',
        'Friday - Saturday: 9:00 AM - 8:00 PM',
        'Sunday: 9:00 AM - 4:00 PM'
      ],
      beauty: [
        'Monday - Thursday: 10:00 AM - 5:00 PM',
        'Friday - Saturday: 9:00 AM - 6:00 PM',
        'Sunday: CLOSED'
      ]
    }
  };

  return (
    <div className="bg-white py-16">
      <MetaTags
        title="Site Map"
        description="Explore the comprehensive site map for Change Up Cuts Barbershop and Beauty Center. Find all pages, services, and contact information."
        keywords="site map, website navigation, Change Up Cuts pages, services list, barbershop sitemap"
        type="website"
        canonicalPath="/sitemap"
        author="Change Up Cuts Team"
        publishedTime="2021-07-01T00:00:00Z"
        modifiedTime={new Date().toISOString()}
      />
      
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-4">Site Map</h1>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">
              Navigate our website easily with this comprehensive site map. Find all our pages, services, and contact information.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Pages */}
            <div className="lg:col-span-2">
              <h2 className="text-2xl font-bold mb-6 text-[#1A3C1F]">Main Pages</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                {mainPages.map((page, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                    <a 
                      href={page.url}
                      className="text-lg font-semibold text-[#1A3C1F] hover:text-[#152f18] flex items-center gap-2 mb-2"
                    >
                      {page.title}
                      <ExternalLink className="w-4 h-4" />
                    </a>
                    <p className="text-gray-600 text-sm">{page.description}</p>
                  </div>
                ))}
              </div>

              {/* Services List */}
              <h3 className="text-xl font-bold mb-4 text-[#1A3C1F]">Our Services</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mb-8">
                {services.map((service, index) => (
                  <div key={index} className="flex items-center gap-2 text-gray-700">
                    <span className="w-2 h-2 bg-[#1A3C1F] rounded-full"></span>
                    {service}
                  </div>
                ))}
              </div>

              {/* Legal Pages */}
              <h3 className="text-xl font-bold mb-4 text-[#1A3C1F]">Legal Information</h3>
              <div className="space-y-3">
                {legalPages.map((page, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-3">
                    <a 
                      href={page.url}
                      className="font-semibold text-[#1A3C1F] hover:text-[#152f18] flex items-center gap-2"
                    >
                      {page.title}
                      <ExternalLink className="w-4 h-4" />
                    </a>
                    <p className="text-gray-600 text-sm mt-1">{page.description}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Business Information Sidebar */}
            <div className="space-y-6">
              {/* Contact Information */}
              <div className="bg-gray-50 rounded-lg p-6">
                <h3 className="text-xl font-bold mb-4 text-[#1A3C1F]">Contact Information</h3>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <MapPin className="w-5 h-5 text-[#1A3C1F] mt-0.5" />
                    <div>
                      <p className="font-medium">Address</p>
                      <a 
                        href="https://www.google.com/maps/place/Change+Up+Cuts+Barbershop+%26+Beauty+Center/@32.9044054,-80.0203215,17.05z/data=!4m6!3m5!1s0x88fe636c08e7b0a3:0x80d92ec6413760e4!8m2!3d32.904006!4d-80.0181136!16s%2Fg%2F11q8vcl_gr?entry=ttu&g_ep=EgoyMDI1MDYwNC4wIKXMDSoASAFQAw%3D%3D"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-gray-600 text-sm hover:text-[#1A3C1F] transition-colors"
                        aria-label="View our location on Google Maps"
                      >
                        {businessInfo.address}
                      </a>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Phone className="w-5 h-5 text-[#1A3C1F] mt-0.5" />
                    <div>
                      <p className="font-medium">Phone</p>
                      <p className="text-gray-600 text-sm">
                        Barbershop: <a href="tel:+18437894430" className="hover:text-[#1A3C1F]">{businessInfo.phone}</a><br />
                        Beauty Center: <a href="tel:+18437894360" className="hover:text-[#1A3C1F]">{businessInfo.beautyPhone}</a>
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Hours */}
              <div className="bg-gray-50 rounded-lg p-6">
                <h3 className="text-xl font-bold mb-4 text-[#1A3C1F] flex items-center gap-2">
                  <Clock className="w-5 h-5" />
                  Business Hours
                </h3>
                <div className="space-y-4">
                  <div>
                    <p className="font-medium mb-2">Barbershop</p>
                    {businessInfo.hours.barbershop.map((hours, index) => (
                      <p key={index} className="text-gray-600 text-sm">{hours}</p>
                    ))}
                  </div>
                  <div>
                    <p className="font-medium mb-2">Beauty Center</p>
                    {businessInfo.hours.beauty.map((hours, index) => (
                      <p key={index} className="text-gray-600 text-sm">{hours}</p>
                    ))}
                  </div>
                </div>
              </div>

              {/* Quick Actions */}
              <div className="bg-[#1A3C1F] rounded-lg p-6 text-white">
                <h3 className="text-xl font-bold mb-4">Quick Actions</h3>
                <div className="space-y-3">
                  <a 
                    href="https://getsquire.com/booking/book/change-up-cuts-barbershop-and-beauty-center-north-charleston/barber/any/services"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block w-full py-2 px-4 bg-[#D2B48C] text-black text-center rounded hover:bg-[#C19A6B] transition-colors"
                  >
                    Book Appointment
                  </a>
                  <a 
                    href="tel:+18437894430"
                    className="block w-full py-2 px-4 border border-white text-center rounded hover:bg-white hover:text-[#1A3C1F] transition-colors"
                  >
                    Call Now
                  </a>
                  <a 
                    href="https://www.google.com/maps/place/Change+Up+Cuts+Barbershop+%26+Beauty+Center/@32.9044054,-80.0203215,17.05z/data=!4m6!3m5!1s0x88fe636c08e7b0a3:0x80d92ec6413760e4!8m2!3d32.904006!4d-80.0181136!16s%2Fg%2F11q8vcl_gr?entry=ttu&g_ep=EgoyMDI1MDYwNC4wIKXMDSoASAFQAw%3D%3D"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block w-full py-2 px-4 border border-white text-center rounded hover:bg-white hover:text-[#1A3C1F] transition-colors"
                  >
                    Get Directions
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom CTA */}
          <div className="text-center mt-12 pt-8 border-t border-gray-200">
            <p className="text-gray-600 mb-4">
              Can't find what you're looking for? We're here to help!
            </p>
            <a 
              href="#contact"
              className="inline-block px-6 py-3 bg-[#1A3C1F] text-white rounded hover:bg-[#152f18] transition-colors"
            >
              Contact Us
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};