import React from 'react';
import { Home, ArrowLeft, Phone, MapPin, Scissors } from 'lucide-react';
import { MetaTags } from './MetaTags';

export const NotFoundPage = () => {
  return (
    <div className="bg-white min-h-screen">
      <MetaTags
        title="Page Not Found - 404"
        description="The page you're looking for doesn't exist. Visit Change Up Cuts Barbershop and Beauty Center to find our services, contact information, and book appointments."
        keywords="404, page not found, Change Up Cuts, barbershop, beauty center"
        type="website"
        canonicalPath="/404"
      />
      
      {/* Hero Section */}
      <section 
        className="relative min-h-screen flex items-center justify-center"
        style={{
          backgroundImage: 'url("https://i.postimg.cc/C1htXj89/barber.webp")',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: window.innerWidth >= 768 ? 'fixed' : 'scroll'
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/70 to-black/80"></div>
        
        <div className="relative z-10 container mx-auto px-4 text-center">
          <div className="max-w-4xl mx-auto">
            {/* 404 Number - Large and Eye-catching */}
            <div className="mb-8 relative">
              <h1 className="text-8xl md:text-9xl lg:text-[12rem] font-display font-bold text-white leading-none opacity-90 select-none">
                404
              </h1>
              <div className="absolute inset-0 flex items-center justify-center">
                <Scissors className="w-16 h-16 md:w-20 md:h-20 lg:w-24 lg:h-24 text-[#1A3C1F] animate-pulse" />
              </div>
            </div>

            {/* Main Message */}
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-display font-bold text-white mb-6 leading-tight">
              Oops! Page Not Found
            </h2>
            
            <p className="text-lg md:text-xl text-white/90 mb-8 max-w-2xl mx-auto leading-relaxed">
              Looks like this page got a trim and doesn't exist anymore. Let's get you back on track!
            </p>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
              <a 
                href="#home"
                className="inline-flex items-center gap-3 px-8 py-4 bg-[#1A3C1F] text-white text-lg font-medium hover:bg-[#152f18] transition-all rounded-lg shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 group"
              >
                <Home className="w-5 h-5 group-hover:scale-110 transition-transform duration-200" />
                Go Home
              </a>
              
              <a 
                href="javascript:history.back()"
                className="inline-flex items-center gap-3 px-8 py-4 bg-transparent border-2 border-white text-white text-lg font-medium hover:bg-white hover:text-[#1A3C1F] transition-all rounded-lg group"
              >
                <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform duration-200" />
                Go Back
              </a>
            </div>

            {/* Spanish Text */}
            <p className="text-white/70 text-lg tracking-wide font-light">¡HABLAMOS ESPAÑOL!</p>
          </div>
        </div>
      </section>

      {/* Quick Navigation Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto text-center">
            <h3 className="text-3xl md:text-4xl font-bold mb-8 text-[#1A3C1F]">Where Would You Like to Go?</h3>
            <p className="text-gray-600 text-lg mb-12 max-w-2xl mx-auto">
              Explore our main sections to find exactly what you're looking for.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {/* Navigation Cards */}
              <a 
                href="#about"
                className="group bg-white p-6 rounded-xl shadow-md hover:shadow-xl transition-all duration-300 hover:scale-105 border border-gray-100 hover:border-[#1A3C1F]/20"
              >
                <div className="w-16 h-16 bg-[#1A3C1F]/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#1A3C1F]/20 transition-colors duration-300">
                  <Home className="w-8 h-8 text-[#1A3C1F]" />
                </div>
                <h4 className="text-xl font-bold mb-2 group-hover:text-[#1A3C1F] transition-colors duration-300">About Us</h4>
                <p className="text-gray-600 text-sm">Learn about our story and mission</p>
              </a>

              <a 
                href="#services"
                className="group bg-white p-6 rounded-xl shadow-md hover:shadow-xl transition-all duration-300 hover:scale-105 border border-gray-100 hover:border-[#1A3C1F]/20"
              >
                <div className="w-16 h-16 bg-[#1A3C1F]/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#1A3C1F]/20 transition-colors duration-300">
                  <Scissors className="w-8 h-8 text-[#1A3C1F]" />
                </div>
                <h4 className="text-xl font-bold mb-2 group-hover:text-[#1A3C1F] transition-colors duration-300">Barbershop</h4>
                <p className="text-gray-600 text-sm">Professional barbering services</p>
              </a>

              <a 
                href="#careers"
                className="group bg-white p-6 rounded-xl shadow-md hover:shadow-xl transition-all duration-300 hover:scale-105 border border-gray-100 hover:border-[#1A3C1F]/20"
              >
                <div className="w-16 h-16 bg-[#1A3C1F]/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#1A3C1F]/20 transition-colors duration-300">
                  <span className="text-2xl text-[#1A3C1F]">✨</span>
                </div>
                <h4 className="text-xl font-bold mb-2 group-hover:text-[#1A3C1F] transition-colors duration-300">Beauty Center</h4>
                <p className="text-gray-600 text-sm">Luxury beauty treatments</p>
              </a>

              <a 
                href="#contact"
                className="group bg-white p-6 rounded-xl shadow-md hover:shadow-xl transition-all duration-300 hover:scale-105 border border-gray-100 hover:border-[#1A3C1F]/20"
              >
                <div className="w-16 h-16 bg-[#1A3C1F]/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#1A3C1F]/20 transition-colors duration-300">
                  <Phone className="w-8 h-8 text-[#1A3C1F]" />
                </div>
                <h4 className="text-xl font-bold mb-2 group-hover:text-[#1A3C1F] transition-colors duration-300">Contact Us</h4>
                <p className="text-gray-600 text-sm">Get in touch and book appointments</p>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Emergency Contact Section */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h3 className="text-2xl md:text-3xl font-bold mb-8">Need Immediate Help?</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-gray-50 p-6 rounded-lg">
                <Phone className="w-8 h-8 text-[#1A3C1F] mx-auto mb-4" />
                <h4 className="text-xl font-bold mb-2">Call Us Directly</h4>
                <p className="text-gray-600 mb-4">Speak with our team for immediate assistance</p>
                <a 
                  href="tel:+18437894430"
                  className="inline-block px-6 py-2 bg-[#1A3C1F] text-white rounded hover:bg-[#152f18] transition-colors"
                >
                  (843) 789-4430
                </a>
              </div>

              <div className="bg-gray-50 p-6 rounded-lg">
                <MapPin className="w-8 h-8 text-[#1A3C1F] mx-auto mb-4" />
                <h4 className="text-xl font-bold mb-2">Visit Our Location</h4>
                <p className="text-gray-600 mb-4">Walk-ins are always welcome</p>
                <a 
                  href="https://www.google.com/maps/place/Change+Up+Cuts+Barbershop+%26+Beauty+Center/@32.9044054,-80.0203215,17.05z/data=!4m6!3m5!1s0x88fe636c08e7b0a3:0x80d92ec6413760e4!8m2!3d32.904006!4d-80.0181136!16s%2Fg%2F11q8vcl_gr?entry=ttu&g_ep=EgoyMDI1MDYwNC4wIKXMDSoASAFQAw%3D%3D"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block px-6 py-2 bg-[#1A3C1F] text-white rounded hover:bg-[#152f18] transition-colors"
                >
                  Get Directions
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-[#1A3C1F] py-12">
        <div className="container mx-auto px-4 text-center">
          <h3 className="text-2xl md:text-3xl text-white font-bold mb-6">Ready to Book Your Appointment?</h3>
          <p className="text-white/90 mb-8 max-w-2xl mx-auto">
            Don't let a wrong turn stop you from getting the perfect cut. Schedule your appointment today!
          </p>
          <a 
            href="https://getsquire.com/booking/book/change-up-cuts-barbershop-and-beauty-center-north-charleston/barber/any/services"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block px-8 py-4 bg-[#D2B48C] text-black text-lg font-medium hover:bg-[#C19A6B] transition-all rounded-lg shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
          >
            Book Now
          </a>
        </div>
      </section>
    </div>
  );
};