import React from 'react';
import { Instagram, Facebook, Twitter, MapPin, Phone, Mail, Clock, Scissors, Sparkles } from 'lucide-react';

export const Footer = () => {
  const barbershopHours = [
    { day: 'Mon-Thu', hours: '10am - 7:30pm' },
    { day: 'Fri-Sat', hours: '9am - 8pm' },
    { day: 'Sun', hours: '9am - 4pm' }
  ];

  const beautyCenterHours = [
    { day: 'Mon-Thu', hours: '10am - 5pm' },
    { day: 'Fri-Sat', hours: '9am - 6pm' },
    { day: 'Sun', hours: 'CLOSED' }
  ];

  return (
    <footer className="bg-barber-dark text-white pt-12 pb-6" role="contentinfo">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="mb-4">
              <img 
                src="https://i.postimg.cc/xCFnNRvc/Changup-Lo-GO.webp" 
                alt="Change Up Cuts logo"
                className="h-12 w-auto"
              />
            </div>
            <p className="text-gray-300 mb-6">
              Premium barbershop and beauty center delivering exceptional service and an unforgettable experience since 2021.
            </p>
            
            <div className="mb-6">
              <h4 className="text-white font-semibold text-sm mb-3">Barbershop Socials:</h4>
              <div className="flex space-x-3">
                <a 
                  href="https://www.facebook.com/Changeupcuts" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-300 hover:text-barber-secondary transition-colors"
                  aria-label="Follow barbershop on Facebook"
                >
                  <Facebook className="h-5 w-5" />
                </a>
                <a 
                  href="http://instagram.com/changeupcuts" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-300 hover:text-barber-secondary transition-colors"
                  aria-label="Follow barbershop on Instagram"
                >
                  <Instagram className="h-5 w-5" />
                </a>
                <a 
                  href="https://twitter.com/changeupcuts" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-300 hover:text-barber-secondary transition-colors"
                  aria-label="Follow barbershop on Twitter"
                >
                  <Twitter className="h-5 w-5" />
                </a>
              </div>
            </div>

            <div>
              <h4 className="text-white font-semibold text-sm mb-3">Beauty Center Socials:</h4>
              <div className="flex space-x-3">
                <a 
                  href="https://www.facebook.com/changeupcutsbeautycenter" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-300 hover:text-barber-secondary transition-colors"
                  aria-label="Follow beauty center on Facebook"
                >
                  <Facebook className="h-5 w-5" />
                </a>
                <a 
                  href="https://www.instagram.com/Changeupcutsbeautycenter/" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-300 hover:text-barber-secondary transition-colors"
                  aria-label="Follow beauty center on Instagram"
                >
                  <Instagram className="h-5 w-5" />
                </a>
                <a 
                  href="https://twitter.com/changeupcuts" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-300 hover:text-barber-secondary transition-colors"
                  aria-label="Follow beauty center on Twitter"
                >
                  <Twitter className="h-5 w-5" />
                </a>
              </div>
            </div>
          </div>

          <nav aria-labelledby="footer-nav-heading">
            <h3 id="footer-nav-heading" className="text-lg font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="#home" className="text-gray-300 hover:text-barber-secondary transition-colors">Home</a></li>
              <li><a href="#services" className="text-gray-300 hover:text-barber-secondary transition-colors">Services</a></li>
              <li><a href="#about" className="text-gray-300 hover:text-barber-secondary transition-colors">About Us</a></li>
              <li><a href="#gallery" className="text-gray-300 hover:text-barber-secondary transition-colors">Gallery</a></li>
              <li><a href="#contact" className="text-gray-300 hover:text-barber-secondary transition-colors">Contact</a></li>
            </ul>
          </nav>

          <div>
            <div className="flex items-center gap-2 mb-4">
              <Clock className="h-5 w-5 text-barber-secondary flex-shrink-0" />
              <h3 className="text-lg font-bold">Hours of Operation</h3>
            </div>
            <div className="space-y-4">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Scissors className="h-4 w-4 text-barber-secondary flex-shrink-0" />
                  <h4 className="text-barber-secondary font-medium">Barbershop</h4>
                </div>
                <ul className="space-y-1">
                  {barbershopHours.map((item, index) => (
                    <li key={index} className="flex justify-between text-sm text-gray-300">
                      <span>{item.day}</span>
                      <span>{item.hours}</span>
                    </li>
                  ))}
                </ul>
                <p className="text-xs text-gray-300 mt-1">Walk-ins Welcome</p>
              </div>
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="h-4 w-4 text-barber-secondary flex-shrink-0" />
                  <h4 className="text-barber-secondary font-medium">Beauty Center</h4>
                </div>
                <ul className="space-y-1">
                  {beautyCenterHours.map((item, index) => (
                    <li key={index} className="flex justify-between text-sm text-gray-300">
                      <span>{item.day}</span>
                      <span>{item.hours}</span>
                    </li>
                  ))}
                </ul>
                <p className="text-xs text-gray-300 mt-1">Walk-ins Welcome</p>
              </div>
            </div>
          </div>

          <address className="not-italic">
            <h3 className="text-lg font-bold mb-4">Contact Info</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-barber-secondary mt-0.5 flex-shrink-0" />
                <div>
                  <a 
                    href="https://www.google.com/maps/place/Change+Up+Cuts+Barbershop+%26+Beauty+Center/@32.9044054,-80.0203215,17.05z/data=!4m6!3m5!1s0x88fe636c08e7b0a3:0x80d92ec6413760e4!8m2!3d32.904006!4d-80.0181136!16s%2Fg%2F11q8vcl_gr?entry=ttu&g_ep=EgoyMDI1MDYwNC4wIKXMDSoASAFQAw%3D%3D"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-300 hover:text-barber-secondary transition-colors"
                    aria-label="View location on Google Maps"
                  >
                    5900 Rivers Avenue<br />
                    Suite D-4<br />
                    North Charleston, SC 29406
                  </a>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <Phone className="h-5 w-5 text-barber-secondary mt-0.5 flex-shrink-0" />
                <div className="text-gray-300">
                  <div className="font-bold text-[#1A3C1F]">Barbershop:</div>
                  <a href="tel:+18437894430" className="hover:text-barber-secondary transition-colors">(843) 789-4430</a>
                  <div className="font-bold text-[#1A3C1F] mt-2">Beauty Center:</div>
                  <a href="tel:+18437894360" className="hover:text-barber-secondary transition-colors">(843) 789-4360</a>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <Mail className="h-5 w-5 text-barber-secondary mt-0.5 flex-shrink-0" />
                <div>
                  <a href="mailto:info@changeupcuts.com" className="text-gray-300 hover:text-barber-secondary transition-colors">
                    info@changeupcuts.com
                  </a>
                </div>
              </li>
            </ul>
          </address>
        </div>

        <div className="border-t border-gray-800 pt-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-300 text-sm mb-4 md:mb-0">
              © {new Date().getFullYear()} Change Up Cuts. All rights reserved.
            </p>
            <nav aria-label="Legal links">
              <div className="flex space-x-4 text-sm text-gray-300">
                <a href="#privacy" className="hover:text-barber-secondary transition-colors">Privacy Policy</a>
                <a href="#terms" className="hover:text-barber-secondary transition-colors">Terms of Use</a>
                <a href="#sitemap" className="hover:text-barber-secondary transition-colors">Site Map</a>
              </div>
            </nav>
          </div>
        </div>
      </div>
    </footer>
  );
};