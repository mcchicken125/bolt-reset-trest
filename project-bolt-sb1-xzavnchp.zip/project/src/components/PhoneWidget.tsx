import React, { useState } from 'react';
import { Phone, X } from 'lucide-react';

export const PhoneWidget = () => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className="fixed bottom-6 right-6 z-40">
      {/* Main Phone Button */}
      <div className="relative">
        {/* Expanded Info Card */}
        {isExpanded && (
          <div className="absolute bottom-14 right-0 bg-white rounded-lg shadow-2xl border border-gray-200 p-4 w-64 transform transition-all duration-300 ease-out">
            {/* Close Button */}
            <button
              onClick={() => setIsExpanded(false)}
              className="absolute top-2 right-2 w-6 h-6 flex items-center justify-center text-gray-400 hover:text-gray-600 transition-colors"
              aria-label="Close phone info"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Content */}
            <div className="pr-6">
              <h3 className="font-bold text-gray-900 mb-2">Call Us Now</h3>
              <p className="text-sm text-gray-600 mb-4">
                Get in touch with our barbershop for appointments or questions
              </p>
              
              {/* Phone Numbers */}
              <div className="space-y-3">
                <div>
                  <p className="text-xs text-gray-500 mb-1">Barbershop</p>
                  <a 
                    href="tel:+18437894430"
                    className="flex items-center gap-2 text-[#1A3C1F] hover:text-[#152f18] font-medium transition-colors group"
                  >
                    <Phone className="w-4 h-4 group-hover:scale-110 transition-transform duration-200" />
                    (843) 789-4430
                  </a>
                </div>
                
                <div>
                  <p className="text-xs text-gray-500 mb-1">Beauty Center</p>
                  <a 
                    href="tel:+18437894360"
                    className="flex items-center gap-2 text-[#1A3C1F] hover:text-[#152f18] font-medium transition-colors group"
                  >
                    <Phone className="w-4 h-4 group-hover:scale-110 transition-transform duration-200" />
                    (843) 789-4360
                  </a>
                </div>
              </div>

              {/* Hours */}
              <div className="mt-4 pt-3 border-t border-gray-100">
                <p className="text-xs text-gray-500 mb-2">Barbershop Hours</p>
                <div className="text-xs text-gray-600 space-y-1">
                  <div className="flex justify-between">
                    <span>Mon-Thu:</span>
                    <span>10am-7:30pm</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Fri-Sat:</span>
                    <span>9am-8pm</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sunday:</span>
                    <span>9am-4pm</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Phone Button */}
        <div className="relative group">
          {/* Pulse Animation Ring */}
          <div className="absolute inset-0 w-12 h-12 bg-[#1A3C1F] rounded-full animate-ping opacity-20"></div>
          <div className="absolute inset-1 w-10 h-10 bg-[#1A3C1F] rounded-full animate-ping opacity-30 animation-delay-300"></div>
          
          {/* Main Button */}
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            onMouseEnter={() => setIsExpanded(true)}
            className="relative w-12 h-12 bg-[#1A3C1F] text-white rounded-full flex items-center justify-center shadow-2xl hover:bg-[#152f18] transition-all duration-300 hover:scale-110 active:scale-95 group focus:ring-4 focus:ring-[#1A3C1F]/30"
            aria-label="Phone contact options"
          >
            <Phone className="w-5 h-5 group-hover:scale-110 transition-transform duration-200" />
            
            {/* Tooltip for mobile */}
            <div className="absolute bottom-14 right-0 bg-black text-white text-xs py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none whitespace-nowrap sm:hidden">
              Tap to see phone options
            </div>
          </button>

          {/* Direct Call Button (shows on mobile when not expanded) */}
          {!isExpanded && (
            <a
              href="tel:+18437894430"
              className="absolute inset-0 w-12 h-12 rounded-full sm:hidden"
              aria-label="Call barbershop directly"
            />
          )}
        </div>

        {/* Quick Call Badge (Desktop) */}
        <div className="hidden sm:block absolute -top-2 -left-8 bg-white text-[#1A3C1F] text-xs font-medium px-2 py-1 rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-all duration-300 transform -translate-y-1 group-hover:translate-y-0 pointer-events-none whitespace-nowrap">
          Quick Call
        </div>
      </div>
    </div>
  );
};