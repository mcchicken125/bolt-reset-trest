import React from 'react';

export const CTASection = () => {
  return (
    <section 
      className="bg-[#1A3C1F] py-8" 
      role="region" 
      aria-labelledby="cta-heading"
    >
      <div className="container mx-auto px-4 flex flex-col md:flex-row items-center justify-center gap-6">
        <h2 id="cta-heading" className="text-3xl md:text-4xl text-white font-display font-bold">
          Need A Haircut?
        </h2>
        <a 
          href="https://getsquire.com/booking/book/change-up-cuts-barbershop-and-beauty-center-north-charleston/barber/any/services"
          target="_blank"
          rel="noopener noreferrer" 
          className="px-6 py-3 bg-[#D2B48C] text-black font-medium hover:bg-[#C19A6B] transition-colors rounded"
          aria-label="Schedule an appointment online - opens in new window"
        >
          Schedule Appointment
        </a>
      </div>
    </section>
  );
};