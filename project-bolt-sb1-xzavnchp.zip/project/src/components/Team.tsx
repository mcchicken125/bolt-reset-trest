import React from 'react';

const barbers = [
  {
    id: 1,
    name: 'James Wilson',
    role: 'Master Barber / Owner',
    image: 'https://images.pexels.com/photos/1139743/pexels-photo-1139743.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    bio: '15+ years of experience specializing in classic cuts and hot towel shaves.',
    specialties: ['Classic Cuts', 'Straight Razor Shaves', 'Beard Design']
  },
  {
    id: 2,
    name: 'Michael Rodriguez',
    role: 'Senior Barber',
    image: 'https://images.pexels.com/photos/1073097/pexels-photo-1073097.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    bio: 'Expert in modern fades and creative designs with 8 years in the industry.',
    specialties: ['Fades', 'Design Work', 'Textured Styles']
  },
  {
    id: 3,
    name: 'David Thompson',
    role: 'Barber',
    image: 'https://images.pexels.com/photos/6639956/pexels-photo-6639956.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    bio: 'Specializes in precision cuts and beard grooming. Known for attention to detail.',
    specialties: ['Precision Cuts', 'Beard Grooming', 'Hair Coloring']
  },
  {
    id: 4,
    name: 'Robert Martinez',
    role: 'Barber',
    image: 'https://images.pexels.com/photos/4397830/pexels-photo-4397830.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    bio: 'Brings a fresh perspective with contemporary styles and excellent client service.',
    specialties: ['Modern Styles', 'Skin Fades', 'Facial Treatments']
  },
];

export const Team = () => {
  return (
    <section id="team" className="section bg-barber-light">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="section-title font-display text-barber-primary">Meet Our Barbers</h2>
          <div className="w-24 h-1 bg-barber-secondary mx-auto my-4"></div>
          <p className="section-subtitle text-gray-700 max-w-2xl mx-auto">
            Our team of skilled professionals is dedicated to providing you with the best barbering experience. Each barber brings their unique expertise and style.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {barbers.map((barber) => (
            <div key={barber.id} className="bg-white rounded-lg overflow-hidden shadow-md group">
              <div className="aspect-square overflow-hidden">
                <img 
                  src={barber.image} 
                  alt={barber.name} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-1">{barber.name}</h3>
                <p className="text-barber-secondary font-medium mb-3">{barber.role}</p>
                <p className="text-gray-600 mb-4">{barber.bio}</p>
                <div className="mt-4">
                  <h4 className="font-bold text-sm text-gray-900 mb-2">Specialties:</h4>
                  <div className="flex flex-wrap gap-2">
                    {barber.specialties.map((specialty, index) => (
                      <span 
                        key={index} 
                        className="bg-gray-100 text-gray-800 text-xs px-3 py-1 rounded-full"
                      >
                        {specialty}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
              <div className="px-6 pb-6">
                <a 
                  href="#booking" 
                  className="block w-full py-2 text-center bg-barber-secondary hover:bg-barber-accent text-white font-medium rounded transition-colors"
                >
                  Book with {barber.name.split(' ')[0]}
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};