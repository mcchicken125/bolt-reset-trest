import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { MetaTags } from './MetaTags';

export const AboutPage = () => {
  const [isHovered, setIsHovered] = React.useState(false);
  const [isTextHovered, setIsTextHovered] = React.useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 1024);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 1024);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const darkGradient = isMobile
    ? 'linear-gradient(to left, rgba(26,26,26,1) 0%, rgba(26,26,26,0.56) 40%, rgba(26,26,26,0) 100%)'
    : 'linear-gradient(to left, rgba(26,26,26,1) 0%, rgba(26,26,26,0.8) 40%, rgba(26,26,26,0) 100%)';

  const lightGradient = isMobile
    ? 'linear-gradient(to right, rgba(255,255,255,1) 0%, rgba(255,255,255,0.56) 40%, rgba(255,255,255,0) 100%)'
    : 'linear-gradient(to right, rgba(255,255,255,1) 0%, rgba(255,255,255,0.8) 40%, rgba(255,255,255,0) 100%)';

  return (
    <div className="bg-white">
      <MetaTags
        title="About Us"
        description="Learn about Change Up Cuts Barbershop and Beauty Center, Charleston's premier multicultural grooming destination. Founded in 2021, we deliver exceptional service and expert styling for all hair types."
        keywords="about Change Up Cuts, Charleston barbershop history, multicultural salon, professional barbers, beauty experts"
        type="article"
        image="https://i.postimg.cc/xT9nxZ7j/doyoubelieveusnow.webp"
        twitterCard="summary_large_image"
        author="Change Up Cuts Team"
        publishedTime="2021-07-01T00:00:00Z"
        modifiedTime={new Date().toISOString()}
        canonicalPath="/about"
      />
      {/* Hero Section */}
      <section 
        className="relative min-h-[80vh] flex items-center justify-center"
        style={{
          backgroundImage: 'url("https://i.postimg.cc/sgs5tj3z/Third.webp")',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed'
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/70 to-black/80"></div>
        
        <div className="relative z-10 container mx-auto px-4 pt-20 text-center">
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-display font-bold text-white mb-6 leading-tight">
            Our Story
          </h1>
          <div className="w-24 h-1 bg-[#1A3C1F] mx-auto mb-8"></div>
          <p className="text-xl md:text-2xl text-white/90 max-w-3xl mx-auto mb-8 leading-relaxed">
            A legacy of excellence in barbering and beauty services since 2021
          </p>
          <p className="text-white/70 text-lg mt-12 tracking-wide font-light">¡HABLAMOS ESPAÑOL!</p>
        </div>

        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black to-transparent"></div>
      </section>

      {/* About Section */}
      <section className="bg-white min-h-[60vh] flex">
        <div className="flex flex-col lg:flex-row w-full">
          <div className="w-full lg:w-1/2 p-12 flex items-center">
            <div>
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-display font-bold mb-4">Community. Culture. Confidence.</h2>
              <div className="w-24 h-1 bg-[#1A3C1F] mb-6"></div>
              <p className="text-gray-600 text-base md:text-lg leading-relaxed">
                At Change Up Cuts, we're more than just a barbershop. We're a community hub built on culture, craft, and confidence.
                Our team brings together diverse talent and styles to serve every walk of life with precision and pride. From clean fades and tapers to shear work, designs, hot shaves, and creative cuts, we've got you covered. Whether you're coming in for a fresh start or your regular look, we make sure you leave sharp, confident, and respected.
                Walk in or book today. We can't wait to see you!
              </p>
            </div>
          </div>
          <div className="relative w-full lg:w-1/2 min-h-[450px] lg:min-h-full overflow-hidden">
            <div 
              className="absolute inset-0 z-10"
              style={{
                background: window.innerWidth < 1024 
                  ? 'linear-gradient(to right, rgba(255,255,255,1) 0%, rgba(255,255,255,0.42) 40%, rgba(255,255,255,0) 100%)'
                  : 'linear-gradient(to right, rgba(255,255,255,1) 0%, rgba(255,255,255,0.6) 40%, rgba(255,255,255,0) 100%)'
              }}
            ></div>
            <div 
              className="absolute inset-0"
              style={{
                backgroundImage: `url('https://i.postimg.cc/QM4ZJ49H/informador.webp')`,
                backgroundPosition: 'center',
                backgroundSize: 'cover',
                backgroundRepeat: 'no-repeat',
                filter: 'grayscale(100%)'
              }}
            ></div>
          </div>
        </div>
      </section>

      {/* Store Info Sections */}
      <section className="min-h-[60vh] flex bg-[#1A1A1A]">
        <div className="flex flex-col lg:flex-row w-full">
          <div className="relative w-full lg:w-1/2 min-h-[450px] lg:min-h-full overflow-hidden">
            <div 
              className="absolute inset-0 z-10"
              style={{
                background: darkGradient
              }}
            ></div>
            <div 
              className="absolute inset-0"
              style={{
                backgroundImage: `url('https://i.postimg.cc/9McRYN63/DSC01318_copia_1.jpg')`,
                backgroundPosition: 'center',
                backgroundSize: 'cover',
                backgroundRepeat: 'no-repeat',
                filter: 'grayscale(100%)'
              }}
            ></div>
          </div>
          <div className="w-full lg:w-1/2 p-12 flex items-center">
            <div>
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold mb-6 text-white">
                Diverse Roots. Sharp Style.
              </h2>
              <p className="text-gray-300 text-lg md:text-xl leading-relaxed mb-8">
                We blend culture, skill, and modern style to deliver precision grooming in a space where everyone feels welcome. Our team is proud to serve a diverse community with cuts that build confidence and celebrate individuality.
              </p>
              <a 
                href="https://getsquire.com/booking/book/change-up-cuts-barbershop-and-beauty-center-north-charleston/barber/any/services"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block px-6 py-3 bg-[#D2B48C] text-black font-medium hover:bg-[#C19A6B] transition-colors rounded"
              >
                Book Now
              </a>
            </div>
          </div>
        </div>
      </section>

      <section className="min-h-[60vh] flex bg-white">
        <div className="flex flex-col lg:flex-row w-full">
          <div className="w-full lg:w-1/2 p-12 flex items-center">
            <div>
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold mb-6">What We Do Best</h2>
              <p className="text-gray-600 text-lg md:text-xl leading-relaxed mb-8">
                Change Up Cuts Barbershop provides a full range of services tailored to fit your style and needs.
              </p>
              <a 
                href="#services"
                className="btn bg-[#1A3C1F] text-white hover:bg-[#152f18] inline-block px-6 py-3 rounded"
              >
                View Services
              </a>
            </div>
          </div>
          <div className="relative w-full lg:w-1/2 min-h-[450px] lg:min-h-full overflow-hidden">
            <div 
              className="absolute inset-0 z-10"
              style={{
                background: lightGradient
              }}
            ></div>
            <div 
              className="absolute inset-0"
              style={{
                backgroundImage: `url('https://i.postimg.cc/sgs5tj3z/Third.webp')`,
                backgroundPosition: 'center',
                backgroundSize: 'cover',
                backgroundRepeat: 'no-repeat',
                filter: 'grayscale(100%)'
              }}
            ></div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-[#1A3C1F] py-8">
        <div className="container mx-auto px-4 flex flex-col md:flex-row items-center justify-center gap-6">
          <h2 className="text-3xl md:text-4xl text-white font-display font-bold">Need A Haircut?</h2>
          <a 
            href="https://getsquire.com/booking/book/change-up-cuts-barbershop-and-beauty-center-north-charleston/barber/any/services"
            target="_blank"
            rel="noopener noreferrer"
            className="px-6 py-3 bg-[#D2B48C] text-black font-medium hover:bg-[#C19A6B] transition-colors rounded"
          >
            Schedule Appointment
          </a>
        </div>
      </section>
    </div>
  );
};