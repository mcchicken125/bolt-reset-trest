import React, { useState, useEffect } from 'react';
import { HiringModal } from './HiringModal';

export const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showTopBar, setShowTopBar] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);
  const [activeItem, setActiveItem] = useState('');
  const [isHiringModalOpen, setIsHiringModalOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      setIsScrolled(currentScrollY > 50);
      setShowTopBar(currentScrollY < 50 || currentScrollY < lastScrollY);
      setLastScrollY(currentScrollY);

      const sections = document.querySelectorAll('section[id]');
      let currentSection = '';
      
      sections.forEach(section => {
        const sectionTop = (section as HTMLElement).offsetTop - 100;
        const sectionHeight = (section as HTMLElement).offsetHeight;
        if (currentScrollY >= sectionTop && currentScrollY < sectionTop + sectionHeight) {
          currentSection = '#' + section.getAttribute('id');
        }
      });
      
      setActiveItem(currentSection);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
  }, [isMobileMenuOpen]);

  const handleMenuItemClick = (href: string) => {
    setIsMobileMenuOpen(false);
    document.body.style.overflow = '';
    setActiveItem(href);
  };

  const handleHiringClick = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsHiringModalOpen(true);
  };

  const menuItems = [
    { href: '#about', label: 'About Us' },
    { href: '#services', label: 'Barbershop' },
    { href: '#careers', label: 'Beauty Center' },
    { href: '#contact', label: 'Contact' }
  ];

  return (
    <>
      <header className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'backdrop-blur-md' : ''}`} role="banner">
        {/* Top Bar */}
        <div 
          className={`bg-[#1A3C1F] text-white transition-all duration-500 ${
            showTopBar ? 'h-10' : 'h-0 overflow-hidden'
          }`}
          role="complementary"
          aria-label="Top navigation bar"
        >
          <div className="container mx-auto px-4 h-full">
            <div className="flex justify-end items-center h-full text-sm">
              <a 
                href="#careers" 
                onClick={handleHiringClick}
                className="hover:text-white/80 transition-colors relative overflow-hidden group cursor-pointer"
                aria-label="View career opportunities and apply for open positions"
              >
                <span className="relative z-10">Now Hiring: Apply Now</span>
                <span className="absolute inset-0 bg-white/20 transform -translate-x-full group-hover:translate-x-0 transition-transform duration-300" aria-hidden="true"></span>
              </a>
              <span className="mx-4 text-white/30" aria-hidden="true">|</span>
              <a 
                href="https://getsquire.com/booking/book/change-up-cuts-barbershop-and-beauty-center-north-charleston/barber/any/services"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-white/80 transition-colors relative overflow-hidden group"
                aria-label="Schedule an appointment online - opens in new window"
              >
                <span className="relative z-10">Schedule Appointment</span>
                <span className="absolute inset-0 bg-white/20 transform -translate-x-full group-hover:translate-x-0 transition-transform duration-300" aria-hidden="true"></span>
              </a>
            </div>
          </div>
        </div>

        {/* Main Navigation */}
        <nav 
          className={`relative z-50 transition-all duration-300 ${
            isScrolled ? 'bg-white/95 backdrop-blur-sm shadow-lg' : 'bg-transparent'
          }`}
          role="navigation"
          aria-label="Main navigation"
        >
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center h-20">
              {/* Logo */}
              <a 
                href="#home" 
                onClick={() => handleMenuItemClick('#home')}
                className="relative z-20 transform transition-transform duration-300 hover:scale-105"
                aria-label="Change Up Cuts - Go to homepage"
              >
                <img 
                  src="https://i.postimg.cc/xCFnNRvc/Changup-Lo-GO.webp" 
                  alt="Change Up Cuts Barbershop and Beauty Center logo featuring company branding and professional styling" 
                  className={`transition-all duration-300 ${
                    isScrolled ? 'h-12' : 'h-16'
                  }`}
                  style={{
                    filter: isScrolled ? 'none' : 'drop-shadow(0 0 4px rgba(0,0,0,0.3))'
                  }}
                />
              </a>

              {/* Desktop Menu */}
              <div className="hidden lg:flex items-center space-x-8" role="menubar">
                {menuItems.map(item => (
                  <a 
                    key={item.href}
                    href={item.href}
                    onClick={() => handleMenuItemClick(item.href)}
                    className={`relative px-2 py-1 font-medium transition-colors duration-300 ${
                      activeItem === item.href
                        ? 'text-[#1A3C1F]'
                        : isScrolled ? 'text-gray-800' : 'text-white'
                    } hover:text-[#1A3C1F] group`}
                    role="menuitem"
                    aria-current={activeItem === item.href ? 'page' : undefined}
                    aria-label={`Navigate to ${item.label} section`}
                  >
                    {item.label}
                    <span 
                      className={`absolute bottom-0 left-0 w-full h-0.5 bg-[#1A3C1F] transform origin-left transition-transform duration-300 ${
                        activeItem === item.href ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'
                      }`}
                      aria-hidden="true"
                    ></span>
                  </a>
                ))}
                <a 
                  href="https://getsquire.com/booking/book/change-up-cuts-barbershop-and-beauty-center-north-charleston/barber/any/services"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="relative px-6 py-2 bg-[#1A3C1F] text-white rounded-md overflow-hidden group"
                  aria-label="Book appointment online - opens in new window"
                >
                  <span className="relative z-10">Book Now</span>
                  <span className="absolute inset-0 bg-[#152f18] transform -translate-x-full group-hover:translate-x-0 transition-transform duration-500 ease-out" aria-hidden="true"></span>
                </a>
              </div>

              {/* Mobile Menu Button */}
              <button
                className={`lg:hidden relative z-20 px-4 py-2 rounded-md transition-all duration-300 ${
                  isMobileMenuOpen 
                    ? 'bg-[#1A3C1F] text-white' 
                    : isScrolled 
                      ? 'text-gray-900 hover:bg-gray-100' 
                      : 'text-white hover:bg-white/10'
                }`}
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                aria-label={isMobileMenuOpen ? "Close mobile menu" : "Open mobile menu"}
                aria-expanded={isMobileMenuOpen}
                aria-controls="mobile-menu"
              >
                {isMobileMenuOpen ? (
                  <span className="font-medium">Close</span>
                ) : (
                  <div className="w-6 h-6 relative flex items-center justify-center">
                    <span className="absolute w-6 h-0.5 bg-current transform -translate-y-2" aria-hidden="true"></span>
                    <span className="absolute w-6 h-0.5 bg-current" aria-hidden="true"></span>
                    <span className="absolute w-6 h-0.5 bg-current transform translate-y-2" aria-hidden="true"></span>
                  </div>
                )}
              </button>
            </div>
          </div>

          {/* Mobile Menu Overlay */}
          <div 
            className={`lg:hidden fixed inset-0 bg-black/50 backdrop-blur-sm transition-opacity duration-500 ${
              isMobileMenuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
            }`}
            onClick={() => setIsMobileMenuOpen(false)}
            style={{ top: '80px' }}
            aria-hidden="true"
          />

          {/* Mobile Menu */}
          <div 
            id="mobile-menu"
            className={`lg:hidden fixed right-0 top-[80px] w-[300px] h-[calc(100vh-80px)] bg-white shadow-2xl transform transition-transform duration-500 ease-[cubic-bezier(0.4,0,0.2,1)] ${
              isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full'
            }`}
            role="menu"
            aria-label="Mobile navigation menu"
          >
            <div className="h-full overflow-y-auto py-6">
              <nav className="px-6 space-y-1" role="menubar">
                {menuItems.map(item => (
                  <a
                    key={item.href}
                    href={item.href}
                    className={`block py-3 px-4 text-lg transition-all duration-300 rounded-lg ${
                      activeItem === item.href
                        ? 'bg-[#1A3C1F]/10 text-[#1A3C1F]'
                        : 'text-gray-900 hover:bg-[#1A3C1F]/5'
                    }`}
                    onClick={() => handleMenuItemClick(item.href)}
                    role="menuitem"
                    aria-current={activeItem === item.href ? 'page' : undefined}
                    aria-label={`Navigate to ${item.label} section`}
                  >
                    <span className="relative">
                      {item.label}
                      {activeItem === item.href && (
                        <span className="absolute -left-4 top-1/2 -translate-y-1/2 w-2 h-2 bg-[#1A3C1F] rounded-full" aria-hidden="true"></span>
                      )}
                    </span>
                  </a>
                ))}
                
                {/* Mobile Hiring Button */}
                <button
                  onClick={handleHiringClick}
                  className="block w-full py-3 px-4 text-lg text-gray-900 hover:bg-[#1A3C1F]/5 transition-all duration-300 rounded-lg text-left"
                  role="menuitem"
                  aria-label="Apply for career opportunities"
                >
                  Now Hiring - Apply
                </button>
              </nav>

              {/* Contact Info Section */}
              <div className="px-6 mt-4">
                <div className="bg-gray-50 rounded-lg p-4" role="region" aria-label="Contact information">
                  <div className="mb-4">
                    <p className="text-sm text-gray-500 mb-1">Barbershop</p>
                    <a 
                      href="tel:+18437894430" 
                      className="text-xl font-medium text-[#1A3C1F] hover:text-[#152f18] transition-colors flex items-center"
                      aria-label="Call barbershop at (843) 789-4430"
                    >
                      (843) 789-4430
                    </a>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 mb-1">Beauty Center</p>
                    <a 
                      href="tel:+18437894360" 
                      className="text-xl font-medium text-[#1A3C1F] hover:text-[#152f18] transition-colors flex items-center"
                      aria-label="Call beauty center at (843) 789-4360"
                    >
                      (843) 789-4360
                    </a>
                  </div>
                </div>
              </div>
              
              <div className="absolute bottom-8 inset-x-6">
                <a
                  href="https://getsquire.com/booking/book/change-up-cuts-barbershop-and-beauty-center-north-charleston/barber/any/services"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full py-3 px-6 bg-[#1A3C1F] text-white text-center text-lg font-medium rounded-lg relative overflow-hidden group"
                  aria-label="Book appointment online - opens in new window"
                >
                  <span className="relative z-10">Book Now</span>
                  <span className="absolute inset-0 bg-[#152f18] transform -translate-x-full group-hover:translate-x-0 transition-transform duration-500 ease-out" aria-hidden="true"></span>
                </a>
              </div>
            </div>
          </div>
        </nav>
      </header>

      {/* Hiring Modal */}
      <HiringModal 
        isOpen={isHiringModalOpen} 
        onClose={() => setIsHiringModalOpen(false)} 
      />
    </>
  );
};