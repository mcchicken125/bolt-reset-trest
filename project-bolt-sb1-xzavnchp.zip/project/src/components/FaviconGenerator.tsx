import React from 'react';
import { Download, Scissors, Palette } from 'lucide-react';

export const FaviconGenerator = () => {
  const faviconSizes = [
    { size: '16x16', file: 'favicon-16x16.png', description: 'Browser tab icon (small)' },
    { size: '32x32', file: 'favicon-32x32.png', description: 'Browser tab icon (large)' },
    { size: '48x48', file: 'favicon-48x48.png', description: 'Windows shortcut icon' },
    { size: '64x64', file: 'favicon-64x64.png', description: 'Windows taskbar icon' },
    { size: '96x96', file: 'favicon-96x96.png', description: 'Android home screen' },
    { size: '128x128', file: 'favicon-128x128.png', description: 'Chrome Web Store' },
    { size: '180x180', file: 'apple-touch-icon-180x180.png', description: 'iPhone/iPad home screen' },
    { size: '192x192', file: 'android-chrome-192x192.png', description: 'Android Chrome' },
    { size: '512x512', file: 'android-chrome-512x512.png', description: 'Android Chrome (large)' }
  ];

  const designElements = [
    {
      icon: Scissors,
      title: 'Scissors Design',
      description: 'Clean, professional scissors icon in brand colors',
      colors: ['#1A3C1F (Brand Green)', '#D2B48C (Gold Accent)', '#FFFFFF (White)']
    },
    {
      icon: Palette,
      title: 'Color Scheme',
      description: 'Consistent with brand identity',
      colors: ['Primary: #1A3C1F', 'Secondary: #D2B48C', 'Background: Transparent/White']
    }
  ];

  return (
    <div className="bg-white py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-4 text-[#1A3C1F]">Favicon Design System</h1>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Professional favicon design for Change Up Cuts barbershop, optimized for all devices and platforms.
            </p>
          </div>

          {/* Design Preview */}
          <div className="bg-gray-50 rounded-lg p-8 mb-12">
            <h2 className="text-2xl font-bold mb-6 text-center">Favicon Preview</h2>
            <div className="flex justify-center items-center gap-8 flex-wrap">
              {/* Large preview */}
              <div className="text-center">
                <div className="w-32 h-32 bg-[#1A3C1F] rounded-full flex items-center justify-center mb-4 shadow-lg">
                  <Scissors className="w-16 h-16 text-[#D2B48C]" />
                </div>
                <p className="text-sm text-gray-600">Large (128x128)</p>
              </div>

              {/* Medium preview */}
              <div className="text-center">
                <div className="w-16 h-16 bg-[#1A3C1F] rounded-full flex items-center justify-center mb-4 shadow-lg">
                  <Scissors className="w-8 h-8 text-[#D2B48C]" />
                </div>
                <p className="text-sm text-gray-600">Medium (64x64)</p>
              </div>

              {/* Small preview */}
              <div className="text-center">
                <div className="w-8 h-8 bg-[#1A3C1F] rounded-full flex items-center justify-center mb-4 shadow-lg">
                  <Scissors className="w-4 h-4 text-[#D2B48C]" />
                </div>
                <p className="text-sm text-gray-600">Small (32x32)</p>
              </div>

              {/* Tiny preview */}
              <div className="text-center">
                <div className="w-4 h-4 bg-[#1A3C1F] rounded-full flex items-center justify-center mb-4 shadow-lg">
                  <div className="w-2 h-2 bg-[#D2B48C] rounded-full"></div>
                </div>
                <p className="text-sm text-gray-600">Tiny (16x16)</p>
              </div>
            </div>
          </div>

          {/* Design Elements */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            {designElements.map((element, index) => (
              <div key={index} className="bg-white border border-gray-200 rounded-lg p-6">
                <div className="flex items-center gap-3 mb-4">
                  <element.icon className="w-6 h-6 text-[#1A3C1F]" />
                  <h3 className="text-xl font-bold">{element.title}</h3>
                </div>
                <p className="text-gray-600 mb-4">{element.description}</p>
                <div className="space-y-2">
                  {element.colors.map((color, colorIndex) => (
                    <div key={colorIndex} className="text-sm font-mono text-gray-700">
                      {color}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Required Sizes */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold mb-6">Required Favicon Sizes</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {faviconSizes.map((favicon, index) => (
                <div key={index} className="bg-white border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-[#1A3C1F]">{favicon.size}</span>
                    <Download className="w-4 h-4 text-gray-400" />
                  </div>
                  <p className="text-sm text-gray-600 mb-2">{favicon.file}</p>
                  <p className="text-xs text-gray-500">{favicon.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Implementation Notes */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
            <h3 className="text-lg font-bold mb-4 text-blue-800">Implementation Notes</h3>
            <div className="space-y-3 text-blue-700">
              <p>• SVG favicon provides the best scalability and smallest file size</p>
              <p>• PNG fallbacks ensure compatibility with older browsers</p>
              <p>• Apple touch icons optimized for iOS home screen bookmarks</p>
              <p>• Android Chrome icons support adaptive design</p>
              <p>• Safari pinned tab uses monochrome SVG for consistency</p>
              <p>• All icons maintain brand recognition at any size</p>
            </div>
          </div>

          {/* Current Favicon Files */}
          <div className="mt-12">
            <h2 className="text-2xl font-bold mb-6">Current Favicon Files</h2>
            <div className="bg-gray-900 rounded-lg p-6 text-white overflow-x-auto">
              <pre className="text-sm">
{`📁 public/
├── favicon.ico                          # Main favicon file
└── 📁 icons/
    ├── favicon.svg                      # Scalable vector favicon ✨ NEW
    ├── favicon-16x16.png               # Browser tab (small)
    ├── favicon-32x32.png               # Browser tab (large)
    ├── safari-pinned-tab.svg           # Safari pinned tab ✨ UPDATED
    ├── apple-touch-icon-57x57.png      # iPhone 3G/3GS
    ├── apple-touch-icon-60x60.png      # iPhone 4
    ├── apple-touch-icon-72x72.png      # iPad 1/2
    ├── apple-touch-icon-76x76.png      # iPad Mini/Air
    ├── apple-touch-icon-114x114.png    # iPhone 4 Retina
    ├── apple-touch-icon-120x120.png    # iPhone 5/6
    ├── apple-touch-icon-144x144.png    # iPad Retina
    ├── apple-touch-icon-152x152.png    # iPad Air/Mini Retina
    ├── apple-touch-icon-180x180.png    # iPhone 6 Plus/X
    ├── android-chrome-36x36.png        # Android (small)
    ├── android-chrome-48x48.png        # Android
    ├── android-chrome-72x72.png        # Android
    ├── android-chrome-96x96.png        # Android
    ├── android-chrome-144x144.png      # Android
    ├── android-chrome-192x192.png      # Android Chrome
    ├── android-chrome-256x256.png      # Android
    ├── android-chrome-384x384.png      # Android
    ├── android-chrome-512x512.png      # Android Chrome (large)
    └── mstile-*.png                     # Windows tiles`}
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};