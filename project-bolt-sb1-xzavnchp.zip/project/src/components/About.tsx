import React from 'react';

export const About = () => {
  return (
    <section 
      className="bg-white min-h-[60vh] flex" 
      id="about" 
      role="region" 
      aria-labelledby="about-heading"
    >
      <div className="flex flex-col lg:flex-row w-full">
        <div className="w-full lg:w-1/2 p-12 flex items-center">
          <div>
            <h2 id="about-heading" className="text-3xl md:text-4xl lg:text-5xl font-display font-bold mb-4">
              Change Up Cuts Barber Shop
            </h2>
            <div className="w-24 h-1 bg-barber-secondary mb-6" aria-hidden="true"></div>
            <p className="text-gray-600 text-base md:text-lg leading-relaxed">
              Change Up Cuts Barbershop and Beauty Center is the brainchild of Feidin Santana and Abdoni Tejada. Founded in July 2021, Change Up Cuts is the fastest growing combination barbershop and hair salon in the greater Charleston, South Carolina area. Our team of experienced professionals provide quality, 5-star services to a diverse clientele.
            </p>
          </div>
        </div>
        <div className="relative w-full lg:w-1/2 min-h-[450px] lg:min-h-full overflow-hidden">
          <div 
            className="absolute inset-0 z-10"
            style={{
              background: window.innerWidth < 1024 
                ? 'linear-gradient(to right, rgba(255,255,255,1) 0%, rgba(255,255,255,0.42) 40%, rgba(255,255,255,0) 100%)'
                : 'linear-gradient(to right, rgba(255,255,255,1) 0%, rgba(255,255,255,0.6) 40%, rgba(255,255,255,0) 100%)'
            }}
            aria-hidden="true"
          ></div>
          <div 
            className="absolute inset-0"
            style={{
              backgroundImage: `url('https://i.postimg.cc/XJjWkxX0/First.webp')`,
              backgroundPosition: 'center',
              backgroundSize: 'cover',
              backgroundRepeat: 'no-repeat',
              filter: 'grayscale(100%)'
            }}
            role="img"
            aria-label="Professional barber providing quality service in our welcoming environment"
          ></div>
        </div>
      </div>
    </section>
  );
};