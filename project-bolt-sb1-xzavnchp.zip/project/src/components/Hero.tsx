import React from 'react';
import { OptimizedBackgroundImage } from './OptimizedImage';

export const Hero = () => {
  return (
    <OptimizedBackgroundImage
      src="https://i.postimg.cc/sgs5tj3z/Third.webp"
      priority={true}
      className="relative min-h-screen flex items-center justify-center bg-cover bg-center"
    >
      <section
        id="home"
        role="banner"
        aria-label="Welcome to Change Up Cuts Barbershop"
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 to-black/50" aria-hidden="true"></div>
        
        <div className="container relative z-10 px-4 mx-auto text-center mt-20">
          <div className="flex flex-col items-center max-w-4xl mx-auto">
            <h1 className="font-display text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight">
              Welcome To The New<br />
              Standard Of<br />
              Barbering
            </h1>
            <p className="text-xl md:text-2xl text-white/90 mb-12 max-w-2xl" role="doc-subtitle">
              Full Service Barbershop, Hair Salon & Nail Salon in North Charleston, SC
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <a 
                href="https://getsquire.com/booking/book/change-up-cuts-barbershop-and-beauty-center-north-charleston/barber/any/services"
                target="_blank"
                rel="noopener noreferrer" 
                className="px-8 py-4 bg-[#1A3C1F] text-white text-lg font-medium hover:bg-[#1A3C1F]/90 transition-all rounded-md shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
                aria-label="Schedule an appointment online - opens in new window"
              >
                Schedule Appointment
              </a>
            </div>
            <p className="text-white/70 text-lg mt-12 tracking-wide font-light" lang="es" aria-label="Spanish language services available">
              ¡HABLAMOS ESPAÑOL!
            </p>
          </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black/80 to-transparent" aria-hidden="true"></div>
      </section>
    </OptimizedBackgroundImage>
  );
};