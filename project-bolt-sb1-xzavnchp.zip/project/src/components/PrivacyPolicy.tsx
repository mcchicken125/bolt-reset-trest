import React, { useState, useEffect } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { MetaTags } from './MetaTags';

export const PrivacyPolicy = () => {
  const [activeSection, setActiveSection] = useState<string | null>(null);
  const [activeNav, setActiveNav] = useState('introduction');

  const sections = [
    {
      id: 'introduction',
      title: '1. Introduction',
      content: `Change Up Cuts Barbershop and Beauty Center ("we," "our," or "us") respects your privacy and is committed to protecting your personal data. This privacy policy explains how we collect, use, and protect your personal information when you use our services or visit our website.`
    },
    {
      id: 'information-collect',
      title: '2. Information We Collect',
      content: `We collect information that you provide directly to us, including:`,
      list: [
        'Name and contact information',
        'Appointment details and preferences',
        'Payment information',
        'Communication history',
        'Feedback and reviews'
      ]
    },
    {
      id: 'information-use',
      title: '3. How We Use Your Information',
      content: `We use your information to:`,
      list: [
        'Process and manage your appointments',
        'Communicate with you about our services',
        'Improve our services and customer experience',
        'Send promotional materials (with your consent)',
        'Comply with legal obligations'
      ]
    },
    {
      id: 'information-sharing',
      title: '4. Information Sharing',
      content: `We do not sell or rent your personal information to third parties. We may share your information with:`,
      list: [
        'Service providers who assist in our operations',
        'Legal authorities when required by law',
        'Business partners with your consent'
      ]
    },
    {
      id: 'your-rights',
      title: '5. Your Rights',
      content: `You have the right to:`,
      list: [
        'Access your personal information',
        'Correct inaccurate information',
        'Request deletion of your information',
        'Opt-out of marketing communications',
        'Lodge a complaint with supervisory authorities'
      ]
    },
    {
      id: 'contact',
      title: '6. Contact Us',
      content: `If you have questions about this privacy policy or our practices, please contact us at:`
    }
  ];

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY + 100;
      
      for (const section of sections) {
        const element = document.getElementById(section.id);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveNav(section.id);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const offset = 100;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <div className="bg-white min-h-screen pt-32 pb-16">
      <MetaTags
        title="Privacy Policy"
        description="Read the privacy policy for Change Up Cuts Barbershop and Beauty Center. Learn how we collect, use, and protect your personal information."
        keywords="privacy policy, data protection, Change Up Cuts privacy, personal information, barbershop privacy policy"
        type="article"
        canonicalPath="/privacy"
        author="Change Up Cuts Legal Team"
        publishedTime="2021-07-01T00:00:00Z"
        modifiedTime={new Date().toISOString()}
      />
      
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Sidebar Navigation */}
            <div className="lg:w-1/4">
              <div className="sticky top-32 bg-white p-6 rounded-lg shadow-md">
                <h2 className="text-xl font-bold mb-4">Table of Contents</h2>
                <nav className="space-y-2">
                  {sections.map((section) => (
                    <button
                      key={section.id}
                      onClick={() => scrollToSection(section.id)}
                      className={`block w-full text-left px-4 py-2 rounded-lg transition-colors ${
                        activeNav === section.id
                          ? 'bg-[#1A3C1F] text-white'
                          : 'hover:bg-gray-100'
                      }`}
                    >
                      {section.title}
                    </button>
                  ))}
                </nav>
              </div>
            </div>

            {/* Main Content */}
            <div className="lg:w-3/4">
              <h1 className="text-4xl font-bold mb-8">Privacy Policy</h1>
              <p className="text-lg text-gray-600 mb-8">
                Last updated: {new Date().toLocaleDateString()}
              </p>

              {sections.map((section) => (
                <section
                  key={section.id}
                  id={section.id}
                  className="mb-8 bg-white rounded-lg shadow-md overflow-hidden"
                >
                  <button
                    className={`w-full p-6 text-left bg-gray-50 flex justify-between items-center ${
                      activeSection === section.id ? 'border-b' : ''
                    }`}
                    onClick={() => setActiveSection(activeSection === section.id ? null : section.id)}
                  >
                    <h2 className="text-2xl font-bold">{section.title}</h2>
                    {activeSection === section.id ? (
                      <ChevronUp className="w-6 h-6 text-gray-500" />
                    ) : (
                      <ChevronDown className="w-6 h-6 text-gray-500" />
                    )}
                  </button>

                  <div
                    className={`transition-all duration-300 ease-in-out ${
                      activeSection === section.id ? 'max-h-[1000px] opacity-100' : 'max-h-0 opacity-0'
                    } overflow-hidden`}
                  >
                    <div className="p-6">
                      <p className="mb-4">{section.content}</p>
                      {section.list && (
                        <ul className="list-disc pl-6 space-y-2">
                          {section.list.map((item, index) => (
                            <li key={index} className="text-gray-700">{item}</li>
                          ))}
                        </ul>
                      )}
                      {section.id === 'contact' && (
                        <div className="bg-gray-50 p-6 rounded-lg mt-4">
                          <p>Change Up Cuts Barbershop and Beauty Center</p>
                          <a 
                            href="https://www.google.com/maps/place/Change+Up+Cuts+Barbershop+%26+Beauty+Center/@32.9044054,-80.0203215,17.05z/data=!4m6!3m5!1s0x88fe636c08e7b0a3:0x80d92ec6413760e4!8m2!3d32.904006!4d-80.0181136!16s%2Fg%2F11q8vcl_gr?entry=ttu&g_ep=EgoyMDI1MDYwNC4wIKXMDSoASAFQAw%3D%3D"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-[#1A3C1F] hover:text-[#152f18] transition-colors"
                            aria-label="View our location on Google Maps"
                          >
                            <p>5900 Rivers Avenue, Suite D-4</p>
                            <p>North Charleston, SC 29406</p>
                          </a>
                          <p>Email: <a href="mailto:info@changeupcuts.com" className="text-[#1A3C1F] hover:text-[#152f18]">info@changeupcuts.com</a></p>
                          <p>Phone: <a href="tel:+18437894430" className="text-[#1A3C1F] hover:text-[#152f18]">(843) 789-4430</a></p>
                        </div>
                      )}
                    </div>
                  </div>
                </section>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};