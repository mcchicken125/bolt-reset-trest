import React from 'react';
import { Helmet } from 'react-helmet-async';

interface MetaTagsProps {
  title?: string;
  description?: string;
  keywords?: string;
  image?: string;
  url?: string;
  type?: string;
  twitterCard?: 'summary' | 'summary_large_image' | 'app' | 'player';
  author?: string;
  publishedTime?: string;
  modifiedTime?: string;
  canonicalPath?: string;
  serviceType?: 'barbershop' | 'beauty' | 'general';
}

export const MetaTags: React.FC<MetaTagsProps> = ({
  title,
  description,
  keywords,
  image,
  url = "https://www.changeupcuts.com",
  type = "website",
  twitterCard = "summary_large_image",
  author = "Change Up Cuts",
  publishedTime,
  modifiedTime,
  canonicalPath,
  serviceType = 'general'
}) => {
  // CRITICAL: Preserve existing SEO-optimized defaults that are already ranking
  const defaultTitle = "Change Up Cuts: Salon and Barber Shop | North Charleston, SC";
  const defaultDescription = "Change Up Cuts is a full service barbershop, hair salon and nail salon in a fun, family-friendly, multicultural environment. We are a one stop shop for the entire family with experienced stylists and barbers.";
  const defaultKeywords = "barbershop North Charleston, beauty salon North Charleston, multicultural barber, Dominican salon, haircuts, nail services, Change Up Cuts, men's grooming, women's haircuts, beard trim, hot towel shave, hair salon near me, barber shop near me, family barbershop";
  
  // CRITICAL: Preserve exact existing title patterns for SEO consistency
  const finalTitle = title ? `${title} - Change Up Cuts: Salon and Barber Shop | North Charleston, SC` : defaultTitle;
  const finalDescription = description || defaultDescription;
  const finalKeywords = keywords || defaultKeywords;
  
  // CRITICAL: Ensure canonical URLs match existing domain structure exactly
  const getCanonicalUrl = () => {
    const baseUrl = "https://www.changeupcuts.com";
    
    if (canonicalPath) {
      // For SEO preservation, maintain existing URL patterns
      return `${baseUrl}${canonicalPath}`;
    }
    
    // Preserve existing hash-based navigation for SEO consistency
    const hash = window.location.hash.toLowerCase();
    switch (hash) {
      case '#about':
        return `${baseUrl}/`; // Keep main domain authority
      case '#services':
        return `${baseUrl}/`; // Keep main domain authority
      case '#careers':
        return `${baseUrl}/`; // Keep main domain authority
      case '#contact':
        return `${baseUrl}/`; // Keep main domain authority
      case '#gallery':
        return `${baseUrl}/`; // Keep main domain authority
      case '#privacy':
        return `${baseUrl}/privacy`;
      case '#terms':
        return `${baseUrl}/terms`;
      case '#sitemap':
        return `${baseUrl}/sitemap`;
      default:
        return baseUrl;
    }
  };

  const canonicalUrl = getCanonicalUrl();
  
  // Preserve existing social image strategy for consistency
  const getSocialImage = () => {
    if (image) return image;
    
    const hash = window.location.hash.toLowerCase();
    switch (hash) {
      case '#about':
        return "https://i.postimg.cc/xT9nxZ7j/doyoubelieveusnow.webp";
      case '#services':
        return "https://i.postimg.cc/sgs5tj3z/Third.webp";
      case '#careers':
        return "https://i.postimg.cc/pd45BtBr/10.webp";
      case '#contact':
        return "https://i.postimg.cc/J4Y1qzf1/googlemaps.png";
      case '#gallery':
        return "https://i.postimg.cc/xCcvt6nb/Fourth.webp";
      default:
        return "https://i.postimg.cc/xCFnNRvc/Changup-Lo-GO.webp";
    }
  };

  const socialImage = getSocialImage();

  // Enhanced individual service schemas (additive, not replacement)
  const getBarbershopServices = () => [
    {
      "@type": "Service",
      "@id": `${canonicalUrl}#gentlemens-haircut`,
      "name": "Gentleman's Haircut",
      "description": "Professional haircuts for men including classic cuts, modern styles, and precision styling. Skilled in all hair types and textures.",
      "provider": {
        "@type": "HairSalon",
        "name": "Change Up Cuts"
      },
      "serviceType": "Haircut",
      "category": "Men's Grooming",
      "offers": {
        "@type": "Offer",
        "price": "28.00",
        "priceCurrency": "USD",
        "availability": "https://schema.org/InStock",
        "validFrom": "2021-07-01",
        "url": `${canonicalUrl}#services`
      },
      "serviceArea": {
        "@type": "GeoCircle",
        "geoMidpoint": {
          "@type": "GeoCoordinates",
          "latitude": 32.8546,
          "longitude": -79.9748
        },
        "geoRadius": "25000"
      },
      "hoursAvailable": [
        {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday"],
          "opens": "10:00",
          "closes": "19:30"
        },
        {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": ["Friday", "Saturday"],
          "opens": "09:00",
          "closes": "20:00"
        },
        {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": "Sunday",
          "opens": "09:00",
          "closes": "16:00"
        }
      ],
      "audience": {
        "@type": "PeopleAudience",
        "suggestedGender": "Male",
        "suggestedMinAge": 13
      }
    },
    {
      "@type": "Service",
      "@id": `${canonicalUrl}#fade-haircut`,
      "name": "Fade Haircut",
      "description": "Precision fade cuts including low fades, mid fades, high fades, and skin fades. Expert technique for clean, sharp lines.",
      "provider": {
        "@type": "HairSalon",
        "name": "Change Up Cuts"
      },
      "serviceType": "Haircut",
      "category": "Men's Grooming",
      "offers": {
        "@type": "Offer",
        "price": "30.00",
        "priceCurrency": "USD",
        "availability": "https://schema.org/InStock",
        "validFrom": "2021-07-01",
        "url": `${canonicalUrl}#services`
      },
      "serviceArea": {
        "@type": "GeoCircle",
        "geoMidpoint": {
          "@type": "GeoCoordinates",
          "latitude": 32.8546,
          "longitude": -79.9748
        },
        "geoRadius": "25000"
      },
      "audience": {
        "@type": "PeopleAudience",
        "suggestedGender": "Male",
        "suggestedMinAge": 13
      }
    },
    {
      "@type": "Service",
      "@id": `${canonicalUrl}#beard-grooming`,
      "name": "Beard Grooming & Trimming",
      "description": "Professional beard trimming, shaping, and styling. Includes beard oil treatment and precision line-ups.",
      "provider": {
        "@type": "HairSalon",
        "name": "Change Up Cuts"
      },
      "serviceType": "Grooming",
      "category": "Men's Grooming",
      "offers": {
        "@type": "Offer",
        "price": "15.00",
        "priceCurrency": "USD",
        "availability": "https://schema.org/InStock",
        "validFrom": "2021-07-01",
        "url": `${canonicalUrl}#services`
      },
      "serviceArea": {
        "@type": "GeoCircle",
        "geoMidpoint": {
          "@type": "GeoCoordinates",
          "latitude": 32.8546,
          "longitude": -79.9748
        },
        "geoRadius": "25000"
      },
      "audience": {
        "@type": "PeopleAudience",
        "suggestedGender": "Male",
        "suggestedMinAge": 16
      }
    },
    {
      "@type": "Service",
      "@id": `${canonicalUrl}#kids-haircut`,
      "name": "Children's Haircuts",
      "description": "Kid-friendly haircuts in a comfortable environment. Patient, experienced stylists who work well with children.",
      "provider": {
        "@type": "HairSalon",
        "name": "Change Up Cuts"
      },
      "serviceType": "Haircut",
      "category": "Children's Services",
      "offers": {
        "@type": "Offer",
        "price": "20.00",
        "priceCurrency": "USD",
        "availability": "https://schema.org/InStock",
        "validFrom": "2021-07-01",
        "url": `${canonicalUrl}#services`
      },
      "serviceArea": {
        "@type": "GeoCircle",
        "geoMidpoint": {
          "@type": "GeoCoordinates",
          "latitude": 32.8546,
          "longitude": -79.9748
        },
        "geoRadius": "25000"
      },
      "audience": {
        "@type": "PeopleAudience",
        "suggestedMaxAge": 12
      }
    },
    {
      "@type": "Service",
      "@id": `${canonicalUrl}#hot-towel-shave`,
      "name": "Hot Towel Shave",
      "description": "Traditional hot towel shave service with straight razor technique. Includes pre-shave oil and post-shave balm.",
      "provider": {
        "@type": "HairSalon",
        "name": "Change Up Cuts"
      },
      "serviceType": "Shaving",
      "category": "Men's Grooming",
      "offers": {
        "@type": "Offer",
        "price": "35.00",
        "priceCurrency": "USD",
        "availability": "https://schema.org/InStock",
        "validFrom": "2021-07-01",
        "url": `${canonicalUrl}#services`
      },
      "serviceArea": {
        "@type": "GeoCircle",
        "geoMidpoint": {
          "@type": "GeoCoordinates",
          "latitude": 32.8546,
          "longitude": -79.9748
        },
        "geoRadius": "25000"
      },
      "audience": {
        "@type": "PeopleAudience",
        "suggestedGender": "Male",
        "suggestedMinAge": 18
      }
    }
  ];

  const getBeautyServices = () => [
    {
      "@type": "Service",
      "@id": `${canonicalUrl}#hair-styling`,
      "name": "Professional Hair Styling",
      "description": "Expert hair styling for women including cuts, blowouts, updos, and special occasion styling.",
      "provider": {
        "@type": "HairSalon",
        "name": "Change Up Cuts Beauty Center"
      },
      "serviceType": "Hair Styling",
      "category": "Beauty Services",
      "offers": {
        "@type": "Offer",
        "priceRange": "$40-$80",
        "priceCurrency": "USD",
        "availability": "https://schema.org/InStock",
        "validFrom": "2021-07-01",
        "url": `${canonicalUrl}#careers`
      },
      "serviceArea": {
        "@type": "GeoCircle",
        "geoMidpoint": {
          "@type": "GeoCoordinates",
          "latitude": 32.8546,
          "longitude": -79.9748
        },
        "geoRadius": "25000"
      },
      "audience": {
        "@type": "PeopleAudience",
        "suggestedGender": "Female",
        "suggestedMinAge": 13
      }
    },
    {
      "@type": "Service",
      "@id": `${canonicalUrl}#hair-coloring`,
      "name": "Hair Coloring & Highlights",
      "description": "Professional hair coloring services including highlights, lowlights, full color, color correction, and balayage.",
      "provider": {
        "@type": "HairSalon",
        "name": "Change Up Cuts Beauty Center"
      },
      "serviceType": "Hair Coloring",
      "category": "Beauty Services",
      "offers": {
        "@type": "Offer",
        "priceRange": "$45-$120",
        "priceCurrency": "USD",
        "availability": "https://schema.org/InStock",
        "validFrom": "2021-07-01",
        "url": `${canonicalUrl}#careers`
      },
      "serviceArea": {
        "@type": "GeoCircle",
        "geoMidpoint": {
          "@type": "GeoCoordinates",
          "latitude": 32.8546,
          "longitude": -79.9748
        },
        "geoRadius": "25000"
      },
      "audience": {
        "@type": "PeopleAudience",
        "suggestedMinAge": 16
      }
    },
    {
      "@type": "Service",
      "@id": `${canonicalUrl}#makeup-services`,
      "name": "Professional Makeup Services",
      "description": "Professional makeup application for special events, weddings, photo shoots, and everyday looks.",
      "provider": {
        "@type": "HairSalon",
        "name": "Change Up Cuts Beauty Center"
      },
      "serviceType": "Makeup",
      "category": "Beauty Services",
      "offers": {
        "@type": "Offer",
        "priceRange": "$35-$75",
        "priceCurrency": "USD",
        "availability": "https://schema.org/InStock",
        "validFrom": "2021-07-01",
        "url": `${canonicalUrl}#careers`
      },
      "serviceArea": {
        "@type": "GeoCircle",
        "geoMidpoint": {
          "@type": "GeoCoordinates",
          "latitude": 32.8546,
          "longitude": -79.9748
        },
        "geoRadius": "25000"
      },
      "audience": {
        "@type": "PeopleAudience",
        "suggestedMinAge": 13
      }
    }
  ];

  // CRITICAL: Enhanced structured data that PRESERVES existing SEO signals
  const getStructuredData = () => {
    const baseStructure = {
      "@context": "https://schema.org",
      "@type": "HairSalon",
      "name": "Change Up Cuts",
      "alternateName": "Change Up Cuts Barbershop and Beauty Center",
      "url": canonicalUrl,
      "logo": {
        "@type": "ImageObject",
        "url": "https://i.postimg.cc/xCFnNRvc/Changup-Lo-GO.webp",
        "width": 400,
        "height": 400
      },
      "image": {
        "@type": "ImageObject",
        "url": socialImage,
        "width": 1200,
        "height": 630
      },
      "description": finalDescription,
      "slogan": "Welcome To The New Standard Of Barbering",
      "founder": [
        {
          "@type": "Person",
          "name": "Feidin Santana"
        },
        {
          "@type": "Person",
          "name": "Abdoni Tejada"
        }
      ],
      "foundingDate": "2021-07-01",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "5900 Rivers Avenue, Suite D-4",
        "addressLocality": "North Charleston",
        "addressRegion": "SC",
        "postalCode": "29406",
        "addressCountry": "US"
      },
      "geo": {
        "@type": "GeoCoordinates",
        "latitude": 32.8546,
        "longitude": -79.9748
      },
      "telephone": "+18437894430",
      "email": "info@changeupcuts.com",
      "openingHoursSpecification": [
        {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday"],
          "opens": "10:00",
          "closes": "19:30"
        },
        {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": ["Friday", "Saturday"],
          "opens": "09:00",
          "closes": "20:00"
        },
        {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": "Sunday",
          "opens": "09:00",
          "closes": "16:00"
        }
      ],
      "priceRange": "$$",
      "paymentAccepted": ["Cash", "Credit Card", "Debit Card"],
      "currenciesAccepted": "USD",
      "serviceArea": {
        "@type": "GeoCircle",
        "geoMidpoint": {
          "@type": "GeoCoordinates",
          "latitude": 32.8546,
          "longitude": -79.9748
        },
        "geoRadius": "25000"
      },
      "knowsLanguage": ["English", "Spanish"],
      "amenityFeature": [
        {
          "@type": "LocationFeatureSpecification",
          "name": "Free Parking",
          "value": true
        },
        {
          "@type": "LocationFeatureSpecification",
          "name": "Walk-ins Welcome",
          "value": true
        },
        {
          "@type": "LocationFeatureSpecification",
          "name": "Wheelchair Accessible",
          "value": true
        },
        {
          "@type": "LocationFeatureSpecification",
          "name": "Air Conditioning",
          "value": true
        },
        {
          "@type": "LocationFeatureSpecification",
          "name": "WiFi Available",
          "value": true
        }
      ],
      "hasOfferCatalog": {
        "@type": "OfferCatalog",
        "name": "Professional Barbershop and Beauty Services",
        "itemListElement": [
          ...getBarbershopServices().map(service => ({
            "@type": "Offer",
            "itemOffered": service
          })),
          ...(serviceType === 'beauty' || serviceType === 'general' ? getBeautyServices().map(service => ({
            "@type": "Offer",
            "itemOffered": service
          })) : [])
        ]
      },
      "sameAs": [
        "https://www.facebook.com/changeupcuts",
        "https://www.instagram.com/changeupcuts",
        "https://twitter.com/changeupcuts",
        "https://www.facebook.com/changeupcutsbeautycenter",
        "https://www.instagram.com/Changeupcutsbeautycenter/"
      ],
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": "5.0",
        "reviewCount": "50",
        "bestRating": "5",
        "worstRating": "1"
      },
      "review": [
        {
          "@type": "Review",
          "author": {
            "@type": "Person",
            "name": "Jerry Moore"
          },
          "reviewRating": {
            "@type": "Rating",
            "ratingValue": "5"
          },
          "reviewBody": "One of the best haircuts and service. Awesome!",
          "datePublished": "2025-05-18"
        },
        {
          "@type": "Review",
          "author": {
            "@type": "Person",
            "name": "Adrian Serna"
          },
          "reviewRating": {
            "@type": "Rating",
            "ratingValue": "5"
          },
          "reviewBody": "They all are really great barbers",
          "datePublished": "2025-04-01"
        },
        {
          "@type": "Review",
          "author": {
            "@type": "Person",
            "name": "Justin Stas"
          },
          "reviewRating": {
            "@type": "Rating",
            "ratingValue": "5"
          },
          "reviewBody": "Best barber shop I've been to in the Charleston Area",
          "datePublished": "2025-04-25"
        }
      ],
      "makesOffer": serviceType === 'barbershop' ? getBarbershopServices() : serviceType === 'beauty' ? getBeautyServices() : [...getBarbershopServices(), ...getBeautyServices()]
    };

    return baseStructure;
  };

  // Service-specific structured data (ADDITIVE enhancement)
  const getServiceSpecificData = () => {
    if (serviceType === 'barbershop') {
      return {
        "@context": "https://schema.org",
        "@type": "ItemList",
        "name": "Barbershop Services",
        "description": "Complete list of professional barbering services offered at Change Up Cuts",
        "itemListElement": getBarbershopServices().map((service, index) => ({
          "@type": "ListItem",
          "position": index + 1,
          "item": service
        }))
      };
    }

    if (serviceType === 'beauty') {
      return {
        "@context": "https://schema.org",
        "@type": "ItemList",
        "name": "Beauty Center Services",
        "description": "Complete list of professional beauty services offered at Change Up Cuts Beauty Center",
        "itemListElement": getBeautyServices().map((service, index) => ({
          "@type": "ListItem",
          "position": index + 1,
          "item": service
        }))
      };
    }

    return null;
  };

  // FAQ Schema for enhanced search results (ADDITIVE SEO benefit)
  const getFAQSchema = () => ({
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "Do you accept walk-ins?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Yes, we welcome walk-ins! However, appointments are recommended to ensure availability and minimize wait times."
        }
      },
      {
        "@type": "Question",
        "name": "What are your hours of operation?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Barbershop: Monday-Thursday 10am-7:30pm, Friday-Saturday 9am-8pm, Sunday 9am-4pm. Beauty Center: Monday-Thursday 10am-5pm, Friday-Saturday 9am-6pm, Sunday Closed."
        }
      },
      {
        "@type": "Question",
        "name": "Do you speak Spanish?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "¡Sí! We are bilingual and provide services in both English and Spanish."
        }
      },
      {
        "@type": "Question",
        "name": "What payment methods do you accept?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "We accept cash, credit cards, and debit cards for your convenience."
        }
      },
      {
        "@type": "Question",
        "name": "Do you offer services for children?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Yes, we specialize in children's haircuts and create a comfortable, fun environment for our youngest clients."
        }
      }
    ]
  });

  return (
    <Helmet>
      {/* CRITICAL: Preserve existing meta tag structure for SEO consistency */}
      <html lang="en" />
      <title>{finalTitle}</title>
      <meta name="title" content={finalTitle} />
      <meta name="description" content={finalDescription} />
      <meta name="keywords" content={finalKeywords} />
      <meta name="author" content={author} />
      <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1" />
      <meta name="language" content="English" />
      <meta name="revisit-after" content="7 days" />
      
      {/* CRITICAL: Canonical URL preservation for existing domain authority */}
      <link rel="canonical" href={canonicalUrl} />
      
      {/* SEO-safe hreflang preservation */}
      <link rel="alternate" hrefLang="en" href={canonicalUrl} />
      <link rel="alternate" hrefLang="es" href={canonicalUrl} />
      <link rel="alternate" hrefLang="x-default" href={canonicalUrl} />

      {/* PRESERVED Open Graph Meta Tags (exact format) */}
      <meta property="og:type" content={type} />
      <meta property="og:url" content={canonicalUrl} />
      <meta property="og:title" content={finalTitle} />
      <meta property="og:description" content={finalDescription} />
      <meta property="og:image" content={socialImage} />
      <meta property="og:image:secure_url" content={socialImage} />
      <meta property="og:image:alt" content={`${title || 'Change Up Cuts'} - Premier Multicultural Barbershop & Beauty Center in North Charleston, SC`} />
      <meta property="og:image:width" content="1200" />
      <meta property="og:image:height" content="630" />
      <meta property="og:image:type" content="image/webp" />
      <meta property="og:site_name" content="Change Up Cuts" />
      <meta property="og:locale" content="en_US" />
      <meta property="og:locale:alternate" content="es_US" />
      
      {/* Enhanced Facebook Specific */}
      <meta property="fb:app_id" content="your-facebook-app-id" />
      
      {/* PRESERVE business specific Open Graph */}
      {type === 'business.business' && (
        <>
          <meta property="business:contact_data:street_address" content="5900 Rivers Avenue, Suite D-4" />
          <meta property="business:contact_data:locality" content="North Charleston" />
          <meta property="business:contact_data:region" content="SC" />
          <meta property="business:contact_data:postal_code" content="29406" />
          <meta property="business:contact_data:country_name" content="United States" />
          <meta property="place:location:latitude" content="32.8546" />
          <meta property="place:location:longitude" content="-79.9748" />
        </>
      )}

      {/* Article specific Open Graph */}
      {type === 'article' && (
        <>
          <meta property="article:author" content={author} />
          <meta property="article:publisher" content="https://www.facebook.com/changeupcuts" />
          {publishedTime && <meta property="article:published_time" content={publishedTime} />}
          {modifiedTime && <meta property="article:modified_time" content={modifiedTime} />}
          <meta property="article:section" content="Beauty & Personal Care" />
          <meta property="article:tag" content="barbershop" />
          <meta property="article:tag" content="beauty salon" />
          <meta property="article:tag" content="haircuts" />
          <meta property="article:tag" content="North Charleston" />
        </>
      )}

      {/* PRESERVED Twitter Card Meta Tags */}
      <meta name="twitter:card" content={twitterCard} />
      <meta name="twitter:url" content={canonicalUrl} />
      <meta name="twitter:title" content={finalTitle} />
      <meta name="twitter:description" content={finalDescription} />
      <meta name="twitter:image" content={socialImage} />
      <meta name="twitter:image:alt" content={`${title || 'Change Up Cuts'} - Premier Multicultural Barbershop & Beauty Center`} />
      <meta name="twitter:site" content="@changeupcuts" />
      <meta name="twitter:creator" content="@changeupcuts" />
      <meta name="twitter:domain" content="changeupcuts.com" />

      {/* Enhanced Twitter data */}
      <meta name="twitter:label1" content="Location" />
      <meta name="twitter:data1" content="North Charleston, SC" />
      <meta name="twitter:label2" content="Phone" />
      <meta name="twitter:data2" content="(843) 789-4430" />

      {/* LinkedIn Specific */}
      <meta property="og:image:width" content="1200" />
      <meta property="og:image:height" content="627" />
      
      {/* WhatsApp Sharing */}
      <meta property="og:image:width" content="300" />
      <meta property="og:image:height" content="300" />
      
      {/* Pinterest Rich Pins */}
      <meta name="pinterest-rich-pin" content="true" />
      <meta property="og:see_also" content="https://www.facebook.com/changeupcuts" />
      <meta property="og:see_also" content="https://www.instagram.com/changeupcuts" />

      {/* Additional SEO Meta Tags */}
      <meta name="theme-color" content="#1A3C1F" />
      <meta name="msapplication-TileColor" content="#1A3C1F" />
      <meta name="msapplication-TileImage" content={socialImage} />
      
      {/* Mobile App Meta Tags */}
      <meta name="apple-mobile-web-app-title" content="Change Up Cuts" />
      <meta name="application-name" content="Change Up Cuts" />
      
      {/* Geo Meta Tags */}
      <meta name="geo.region" content="US-SC" />
      <meta name="geo.placename" content="North Charleston" />
      <meta name="geo.position" content="32.8546;-79.9748" />
      <meta name="ICBM" content="32.8546, -79.9748" />

      {/* Google+ / Schema.org */}
      <meta itemProp="name" content={finalTitle} />
      <meta itemProp="description" content={finalDescription} />
      <meta itemProp="image" content={socialImage} />

      {/* RSS Feed */}
      <link rel="alternate" type="application/rss+xml" title="Change Up Cuts Blog" href="/feed.xml" />

      {/* Enhanced DNS Prefetch and Preconnect */}
      <link rel="dns-prefetch" href="//i.postimg.cc" />
      <link rel="dns-prefetch" href="//fonts.googleapis.com" />
      <link rel="dns-prefetch" href="//fonts.gstatic.com" />
      <link rel="dns-prefetch" href="//getsquire.com" />
      <link rel="dns-prefetch" href="//www.facebook.com" />
      <link rel="dns-prefetch" href="//www.instagram.com" />
      <link rel="dns-prefetch" href="//twitter.com" />
      
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
      <link rel="preconnect" href="https://i.postimg.cc" />

      {/* ENHANCED but SEO-SAFE Main Business Schema.org JSON-LD */}
      <script type="application/ld+json">
        {JSON.stringify(getStructuredData())}
      </script>

      {/* ADDITIVE Service-Specific Schema (SEO enhancement) */}
      {getServiceSpecificData() && (
        <script type="application/ld+json">
          {JSON.stringify(getServiceSpecificData())}
        </script>
      )}

      {/* ADDITIVE FAQ Schema for rich snippets */}
      <script type="application/ld+json">
        {JSON.stringify(getFAQSchema())}
      </script>

      {/* PRESERVED Additional Local Business Schema */}
      <script type="application/ld+json">
        {JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Organization",
          "name": "Change Up Cuts",
          "url": "https://www.changeupcuts.com",
          "logo": "https://i.postimg.cc/xCFnNRvc/Changup-Lo-GO.webp",
          "contactPoint": [
            {
              "@type": "ContactPoint",
              "telephone": "+1-843-789-4430",
              "contactType": "customer service",
              "areaServed": "US-SC",
              "availableLanguage": ["English", "Spanish"],
              "hoursAvailable": [
                {
                  "@type": "OpeningHoursSpecification",
                  "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday"],
                  "opens": "10:00",
                  "closes": "19:30"
                },
                {
                  "@type": "OpeningHoursSpecification",
                  "dayOfWeek": ["Friday", "Saturday"],
                  "opens": "09:00",
                  "closes": "20:00"
                },
                {
                  "@type": "OpeningHoursSpecification",
                  "dayOfWeek": "Sunday",
                  "opens": "09:00",
                  "closes": "16:00"
                }
              ]
            },
            {
              "@type": "ContactPoint",
              "telephone": "+1-843-789-4360",
              "contactType": "customer service",
              "areaServed": "US-SC",
              "availableLanguage": ["English", "Spanish"],
              "serviceType": "Beauty Center",
              "hoursAvailable": [
                {
                  "@type": "OpeningHoursSpecification",
                  "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday"],
                  "opens": "10:00",
                  "closes": "17:00"
                },
                {
                  "@type": "OpeningHoursSpecification",
                  "dayOfWeek": ["Friday", "Saturday"],
                  "opens": "09:00",
                  "closes": "18:00"
                }
              ]
            }
          ],
          "sameAs": [
            "https://www.facebook.com/changeupcuts",
            "https://www.instagram.com/changeupcuts",
            "https://twitter.com/changeupcuts",
            "https://www.facebook.com/changeupcutsbeautycenter",
            "https://www.instagram.com/Changeupcutsbeautycenter/"
          ]
        })}
      </script>

      {/* ADDITIVE Professional Service Provider Schema for enhanced local SEO */}
      <script type="application/ld+json">
        {JSON.stringify({
          "@context": "https://schema.org",
          "@type": "ProfessionalService",
          "name": "Change Up Cuts Professional Services",
          "description": "Professional barbering and beauty services for the greater Charleston area",
          "provider": {
            "@type": "HairSalon",
            "name": "Change Up Cuts"
          },
          "areaServed": [
            {
              "@type": "City",
              "name": "North Charleston",
              "containedInPlace": {
                "@type": "State",
                "name": "South Carolina"
              }
            },
            {
              "@type": "City",
              "name": "Charleston",
              "containedInPlace": {
                "@type": "State",
                "name": "South Carolina"
              }
            },
            {
              "@type": "City",
              "name": "Mount Pleasant",
              "containedInPlace": {
                "@type": "State",
                "name": "South Carolina"
              }
            },
            {
              "@type": "City",
              "name": "Summerville",
              "containedInPlace": {
                "@type": "State",
                "name": "South Carolina"
              }
            }
          ],
          "serviceType": [
            "Hair Cutting",
            "Hair Styling", 
            "Beard Grooming",
            "Hair Coloring",
            "Beauty Services"
          ]
        })}
      </script>
    </Helmet>
  );
};