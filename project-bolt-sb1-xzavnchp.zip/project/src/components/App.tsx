import React, { lazy, Suspense, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { AsSeenOn } from './components/AsSeenOn';
import { StoreInfo } from './components/StoreInfo';
import { CTASection } from './components/CTASection';
import { Footer } from './components/Footer';
import { MetaTags } from './components/MetaTags';
import { LoadingScreen, LoadingSpinner } from './components/LoadingScreen';
import { AppLoader } from './components/AppLoader';
import { SocialProof } from './components/SocialProof';
import { FloatingShareButton } from './components/SocialSharing';
import { PerformanceMonitor } from './utils/performance';

// Lazy load page components
const AboutPage = lazy(() => import('./components/AboutPage').then(m => ({ default: m.AboutPage })));
const ServicesPage = lazy(() => import('./components/ServicesPage').then(m => ({ default: m.ServicesPage })));
const BeautyCenterPage = lazy(() => import('./components/BeautyCenterPage').then(m => ({ default: m.BeautyCenterPage })));
const ContactPage = lazy(() => import('./components/ContactPage').then(m => ({ default: m.ContactPage })));
const StyleGalleryPage = lazy(() => import('./components/StyleGalleryPage').then(m => ({ default: m.StyleGalleryPage })));
const PrivacyPolicy = lazy(() => import('./components/PrivacyPolicy').then(m => ({ default: m.PrivacyPolicy })));
const TermsOfService = lazy(() => import('./components/TermsOfService').then(m => ({ default: m.TermsOfService })));
const HtmlSitemap = lazy(() => import('./components/HtmlSitemap').then(m => ({ default: m.HtmlSitemap })));
const NotFoundPage = lazy(() => import('./components/NotFoundPage').then(m => ({ default: m.NotFoundPage })));

function App() {
  const [currentPage, setCurrentPage] = React.useState('home');

  // Initialize performance monitoring
  useEffect(() => {
    const monitor = PerformanceMonitor.getInstance();
    monitor.measureCoreWebVitals();
    monitor.monitorResourceLoading();
    monitor.markStart('app-initialization');
    
    // Mark when app is fully loaded
    const handleLoad = () => {
      monitor.markEnd('app-initialization');
    };
    
    if (document.readyState === 'complete') {
      handleLoad();
    } else {
      window.addEventListener('load', handleLoad);
      return () => window.removeEventListener('load', handleLoad);
    }
  }, []);

  React.useEffect(() => {
    const handleHashChange = () => {
      const monitor = PerformanceMonitor.getInstance();
      monitor.markStart('page-navigation');
      
      const hash = window.location.hash.toLowerCase();
      switch (hash) {
        case '#about':
          setCurrentPage('about');
          break;
        case '#services':
          setCurrentPage('services');
          break;
        case '#careers':
          setCurrentPage('beauty');
          break;
        case '#contact':
          setCurrentPage('contact');
          break;
        case '#gallery':
          setCurrentPage('gallery');
          break;
        case '#privacy':
          setCurrentPage('privacy');
          break;
        case '#terms':
          setCurrentPage('terms');
          break;
        case '#sitemap':
          setCurrentPage('sitemap');
          break;
        case '#404':
          setCurrentPage('404');
          break;
        case '':
        case '#':
        case '#home':
          setCurrentPage('home');
          break;
        default:
          // For any unknown hash, show 404
          setCurrentPage('404');
      }
      
      // Scroll to top when page changes
      window.scrollTo(0, 0);
      
      // Announce page change to screen readers
      const announcement = document.getElementById('page-announcement');
      if (announcement) {
        const pageName = currentPage === 'home' ? 'home page' : currentPage === '404' ? 'page not found' : currentPage + ' page';
        announcement.textContent = `Navigated to ${pageName}`;
      }
      
      monitor.markEnd('page-navigation');
    };

    window.addEventListener('hashchange', handleHashChange);
    handleHashChange(); // Check initial hash

    return () => window.removeEventListener('hashchange', handleHashChange);
  }, [currentPage]);

  const renderPage = () => {
    // Enhanced loading fallback with branded experience
    const LoadingFallback = () => (
      <div className="min-h-screen bg-white flex items-center justify-center relative overflow-hidden">
        <div className="relative z-10 flex flex-col items-center text-center max-w-md mx-auto px-6">
          {/* Animated Logo */}
          <div className="mb-8 relative">
            <div className="absolute inset-0 w-20 h-20 border-4 border-transparent border-t-[#1A3C1F] border-r-[#1A3C1F] rounded-full animate-spin opacity-60"></div>
            <div className="relative w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-lg border border-gray-100">
              <img 
                src="https://i.postimg.cc/xCFnNRvc/Changup-Lo-GO.webp" 
                alt="Change Up Cuts Logo" 
                className="w-12 h-12 object-contain animate-pulse"
                loading="eager"
              />
            </div>
            <div className="absolute inset-0 w-20 h-20 bg-[#1A3C1F] rounded-full opacity-10 animate-ping"></div>
          </div>

          {/* Loading Text */}
          <div className="mb-6">
            <h2 className="text-2xl font-display font-bold text-[#1A3C1F] mb-2">
              Loading...
            </h2>
            <p className="text-gray-500 text-sm">
              Preparing your barbershop experience
            </p>
          </div>

          {/* Loading Animation */}
          <div className="flex space-x-1">
            {[0, 1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className="w-2 bg-[#1A3C1F] rounded-full animate-pulse"
                style={{
                  height: '16px',
                  animationDelay: `${i * 0.2}s`,
                  animationDuration: '1s'
                }}
              />
            ))}
          </div>
        </div>
      </div>
    );

    switch (currentPage) {
      case 'about':
        return (
          <Suspense fallback={<LoadingFallback />}>
            <AboutPage />
          </Suspense>
        );
      case 'services':
        return (
          <Suspense fallback={<LoadingFallback />}>
            <ServicesPage />
          </Suspense>
        );
      case 'beauty':
        return (
          <Suspense fallback={<LoadingFallback />}>
            <BeautyCenterPage />
          </Suspense>
        );
      case 'contact':
        return (
          <Suspense fallback={<LoadingFallback />}>
            <ContactPage />
          </Suspense>
        );
      case 'gallery':
        return (
          <Suspense fallback={<LoadingFallback />}>
            <StyleGalleryPage />
          </Suspense>
        );
      case 'privacy':
        return (
          <Suspense fallback={<LoadingFallback />}>
            <PrivacyPolicy />
          </Suspense>
        );
      case 'terms':
        return (
          <Suspense fallback={<LoadingFallback />}>
            <TermsOfService />
          </Suspense>
        );
      case 'sitemap':
        return (
          <Suspense fallback={<LoadingFallback />}>
            <HtmlSitemap />
          </Suspense>
        );
      case '404':
        return (
          <Suspense fallback={<LoadingFallback />}>
            <NotFoundPage />
          </Suspense>
        );
      default:
        return (
          <>
            <MetaTags
              title="Premier Multicultural Barbershop & Beauty Center"
              description="Experience top-tier barber, salon, and nail services at Change Up Cuts in North Charleston, SC. Our multicultural team offers expert cuts, styling, and grooming for all hair types. Walk-ins welcome!"
              type="business.business"
            />
            <Hero />
            <AsSeenOn />
            <About />
            <SocialProof />
            <StoreInfo />
            <CTASection />
          </>
        );
    }
  };

  // Get page-specific social sharing props
  const getSharingProps = () => {
    const baseUrl = "https://www.changeupcuts.com";
    const baseTitle = "Change Up Cuts - Premier Multicultural Barbershop & Beauty Center";
    
    switch (currentPage) {
      case 'about':
        return {
          url: `${baseUrl}/about`,
          title: "About Change Up Cuts - Our Story",
          description: "Learn about Change Up Cuts, Charleston's premier multicultural barbershop and beauty center. Founded in 2021, delivering exceptional service and community focus.",
          hashtags: ["AboutUs", "ChangeUpCuts", "Charleston", "Barbershop"]
        };
      case 'services':
        return {
          url: `${baseUrl}/services`,
          title: "Professional Barbershop Services - Change Up Cuts",
          description: "Expert haircuts, fades, beard grooming, and styling services. Professional barbers skilled in all hair types and cultural styles.",
          hashtags: ["BarbershopServices", "Haircuts", "Fades", "BeardGrooming"]
        };
      case 'beauty':
        return {
          url: `${baseUrl}/beauty-center`,
          title: "Beauty Center Services - Change Up Cuts",
          description: "Luxury beauty treatments, hair styling, coloring, and professional makeup services at our beauty center in North Charleston.",
          hashtags: ["BeautyCenter", "HairStyling", "BeautyTreatments", "Salon"]
        };
      case 'gallery':
        return {
          url: `${baseUrl}/gallery`,
          title: "Style Gallery - Change Up Cuts",
          description: "Browse our gallery of haircuts, styles, and grooming transformations. See the quality craftsmanship of our expert team.",
          hashtags: ["StyleGallery", "Haircuts", "BeforeAfter", "Barbering"]
        };
      case 'contact':
        return {
          url: `${baseUrl}/contact`,
          title: "Contact Change Up Cuts - Book Your Appointment",
          description: "Get in touch with Change Up Cuts in North Charleston. Book appointments, find our location, and connect with our professional team.",
          hashtags: ["Contact", "BookAppointment", "NorthCharleston", "Barbershop"]
        };
      default:
        return {
          url: baseUrl,
          title: baseTitle,
          description: "Experience exceptional barbershop and beauty services at Change Up Cuts in North Charleston, SC. Professional haircuts, fades, beard grooming, and beauty treatments.",
          hashtags: ["ChangeUpCuts", "NorthCharleston", "Barbershop", "BeautyCenter"]
        };
    }
  };

  return (
    <AppLoader>
      <div className="font-primary text-gray-900 bg-white" lang="en">
        {/* Skip Navigation Link for Screen Readers */}
        <a 
          href="#main-content" 
          className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 bg-[#1A3C1F] text-white px-4 py-2 rounded z-50"
          aria-label="Skip to main content"
        >
          Skip to main content
        </a>
        
        {/* Screen reader announcements */}
        <div 
          id="page-announcement" 
          className="sr-only" 
          aria-live="polite" 
          aria-atomic="true"
        ></div>
        
        <Navbar />
        <main id="main-content" role="main">
          {renderPage()}
        </main>
        <Footer />
        
        {/* Floating Social Share Button - Only on main pages */}
        {['home', 'about', 'services', 'beauty', 'gallery', 'contact'].includes(currentPage) && (
          <FloatingShareButton {...getSharingProps()} />
        )}
      </div>
    </AppLoader>
  );
}

export default App;