import React, { useState, useEffect } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { MetaTags } from './MetaTags';

export const TermsOfService = () => {
  const [activeSection, setActiveSection] = useState<string | null>(null);
  const [activeNav, setActiveNav] = useState('agreement');

  const sections = [
    {
      id: 'agreement',
      title: '1. Agreement to Terms',
      content: `By accessing or using Change Up Cuts Barbershop and Beauty Center's services, you agree to be bound by these Terms of Service. If you disagree with any part of these terms, you may not access our services.`
    },
    {
      id: 'services',
      title: '2. Services',
      content: `We provide barbershop and beauty services, including but not limited to:`,
      list: [
        'Haircuts and styling',
        'Beard grooming',
        'Hair coloring',
        'Beauty treatments',
        'Related grooming services'
      ]
    },
    {
      id: 'appointments',
      title: '3. Appointments and Cancellations',
      content: `We operate on an appointment basis. Walk-ins are welcome but subject to availability.`,
      list: [
        'Please arrive 5 minutes before your scheduled appointment',
        '24-hour notice is required for cancellations',
        'No-shows may be subject to a cancellation fee',
        'Late arrivals may result in reduced service time'
      ]
    },
    {
      id: 'payment',
      title: '4. Payment Terms',
      content: `We accept various payment methods including cash, credit cards, and digital payments.`,
      list: [
        'Payment is required at the time of service',
        'Prices are subject to change without notice',
        'Special services may require deposits',
        'Gift cards are non-refundable'
      ]
    },
    {
      id: 'health',
      title: '5. Health and Safety',
      content: `We maintain high standards of cleanliness and safety. Clients must:`,
      list: [
        'Disclose any relevant health conditions',
        'Follow safety protocols and guidelines',
        'Respect sanitation procedures',
        'Comply with posted safety notices'
      ]
    },
    {
      id: 'liability',
      title: '6. Liability',
      content: `While we strive for excellence, we are not liable for:`,
      list: [
        'Unsatisfactory results due to client requests',
        'Reactions to products or services',
        'Personal items left in the facility',
        'Circumstances beyond our reasonable control'
      ]
    },
    {
      id: 'contact',
      title: '7. Contact Information',
      content: `For questions about these Terms of Service, please contact us at:`
    }
  ];

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY + 100;
      
      for (const section of sections) {
        const element = document.getElementById(section.id);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveNav(section.id);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const offset = 100;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <div className="bg-white min-h-screen pt-32 pb-16">
      <MetaTags
        title="Terms of Service"
        description="Review the terms of service for Change Up Cuts Barbershop and Beauty Center. Understand our policies regarding appointments, payments, and service usage."
        keywords="terms of service, service agreement, Change Up Cuts policies, appointment terms, barbershop terms"
        type="article"
        canonicalPath="/terms"
        author="Change Up Cuts Legal Team"
        publishedTime="2021-07-01T00:00:00Z"
        modifiedTime={new Date().toISOString()}
      />
      
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Sidebar Navigation */}
            <div className="lg:w-1/4">
              <div className="sticky top-32 bg-white p-6 rounded-lg shadow-md">
                <h2 className="text-xl font-bold mb-4">Table of Contents</h2>
                <nav className="space-y-2">
                  {sections.map((section) => (
                    <button
                      key={section.id}
                      onClick={() => scrollToSection(section.id)}
                      className={`block w-full text-left px-4 py-2 rounded-lg transition-colors ${
                        activeNav === section.id
                          ? 'bg-[#1A3C1F] text-white'
                          : 'hover:bg-gray-100'
                      }`}
                    >
                      {section.title}
                    </button>
                  ))}
                </nav>
              </div>
            </div>

            {/* Main Content */}
            <div className="lg:w-3/4">
              <h1 className="text-4xl font-bold mb-8">Terms of Service</h1>
              <p className="text-lg text-gray-600 mb-8">
                Last updated: {new Date().toLocaleDateString()}
              </p>

              {sections.map((section) => (
                <section
                  key={section.id}
                  id={section.id}
                  className="mb-8 bg-white rounded-lg shadow-md overflow-hidden"
                >
                  <button
                    className={`w-full p-6 text-left bg-gray-50 flex justify-between items-center ${
                      activeSection === section.id ? 'border-b' : ''
                    }`}
                    onClick={() => setActiveSection(activeSection === section.id ? null : section.id)}
                  >
                    <h2 className="text-2xl font-bold">{section.title}</h2>
                    {activeSection === section.id ? (
                      <ChevronUp className="w-6 h-6 text-gray-500" />
                    ) : (
                      <ChevronDown className="w-6 h-6 text-gray-500" />
                    )}
                  </button>

                  <div
                    className={`transition-all duration-300 ease-in-out ${
                      activeSection === section.id ? 'max-h-[1000px] opacity-100' : 'max-h-0 opacity-0'
                    } overflow-hidden`}
                  >
                    <div className="p-6">
                      <p className="mb-4">{section.content}</p>
                      {section.list && (
                        <ul className="list-disc pl-6 space-y-2">
                          {section.list.map((item, index) => (
                            <li key={index} className="text-gray-700">{item}</li>
                          ))}
                        </ul>
                      )}
                      {section.id === 'contact' && (
                        <div className="bg-gray-50 p-6 rounded-lg mt-4">
                          <p>Change Up Cuts Barbershop and Beauty Center</p>
                          <a 
                            href="https://www.google.com/maps/place/Change+Up+Cuts+Barbershop+%26+Beauty+Center/@32.9044054,-80.0203215,17.05z/data=!4m6!3m5!1s0x88fe636c08e7b0a3:0x80d92ec6413760e4!8m2!3d32.904006!4d-80.0181136!16s%2Fg%2F11q8vcl_gr?entry=ttu&g_ep=EgoyMDI1MDYwNC4wIKXMDSoASAFQAw%3D%3D"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-[#1A3C1F] hover:text-[#152f18] transition-colors"
                            aria-label="View our location on Google Maps"
                          >
                            <p>5900 Rivers Avenue, Suite D-4</p>
                            <p>North Charleston, SC 29406</p>
                          </a>
                          <p>Email: <a href="mailto:info@changeupcuts.com" className="text-[#1A3C1F] hover:text-[#152f18]">info@changeupcuts.com</a></p>
                          <p>Phone: <a href="tel:+18437894430" className="text-[#1A3C1F] hover:text-[#152f18]">(843) 789-4430</a></p>
                        </div>
                      )}
                    </div>
                  </div>
                </section>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};