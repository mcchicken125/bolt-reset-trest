import React from 'react';
import { AlertCircle, CheckCircle, Info, X } from 'lucide-react';

export interface FormError {
  field?: string;
  message: string;
  type?: 'error' | 'warning' | 'info' | 'success';
}

interface FormErrorHandlerProps {
  errors: FormError[];
  onClearError?: (index: number) => void;
  className?: string;
}

export const FormErrorHandler: React.FC<FormErrorHandlerProps> = ({
  errors,
  onClearError,
  className = ''
}) => {
  if (errors.length === 0) return null;

  const getIcon = (type: FormError['type'] = 'error') => {
    switch (type) {
      case 'success':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'warning':
        return <AlertCircle className="w-4 h-4 text-yellow-600" />;
      case 'info':
        return <Info className="w-4 h-4 text-blue-600" />;
      default:
        return <AlertCircle className="w-4 h-4 text-red-600" />;
    }
  };

  const getClasses = (type: FormError['type'] = 'error') => {
    switch (type) {
      case 'success':
        return 'bg-green-50 border-green-200 text-green-800';
      case 'warning':
        return 'bg-yellow-50 border-yellow-200 text-yellow-800';
      case 'info':
        return 'bg-blue-50 border-blue-200 text-blue-800';
      default:
        return 'bg-red-50 border-red-200 text-red-800';
    }
  };

  return (
    <div className={`space-y-2 ${className}`}>
      {errors.map((error, index) => (
        <div
          key={index}
          className={`p-3 rounded-lg border flex items-start gap-3 ${getClasses(error.type)}`}
          role="alert"
          aria-live="polite"
        >
          {getIcon(error.type)}
          <div className="flex-1 min-w-0">
            {error.field && (
              <span className="font-medium text-sm">
                {error.field}:{' '}
              </span>
            )}
            <span className="text-sm">{error.message}</span>
          </div>
          {onClearError && (
            <button
              onClick={() => onClearError(index)}
              className="flex-shrink-0 p-1 hover:bg-black/5 rounded transition-colors"
              aria-label={`Clear ${error.type || 'error'} message`}
            >
              <X className="w-3 h-3" />
            </button>
          )}
        </div>
      ))}
    </div>
  );
};

// Field-specific error component
interface FieldErrorProps {
  error?: string;
  touched?: boolean;
  className?: string;
}

export const FieldError: React.FC<FieldErrorProps> = ({
  error,
  touched,
  className = ''
}) => {
  if (!error || !touched) return null;

  return (
    <div className={`flex items-center gap-2 mt-1 text-red-600 text-sm ${className}`}>
      <AlertCircle className="w-4 h-4 flex-shrink-0" />
      <span>{error}</span>
    </div>
  );
};

// Success message component
interface SuccessMessageProps {
  message: string;
  onClose?: () => void;
  autoClose?: boolean;
  duration?: number;
}

export const SuccessMessage: React.FC<SuccessMessageProps> = ({
  message,
  onClose,
  autoClose = true,
  duration = 5000
}) => {
  React.useEffect(() => {
    if (autoClose && onClose) {
      const timer = setTimeout(onClose, duration);
      return () => clearTimeout(timer);
    }
  }, [autoClose, onClose, duration]);

  return (
    <div className="p-4 bg-green-50 border border-green-200 rounded-lg flex items-start gap-3">
      <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
      <div className="flex-1">
        <p className="text-green-800 font-medium">{message}</p>
      </div>
      {onClose && (
        <button
          onClick={onClose}
          className="flex-shrink-0 p-1 hover:bg-green-100 rounded transition-colors"
          aria-label="Close success message"
        >
          <X className="w-4 h-4 text-green-600" />
        </button>
      )}
    </div>
  );
};

// Loading state component
interface LoadingStateProps {
  message?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const LoadingState: React.FC<LoadingStateProps> = ({
  message = 'Loading...',
  size = 'md'
}) => {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-6 h-6',
    lg: 'w-8 h-8'
  };

  return (
    <div className="flex items-center justify-center gap-3 p-4">
      <div className={`${sizeClasses[size]} border-2 border-[#1A3C1F] border-t-transparent rounded-full animate-spin`} />
      <span className="text-gray-600">{message}</span>
    </div>
  );
};