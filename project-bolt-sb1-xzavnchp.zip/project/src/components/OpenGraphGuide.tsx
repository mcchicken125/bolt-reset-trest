import React from 'react';
import { Image, Smartphone, Monitor, Share2, CheckCircle } from 'lucide-react';

export const OpenGraphGuide = () => {
  const imageSpecs = [
    {
      platform: "Facebook",
      size: "1200 x 630px",
      ratio: "1.91:1",
      format: "JPG, PNG, WebP",
      maxSize: "8MB",
      description: "Most versatile format, works on LinkedIn and most platforms"
    },
    {
      platform: "Twitter",
      size: "1200 x 600px", 
      ratio: "2:1",
      format: "JPG, PNG, WebP",
      maxSize: "5MB",
      description: "Summary Large Image card format"
    },
    {
      platform: "WhatsApp",
      size: "300 x 300px",
      ratio: "1:1",
      format: "JPG, PNG",
      maxSize: "300KB",
      description: "Square format for mobile sharing"
    },
    {
      platform: "LinkedIn",
      size: "1200 x 627px",
      ratio: "1.91:1", 
      format: "JPG, PNG",
      maxSize: "5MB",
      description: "Professional sharing format"
    }
  ];

  const designTips = [
    {
      icon: CheckCircle,
      title: "Use High-Quality Images",
      description: "Choose sharp, professional photos that represent your barbershop's quality and atmosphere."
    },
    {
      icon: CheckCircle,
      title: "Add Your Logo",
      description: "Include your Change Up Cuts logo prominently for brand recognition."
    },
    {
      icon: CheckCircle,
      title: "Keep Text Readable",
      description: "Use large, bold fonts with high contrast. Text should be readable on mobile devices."
    },
    {
      icon: CheckCircle,
      title: "Include Key Information",
      description: "Add your location (North Charleston, SC) and contact info when relevant."
    },
    {
      icon: CheckCircle,
      title: "Stay On-Brand",
      description: "Use your brand colors (#1A3C1F green) and maintain consistent styling."
    }
  ];

  return (
    <div className="bg-white py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-4 text-[#1A3C1F]">Open Graph Images Guide</h1>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Your website is already optimized for social sharing! Here's how to create the perfect 
              Open Graph images for maximum engagement across all platforms.
            </p>
          </div>

          {/* Current Implementation Status */}
          <div className="bg-green-50 border border-green-200 rounded-lg p-6 mb-12">
            <div className="flex items-center gap-3 mb-4">
              <CheckCircle className="w-6 h-6 text-green-600" />
              <h2 className="text-xl font-bold text-green-800">Your Implementation is Ready!</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-green-700">
              <div>✅ Dynamic Open Graph tags implemented</div>
              <div>✅ Page-specific images configured</div>
              <div>✅ Twitter Cards optimized</div>
              <div>✅ LinkedIn sharing ready</div>
              <div>✅ WhatsApp sharing enabled</div>
              <div>✅ Proper image dimensions set</div>
            </div>
          </div>

          {/* Platform Specifications */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold mb-8 text-center">Platform Image Specifications</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {imageSpecs.map((spec, index) => (
                <div key={index} className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-lg transition-shadow">
                  <h3 className="text-xl font-bold mb-3 text-[#1A3C1F]">{spec.platform}</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="font-medium">Size:</span>
                      <span className="font-mono text-sm">{spec.size}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Ratio:</span>
                      <span className="font-mono text-sm">{spec.ratio}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Format:</span>
                      <span className="text-sm">{spec.format}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Max Size:</span>
                      <span className="text-sm">{spec.maxSize}</span>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 mt-3 italic">{spec.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Design Guidelines */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold mb-8 text-center">Design Best Practices</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {designTips.map((tip, index) => (
                <div key={index} className="bg-gray-50 p-6 rounded-lg">
                  <tip.icon className="w-8 h-8 text-green-600 mb-4" />
                  <h3 className="font-bold mb-2">{tip.title}</h3>
                  <p className="text-gray-600 text-sm">{tip.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Image Templates Suggestions */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold mb-8 text-center">Recommended Images for Each Page</h2>
            <div className="space-y-6">
              <div className="bg-white border border-gray-200 rounded-lg p-6">
                <h3 className="text-xl font-bold mb-4 text-[#1A3C1F]">Homepage</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="bg-gray-100 h-32 rounded-lg mb-2 flex items-center justify-center">
                      <Monitor className="w-8 h-8 text-gray-400" />
                    </div>
                    <p className="text-sm font-medium">Main barbershop interior</p>
                  </div>
                  <div className="text-center">
                    <div className="bg-gray-100 h-32 rounded-lg mb-2 flex items-center justify-center">
                      <Image className="w-8 h-8 text-gray-400" />
                    </div>
                    <p className="text-sm font-medium">Your logo prominently displayed</p>
                  </div>
                  <div className="text-center">
                    <div className="bg-gray-100 h-32 rounded-lg mb-2 flex items-center justify-center">
                      <Share2 className="w-8 h-8 text-gray-400" />
                    </div>
                    <p className="text-sm font-medium">Contact info & location</p>
                  </div>
                </div>
              </div>

              <div className="bg-white border border-gray-200 rounded-lg p-6">
                <h3 className="text-xl font-bold mb-4 text-[#1A3C1F]">Services Page</h3>
                <p className="text-gray-600 mb-4">
                  <strong>Current:</strong> Using "Third.webp" - shows professional haircut in progress
                </p>
                <p className="text-sm text-gray-500">
                  ✅ Perfect choice! Shows actual service being performed professionally
                </p>
              </div>

              <div className="bg-white border border-gray-200 rounded-lg p-6">
                <h3 className="text-xl font-bold mb-4 text-[#1A3C1F]">Gallery Page</h3>
                <p className="text-gray-600 mb-4">
                  <strong>Current:</strong> Using "Fourth.webp" - showcases finished styling work
                </p>
                <p className="text-sm text-gray-500">
                  ✅ Excellent! Demonstrates the quality of your finished work
                </p>
              </div>
            </div>
          </div>

          {/* Tools & Resources */}
          <div className="bg-[#1A3C1F] text-white rounded-lg p-8">
            <h2 className="text-3xl font-bold mb-6 text-center">Tools for Creating Open Graph Images</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="text-center">
                <h3 className="font-bold mb-2">Canva</h3>
                <p className="text-sm text-white/80">
                  Free templates specifically for social media. Search "Facebook Post" or "Open Graph"
                </p>
              </div>
              <div className="text-center">
                <h3 className="font-bold mb-2">Figma</h3>
                <p className="text-sm text-white/80">
                  Professional design tool with social media templates and precise sizing
                </p>
              </div>
              <div className="text-center">
                <h3 className="font-bold mb-2">Adobe Express</h3>
                <p className="text-sm text-white/80">
                  Quick social media graphics with brand kit integration
                </p>
              </div>
            </div>
          </div>

          {/* Testing Tools */}
          <div className="mt-12">
            <h2 className="text-3xl font-bold mb-8 text-center">Test Your Open Graph Images</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                <h3 className="font-bold text-blue-800 mb-3">Facebook Sharing Debugger</h3>
                <p className="text-blue-700 text-sm mb-4">
                  Test how your pages will appear when shared on Facebook and LinkedIn
                </p>
                <a 
                  href="https://developers.facebook.com/tools/debug/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors text-sm"
                >
                  Test on Facebook
                </a>
              </div>
              
              <div className="bg-sky-50 border border-sky-200 rounded-lg p-6">
                <h3 className="font-bold text-sky-800 mb-3">Twitter Card Validator</h3>
                <p className="text-sky-700 text-sm mb-4">
                  Preview how your pages will look when shared on Twitter/X
                </p>
                <a 
                  href="https://cards-dev.twitter.com/validator"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block px-4 py-2 bg-sky-600 text-white rounded hover:bg-sky-700 transition-colors text-sm"
                >
                  Test on Twitter
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};