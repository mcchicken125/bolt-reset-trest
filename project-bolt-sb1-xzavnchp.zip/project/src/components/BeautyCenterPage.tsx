import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Scissors, Sparkles, SprayCan, Palette } from 'lucide-react';
import { MetaTags } from './MetaTags';

export const BeautyCenterPage = () => {
  const [isMobile, setIsMobile] = useState(window.innerWidth < 1024);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 1024);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const darkGradient = isMobile
    ? 'linear-gradient(to left, rgba(26,26,26,1) 0%, rgba(26,26,26,0.56) 40%, rgba(26,26,26,0) 100%)'
    : 'linear-gradient(to left, rgba(26,26,26,1) 0%, rgba(26,26,26,0.8) 40%, rgba(26,26,26,0) 100%)';

  const lightGradientLeft = isMobile
    ? 'linear-gradient(to left, rgba(255,255,255,1) 0%, rgba(255,255,255,0.42) 40%, rgba(255,255,255,0) 100%)'
    : 'linear-gradient(to left, rgba(255,255,255,1) 0%, rgba(255,255,255,0.6) 40%, rgba(255,255,255,0) 100%)';

  const lightGradientRight = isMobile
    ? 'linear-gradient(to right, rgba(255,255,255,1) 0%, rgba(255,255,255,0.42) 40%, rgba(255,255,255,0) 100%)'
    : 'linear-gradient(to right, rgba(255,255,255,1) 0%, rgba(255,255,255,0.6) 40%, rgba(255,255,255,0) 100%)';

  const darkGradientRight = isMobile
    ? 'linear-gradient(to right, rgba(26,26,26,1) 0%, rgba(26,26,26,0.56) 40%, rgba(26,26,26,0) 100%)'
    : 'linear-gradient(to right, rgba(26,26,26,1) 0%, rgba(26,26,26,0.8) 40%, rgba(26,26,26,0) 100%)';

  return (
    <div className="bg-white">
      <MetaTags
        title="Beauty Center"
        description="Experience luxury beauty treatments and professional hair styling at our beauty center. Our expert stylists offer cutting-edge services for all hair types and textures."
        keywords="beauty salon, hair styling, hair coloring, beauty treatments, Charleston beauty center"
        type="article"
        image="https://i.postimg.cc/pd45BtBr/10.webp"
        twitterCard="summary_large_image"
        author="Change Up Cuts Team"
        publishedTime="2021-07-01T00:00:00Z"
        modifiedTime={new Date().toISOString()}
        canonicalPath="/beauty-center"
        serviceType="beauty"
      />
      {/* Hero Section */}
      <section 
        className="relative min-h-[80vh] flex items-center justify-center"
        style={{
          backgroundImage: 'url("https://i.postimg.cc/ncG7fgnS/11.webp")',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed'
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/70 to-black/80"></div>
        
        <div className="relative z-10 container mx-auto px-4 pt-20 text-center">
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-display font-bold text-white mb-6 leading-tight">
            Beauty Center
          </h1>
          <div className="w-24 h-1 bg-[#1A3C1F] mx-auto mb-8"></div>
          <p className="text-xl md:text-2xl text-white/90 max-w-3xl mx-auto mb-8 leading-relaxed">
            Experience luxury beauty treatments and professional hair styling services
          </p>
          <p className="text-white/70 text-lg mt-12 tracking-wide font-light">¡HABLAMOS ESPAÑOL!</p>
        </div>

        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black to-transparent"></div>
      </section>

      {/* Hair Styling Section - Text Left, Image Right */}
      <section className="min-h-[60vh] flex bg-white" id="hair-styling">
        <div className="flex flex-col lg:flex-row w-full">
          <div className="w-full lg:w-1/2 p-12 flex items-center">
            <div>
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold mb-6">
                Hair Styling
              </h2>
              <div className="w-24 h-1 bg-[#1A3C1F] mb-6"></div>
              <p className="text-gray-600 text-lg md:text-xl leading-relaxed mb-8">
                From elegant updos to trendy cuts, our expert stylists create stunning looks tailored to your personality and lifestyle. Using premium products and advanced techniques for beautiful, lasting results.
              </p>
              <div className="mb-6">
                <span className="text-2xl font-bold text-[#1A3C1F]">$40-$80</span>
                <span className="text-gray-500 ml-2">Varies by service</span>
              </div>
              <a 
                href="https://getsquire.com/booking/book/change-up-cuts-barbershop-and-beauty-center-north-charleston/barber/any/services"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block px-6 py-3 bg-[#1A3C1F] text-white font-medium hover:bg-[#152f18] transition-colors rounded"
              >
                Schedule Appointment
              </a>
            </div>
          </div>
          <div className="relative w-full lg:w-1/2 min-h-[450px] lg:min-h-full overflow-hidden">
            <div 
              className="absolute inset-0 z-10"
              style={{
                background: lightGradientRight
              }}
            ></div>
            <div 
              className="absolute inset-0"
              style={{
                backgroundImage: `url('https://i.postimg.cc/pd45BtBr/10.webp')`,
                backgroundPosition: 'center',
                backgroundSize: 'cover',
                backgroundRepeat: 'no-repeat',
                filter: 'grayscale(100%)'
              }}
            ></div>
          </div>
        </div>
      </section>

      {/* Hair Highlights Section - Image Left, Text Right */}
      <section className="min-h-[60vh] flex bg-[#1A1A1A]" id="hair-coloring">
        <div className="flex flex-col lg:flex-row w-full">
          <div className="relative w-full lg:w-1/2 min-h-[450px] lg:min-h-full overflow-hidden">
            <div 
              className="absolute inset-0 z-10"
              style={{
                background: darkGradient
              }}
            ></div>
            <div 
              className="absolute inset-0"
              style={{
                backgroundImage: `url('https://i.postimg.cc/nhpGFqXF/Highlights.webp')`,
                backgroundPosition: 'center',
                backgroundSize: 'cover',
                backgroundRepeat: 'no-repeat',
                filter: 'grayscale(100%)'
              }}
            ></div>
          </div>
          <div className="w-full lg:w-1/2 p-12 flex items-center">
            <div>
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold mb-6 text-white">Hair Highlights</h2>
              <div className="w-24 h-1 bg-[#1A3C1F] mb-6"></div>
              <p className="text-gray-300 text-lg md:text-xl leading-relaxed mb-8">
                Transform your look with our professional hair coloring services. From natural highlights to bold fashion colors, we help you achieve the perfect shade while maintaining hair health.
              </p>
              <div className="mb-6">
                <span className="text-2xl font-bold text-[#D2B48C]">$45-$120</span>
                <span className="text-gray-400 ml-2">Includes color consultation</span>
              </div>
              <a 
                href="https://getsquire.com/booking/book/change-up-cuts-barbershop-and-beauty-center-north-charleston/barber/any/services"
                target="_blank"
                rel="noopener noreferrer"
                className="btn bg-[#D2B48C] text-black hover:bg-[#C19A6B] inline-block px-6 py-3 rounded"
              >
                Schedule Appointment
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Makeup Services Section - Text Left, Image Right */}
      <section className="min-h-[60vh] flex bg-white" id="makeup-services">
        <div className="flex flex-col lg:flex-row w-full">
          <div className="w-full lg:w-1/2 p-12 flex items-center">
            <div>
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold mb-6">
                Makeup Services
              </h2>
              <div className="w-24 h-1 bg-[#1A3C1F] mb-6"></div>
              <p className="text-gray-600 text-lg md:text-xl leading-relaxed mb-8">
                Professional makeup application for any occasion. From natural day looks to glamorous evening styles, our artists enhance your natural beauty with skill and precision.
              </p>
              <div className="mb-6">
                <span className="text-2xl font-bold text-[#1A3C1F]">$35-$75</span>
                <span className="text-gray-500 ml-2">Special events available</span>
              </div>
              <a 
                href="https://getsquire.com/booking/book/change-up-cuts-barbershop-and-beauty-center-north-charleston/barber/any/services"
                target="_blank"
                rel="noopener noreferrer"
                className="btn bg-[#1A3C1F] text-white hover:bg-[#152f18] inline-block px-6 py-3 rounded"
              >
                Schedule Appointment
              </a>
            </div>
          </div>
          <div className="relative w-full lg:w-1/2 min-h-[450px] lg:min-h-full overflow-hidden">
            <div 
              className="absolute inset-0 z-10"
              style={{
                background: lightGradientRight
              }}
            ></div>
            <div 
              className="absolute inset-0"
              style={{
                backgroundImage: `url('https://images.pexels.com/photos/457701/pexels-photo-457701.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')`,
                backgroundPosition: 'center',
                backgroundSize: 'cover',
                backgroundRepeat: 'no-repeat',
                filter: 'grayscale(100%)'
              }}
            ></div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-[#1A3C1F] py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-5xl text-white font-bold mb-8">Transform Your Look Today</h2>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Book your appointment with our expert beauty professionals and experience the difference.
          </p>
          <a 
            href="https://getsquire.com/booking/book/change-up-cuts-barbershop-and-beauty-center-north-charleston/barber/any/services"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block px-8 py-4 bg-[#D2B48C] text-black text-lg font-medium hover:bg-[#C19A6B] transition-all rounded-md shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
          >
            Schedule Appointment
          </a>
        </div>
      </section>
    </div>
  );
};