import React, { useState } from 'react';
import { Share2, Facebook, Twitter, MessageCircle, Linkedin, Copy, Check } from 'lucide-react';

interface SocialSharingProps {
  url?: string;
  title?: string;
  description?: string;
  hashtags?: string[];
  className?: string;
}

export const SocialSharing: React.FC<SocialSharingProps> = ({
  url = window.location.href,
  title = "Change Up Cuts - Premier Multicultural Barbershop & Beauty Center",
  description = "Experience exceptional barbershop and beauty services in North Charleston, SC. Professional haircuts, fades, beard grooming, and beauty treatments.",
  hashtags = ["ChangeUpCuts", "NorthCharleston", "Barbershop", "BeautyCenter"],
  className = ""
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  const encodedUrl = encodeURIComponent(url);
  const encodedTitle = encodeURIComponent(title);
  const encodedDescription = encodeURIComponent(description);
  const hashtagString = hashtags.map(tag => `#${tag}`).join(',');

  const shareLinks = {
    facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`,
    twitter: `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedTitle}&hashtags=${hashtags.join(',')}&via=changeupcuts`,
    linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`,
    whatsapp: `https://wa.me/?text=${encodedTitle}%20${encodedUrl}`,
    email: `mailto:?subject=${encodedTitle}&body=${encodedDescription}%0A%0A${url}`
  };

  const handleShare = (platform: string) => {
    const link = shareLinks[platform as keyof typeof shareLinks];
    if (link) {
      window.open(link, '_blank', 'width=600,height=400,scrollbars=yes,resizable=yes');
    }
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = url;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const shareOptions = [
    {
      name: 'Facebook',
      icon: Facebook,
      color: 'bg-blue-600 hover:bg-blue-700',
      action: () => handleShare('facebook')
    },
    {
      name: 'Twitter',
      icon: Twitter,
      color: 'bg-sky-500 hover:bg-sky-600',
      action: () => handleShare('twitter')
    },
    {
      name: 'LinkedIn',
      icon: Linkedin,
      color: 'bg-blue-700 hover:bg-blue-800',
      action: () => handleShare('linkedin')
    },
    {
      name: 'WhatsApp',
      icon: MessageCircle,
      color: 'bg-green-600 hover:bg-green-700',
      action: () => handleShare('whatsapp')
    },
    {
      name: 'Copy Link',
      icon: copied ? Check : Copy,
      color: copied ? 'bg-green-600' : 'bg-gray-600 hover:bg-gray-700',
      action: copyToClipboard
    }
  ];

  return (
    <div className={`relative ${className}`}>
      {/* Share Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="inline-flex items-center gap-2 px-4 py-2 bg-[#1A3C1F] text-white rounded-lg hover:bg-[#152f18] transition-all duration-300 shadow-md hover:shadow-lg"
        aria-label="Share this page"
      >
        <Share2 className="w-4 h-4" />
        Share
      </button>

      {/* Share Options - Dropdown */}
      {isOpen && (
        <>
          {/* Backdrop */}
          <div 
            className="fixed inset-0 z-40"
            onClick={() => setIsOpen(false)}
          />
          
          {/* Share Menu */}
          <div className="absolute top-full mt-2 right-0 bg-white rounded-xl shadow-xl border border-gray-200 p-4 z-50 min-w-[280px]">
            <h3 className="text-lg font-bold mb-3 text-gray-900">Share Change Up Cuts</h3>
            
            <div className="grid grid-cols-2 gap-3">
              {shareOptions.map((option) => (
                <button
                  key={option.name}
                  onClick={option.action}
                  className={`${option.color} text-white p-3 rounded-lg transition-all duration-300 flex items-center gap-3 text-sm font-medium hover:scale-105 active:scale-95`}
                >
                  <option.icon className="w-4 h-4" />
                  {option.name}
                </button>
              ))}
            </div>

            {/* Share URL Display */}
            <div className="mt-4 p-3 bg-gray-50 rounded-lg">
              <p className="text-xs text-gray-600 mb-1">Share URL:</p>
              <p className="text-sm text-gray-800 break-all font-mono">{url}</p>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

// Floating Share Button Component
export const FloatingShareButton: React.FC<SocialSharingProps> = (props) => {
  return (
    <div className="fixed bottom-6 right-6 z-40">
      <SocialSharing {...props} />
    </div>
  );
};

// Social Share for specific content
export const ContentShare: React.FC<SocialSharingProps & { showLabel?: boolean }> = ({ 
  showLabel = true, 
  ...props 
}) => {
  return (
    <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg border border-gray-200">
      {showLabel && (
        <span className="text-gray-700 font-medium">Share this:</span>
      )}
      <SocialSharing {...props} />
    </div>
  );
};