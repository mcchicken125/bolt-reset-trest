import React, { useState, useEffect } from 'react';

interface LoadingScreenProps {
  message?: string;
  showProgress?: boolean;
  fullScreen?: boolean;
}

export const LoadingScreen: React.FC<LoadingScreenProps> = ({ 
  message = "Loading...", 
  showProgress = false,
  fullScreen = true 
}) => {
  const [progress, setProgress] = useState(0);
  const [loadingText, setLoadingText] = useState(message);

  useEffect(() => {
    if (!showProgress) return;

    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + Math.random() * 15;
      });
    }, 100);

    return () => clearInterval(interval);
  }, [showProgress]);

  useEffect(() => {
    const messages = [
      "Preparing your experience...",
      "Setting up the barbershop...",
      "Almost ready..."
    ];
    
    let messageIndex = 0;
    const messageInterval = setInterval(() => {
      messageIndex = (messageIndex + 1) % messages.length;
      setLoadingText(messages[messageIndex]);
    }, 2000);

    return () => clearInterval(messageInterval);
  }, []);

  const containerClasses = fullScreen 
    ? "fixed inset-0 z-50 bg-white" 
    : "min-h-screen bg-white";

  return (
    <div 
      className={`${containerClasses} flex items-center justify-center`}
      role="status" 
      aria-label="Loading page content"
    >
      <div className="relative z-10 flex flex-col items-center max-w-md mx-auto px-6 text-center">
        {/* Logo Container */}
        <div className="mb-8 relative">
          <div className="absolute inset-0 w-24 h-24 border-4 border-transparent border-t-[#1A3C1F] border-r-[#1A3C1F] rounded-full animate-spin opacity-60" aria-hidden="true"></div>
          <div className="absolute inset-2 w-20 h-20 border-2 border-transparent border-b-[#D2B48C] border-l-[#D2B48C] rounded-full animate-spin opacity-40" style={{ animationDirection: 'reverse', animationDuration: '3s' }} aria-hidden="true"></div>
          
          <div className="relative w-24 h-24 bg-white rounded-full flex items-center justify-center shadow-lg border border-gray-100">
            <img 
              src="https://i.postimg.cc/xCFnNRvc/Changup-Lo-GO.webp" 
              alt="Change Up Cuts logo" 
              className="w-16 h-16 object-contain animate-pulse"
            />
          </div>
          
          <div className="absolute inset-0 w-24 h-24 bg-[#1A3C1F] rounded-full opacity-20 animate-ping" aria-hidden="true"></div>
        </div>

        {/* Brand Name */}
        <div className="mb-6">
          <h1 className="text-3xl font-display font-bold text-[#1A3C1F] mb-2 animate-fade-in">
            Change Up Cuts
          </h1>
          <p className="text-sm text-gray-500 font-medium tracking-wider uppercase">
            Barbershop & Beauty Center
          </p>
        </div>

        {/* Loading Animation Bars */}
        <div className="flex space-x-1 mb-6" aria-hidden="true">
          {[0, 1, 2, 3, 4].map((i) => (
            <div
              key={i}
              className="w-2 bg-[#1A3C1F] rounded-full animate-pulse"
              style={{
                height: '20px',
                animationDelay: `${i * 0.2}s`,
                animationDuration: '1s'
              }}
            />
          ))}
        </div>

        {/* Loading Text */}
        <div className="mb-4 h-6">
          <p className="text-gray-600 text-lg font-medium transition-all duration-500 ease-in-out">
            {loadingText}
          </p>
        </div>

        {/* Progress Bar (optional) */}
        {showProgress && (
          <div className="w-full max-w-xs">
            <div className="bg-gray-200 rounded-full h-2 overflow-hidden" role="progressbar" aria-valuenow={Math.round(Math.min(progress, 100))} aria-valuemin={0} aria-valuemax={100}>
              <div 
                className="bg-gradient-to-r from-[#1A3C1F] to-[#D2B48C] h-full rounded-full transition-all duration-300 ease-out"
                style={{ width: `${Math.min(progress, 100)}%` }}
              />
            </div>
            <p className="text-xs text-gray-500 mt-2 text-center">
              {Math.round(Math.min(progress, 100))}%
            </p>
          </div>
        )}

        <p className="text-gray-400 text-sm mt-6 tracking-wide font-light" lang="es">
          ¡HABLAMOS ESPAÑOL!
        </p>
      </div>

      <span className="sr-only">Loading Change Up Cuts website...</span>
    </div>
  );
};

// Simple loading spinner for smaller components
export const LoadingSpinner: React.FC<{ size?: 'sm' | 'md' | 'lg'; color?: string }> = ({ 
  size = 'md', 
  color = 'text-[#1A3C1F]' 
}) => {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-8 h-8',
    lg: 'w-12 h-12'
  };

  return (
    <div className="flex items-center justify-center p-4">
      <div className={`${sizeClasses[size]} border-2 border-transparent border-t-current border-r-current rounded-full animate-spin ${color}`} role="status" aria-label="Loading content" />
    </div>
  );
};