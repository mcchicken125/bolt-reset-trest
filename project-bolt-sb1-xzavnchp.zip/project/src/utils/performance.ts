// Performance monitoring utilities
export class PerformanceMonitor {
  private static instance: PerformanceMonitor;
  private metrics: Map<string, number> = new Map();

  static getInstance(): PerformanceMonitor {
    if (!PerformanceMonitor.instance) {
      PerformanceMonitor.instance = new PerformanceMonitor();
    }
    return PerformanceMonitor.instance;
  }

  // Measure Core Web Vitals
  measureCoreWebVitals() {
    try {
      // Largest Contentful Paint (LCP)
      if ('PerformanceObserver' in window) {
        new PerformanceObserver((entryList) => {
          const entries = entryList.getEntries();
          const lastEntry = entries[entries.length - 1];
          this.metrics.set('LCP', lastEntry.startTime);
          this.reportMetric('LCP', lastEntry.startTime);
        }).observe({ entryTypes: ['largest-contentful-paint'] });

        // First Input Delay (FID)
        new PerformanceObserver((entryList) => {
          const entries = entryList.getEntries();
          entries.forEach((entry: any) => {
            this.metrics.set('FID', entry.processingStart - entry.startTime);
            this.reportMetric('FID', entry.processingStart - entry.startTime);
          });
        }).observe({ entryTypes: ['first-input'] });

        // Cumulative Layout Shift (CLS)
        let clsValue = 0;
        new PerformanceObserver((entryList) => {
          const entries = entryList.getEntries();
          entries.forEach((entry: any) => {
            if (!entry.hadRecentInput) {
              clsValue += entry.value;
            }
          });
          this.metrics.set('CLS', clsValue);
          this.reportMetric('CLS', clsValue);
        }).observe({ entryTypes: ['layout-shift'] });
      }
    } catch (error) {
      // Silently handle performance monitoring errors
    }
  }

  // Measure custom metrics
  markStart(name: string) {
    try {
      performance.mark(`${name}-start`);
    } catch (error) {
      // Silently handle performance API errors
    }
  }

  markEnd(name: string) {
    try {
      performance.mark(`${name}-end`);
      performance.measure(name, `${name}-start`, `${name}-end`);
      
      const measure = performance.getEntriesByName(name)[0];
      this.metrics.set(name, measure.duration);
      this.reportMetric(name, measure.duration);
    } catch (error) {
      // Silently handle performance API errors
    }
  }

  // Report metrics (in production, send to analytics)
  private reportMetric(name: string, value: number) {
    if (typeof process !== 'undefined' && process.env && process.env.NODE_ENV === 'development') {
      // Only log in development
    }
    
    // In production, send to your analytics service
    // Example: Google Analytics, Mixpanel, etc.
  }

  // Get all collected metrics
  getMetrics() {
    return Object.fromEntries(this.metrics);
  }

  // Monitor resource loading
  monitorResourceLoading() {
    try {
      if ('PerformanceObserver' in window) {
        new PerformanceObserver((entryList) => {
          const entries = entryList.getEntries();
          entries.forEach((entry: any) => {
            if (entry.transferSize > 100000) { // Flag large resources
              // Only warn in development
              if (typeof process !== 'undefined' && process.env && process.env.NODE_ENV === 'development') {
                // Log warning in development only
              }
            }
          });
        }).observe({ entryTypes: ['resource'] });
      }
    } catch (error) {
      // Silently handle performance monitoring errors
    }
  }
}

// Image lazy loading utility
export const lazyLoadImages = () => {
  const images = document.querySelectorAll('img[data-src]');
  
  if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const img = entry.target as HTMLImageElement;
          img.src = img.dataset.src!;
          img.classList.remove('lazy');
          imageObserver.unobserve(img);
        }
      });
    });

    images.forEach(img => imageObserver.observe(img));
  }
};

// Preload critical resources
export const preloadCriticalResources = () => {
  const criticalImages = [
    'https://i.postimg.cc/xCFnNRvc/Changup-Lo-GO.webp',
    'https://i.postimg.cc/sgs5tj3z/Third.webp'
  ];

  criticalImages.forEach(src => {
    const link = document.createElement('link');
    link.rel = 'preload';
    link.as = 'image';
    link.href = src;
    document.head.appendChild(link);
  });
};

// Defer non-critical JavaScript
export const deferNonCriticalJS = () => {
  const scripts = document.querySelectorAll('script[data-defer]');
  
  // Load after main content is rendered
  if ('requestIdleCallback' in window) {
    (window as any).requestIdleCallback(() => {
      scripts.forEach(script => {
        const newScript = document.createElement('script');
        newScript.src = script.getAttribute('data-defer')!;
        newScript.async = true;
        document.head.appendChild(newScript);
      });
    });
  }
};

// Resource hints utility
export const addResourceHints = () => {
  const domains = [
    '//fonts.googleapis.com',
    '//fonts.gstatic.com',
    '//i.postimg.cc',
    '//getsquire.com'
  ];

  domains.forEach(domain => {
    const link = document.createElement('link');
    link.rel = 'dns-prefetch';
    link.href = domain;
    document.head.appendChild(link);
  });
};