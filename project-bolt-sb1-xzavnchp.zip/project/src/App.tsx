import React, { lazy, Suspense, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { AsSeenOn } from './components/AsSeenOn';
import { StoreInfo } from './components/StoreInfo';
import { CTASection } from './components/CTASection';
import { Footer } from './components/Footer';
import { MetaTags } from './components/MetaTags';
import { LoadingScreen, LoadingSpinner } from './components/LoadingScreen';
import { AppLoader } from './components/AppLoader';
import { PhoneWidget } from './components/PhoneWidget';
import { PerformanceMonitor } from './utils/performance';
import { SEOSafeguards } from './components/SEOSafeguards';
import { ErrorBoundary } from './components/ErrorBoundary';
import { NetworkErrorHandler } from './components/NetworkErrorHandler';
import { SupabaseConnectionMonitor } from './lib/enhancedSupabase';

// Lazy load page components
const AboutPage = lazy(() => import('./components/AboutPage').then(m => ({ default: m.AboutPage })));
const ServicesPage = lazy(() => import('./components/ServicesPage').then(m => ({ default: m.ServicesPage })));
const BeautyCenterPage = lazy(() => import('./components/BeautyCenterPage').then(m => ({ default: m.BeautyCenterPage })));
const ContactPage = lazy(() => import('./components/ContactPage').then(m => ({ default: m.ContactPage })));
const StyleGalleryPage = lazy(() => import('./components/StyleGalleryPage').then(m => ({ default: m.StyleGalleryPage })));
const PrivacyPolicy = lazy(() => import('./components/PrivacyPolicy').then(m => ({ default: m.PrivacyPolicy })));
const TermsOfService = lazy(() => import('./components/TermsOfService').then(m => ({ default: m.TermsOfService })));
const HtmlSitemap = lazy(() => import('./components/HtmlSitemap').then(m => ({ default: m.HtmlSitemap })));
const NotFoundPage = lazy(() => import('./components/NotFoundPage').then(m => ({ default: m.NotFoundPage })));

function App() {
  const [currentPage, setCurrentPage] = React.useState('home');

  // Initialize performance monitoring and connection monitoring
  useEffect(() => {
    const monitor = PerformanceMonitor.getInstance();
    monitor.measureCoreWebVitals();
    monitor.monitorResourceLoading();
    monitor.markStart('app-initialization');
    
    // Initialize Supabase connection monitoring
    const connectionMonitor = SupabaseConnectionMonitor.getInstance();
    connectionMonitor.startMonitoring();
    
    // Mark when app is fully loaded
    const handleLoad = () => {
      monitor.markEnd('app-initialization');
    };
    
    if (document.readyState === 'complete') {
      handleLoad();
    } else {
      window.addEventListener('load', handleLoad);
      return () => window.removeEventListener('load', handleLoad);
    }
  }, []);

  React.useEffect(() => {
    const handleHashChange = () => {
      const monitor = PerformanceMonitor.getInstance();
      monitor.markStart('page-navigation');
      
      const hash = window.location.hash.toLowerCase();
      switch (hash) {
        case '#about':
          setCurrentPage('about');
          break;
        case '#services':
          setCurrentPage('services');
          break;
        case '#careers':
          setCurrentPage('beauty');
          break;
        case '#contact':
          setCurrentPage('contact');
          break;
        case '#gallery':
          setCurrentPage('gallery');
          break;
        case '#privacy':
          setCurrentPage('privacy');
          break;
        case '#terms':
          setCurrentPage('terms');
          break;
        case '#sitemap':
          setCurrentPage('sitemap');
          break;
        case '#404':
          setCurrentPage('404');
          break;
        case '':
        case '#':
        case '#home':
          setCurrentPage('home');
          break;
        default:
          // For any unknown hash, show 404
          setCurrentPage('404');
      }
      
      // Scroll to top when page changes
      window.scrollTo(0, 0);
      
      // Announce page change to screen readers
      const announcement = document.getElementById('page-announcement');
      if (announcement) {
        const pageName = currentPage === 'home' ? 'home page' : currentPage === '404' ? 'page not found' : currentPage + ' page';
        announcement.textContent = `Navigated to ${pageName}`;
      }
      
      monitor.markEnd('page-navigation');
    };

    window.addEventListener('hashchange', handleHashChange);
    handleHashChange(); // Check initial hash

    return () => window.removeEventListener('hashchange', handleHashChange);
  }, [currentPage]);

  const renderPage = () => {
    // Enhanced loading fallback with branded experience
    const LoadingFallback = () => (
      <div className="min-h-screen bg-white flex items-center justify-center relative overflow-hidden">
        <div className="relative z-10 flex flex-col items-center text-center max-w-md mx-auto px-6">
          {/* Animated Logo */}
          <div className="mb-8 relative">
            <div className="absolute inset-0 w-20 h-20 border-4 border-transparent border-t-[#1A3C1F] border-r-[#1A3C1F] rounded-full animate-spin opacity-60"></div>
            <div className="relative w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-lg border border-gray-100">
              <img 
                src="https://i.postimg.cc/xCFnNRvc/Changup-Lo-GO.webp" 
                alt="Change Up Cuts Logo" 
                className="w-12 h-12 object-contain animate-pulse"
                loading="eager"
              />
            </div>
            <div className="absolute inset-0 w-20 h-20 bg-[#1A3C1F] rounded-full opacity-10 animate-ping"></div>
          </div>

          {/* Loading Text */}
          <div className="mb-6">
            <h2 className="text-2xl font-display font-bold text-[#1A3C1F] mb-2">
              Loading...
            </h2>
            <p className="text-gray-500 text-sm">
              Preparing your barbershop experience
            </p>
          </div>

          {/* Loading Animation */}
          <div className="flex space-x-1">
            {[0, 1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className="w-2 bg-[#1A3C1F] rounded-full animate-pulse"
                style={{
                  height: '16px',
                  animationDelay: `${i * 0.2}s`,
                  animationDuration: '1s'
                }}
              />
            ))}
          </div>
        </div>
      </div>
    );

    switch (currentPage) {
      case 'about':
        return (
          <ErrorBoundary>
            <Suspense fallback={<LoadingFallback />}>
              <AboutPage />
            </Suspense>
          </ErrorBoundary>
        );
      case 'services':
        return (
          <ErrorBoundary>
            <Suspense fallback={<LoadingFallback />}>
              <ServicesPage />
            </Suspense>
          </ErrorBoundary>
        );
      case 'beauty':
        return (
          <ErrorBoundary>
            <Suspense fallback={<LoadingFallback />}>
              <BeautyCenterPage />
            </Suspense>
          </ErrorBoundary>
        );
      case 'contact':
        return (
          <ErrorBoundary>
            <Suspense fallback={<LoadingFallback />}>
              <ContactPage />
            </Suspense>
          </ErrorBoundary>
        );
      case 'gallery':
        return (
          <ErrorBoundary>
            <Suspense fallback={<LoadingFallback />}>
              <StyleGalleryPage />
            </Suspense>
          </ErrorBoundary>
        );
      case 'privacy':
        return (
          <ErrorBoundary>
            <Suspense fallback={<LoadingFallback />}>
              <PrivacyPolicy />
            </Suspense>
          </ErrorBoundary>
        );
      case 'terms':
        return (
          <ErrorBoundary>
            <Suspense fallback={<LoadingFallback />}>
              <TermsOfService />
            </Suspense>
          </ErrorBoundary>
        );
      case 'sitemap':
        return (
          <ErrorBoundary>
            <Suspense fallback={<LoadingFallback />}>
              <HtmlSitemap />
            </Suspense>
          </ErrorBoundary>
        );
      case '404':
        return (
          <ErrorBoundary>
            <Suspense fallback={<LoadingFallback />}>
              <NotFoundPage />
            </Suspense>
          </ErrorBoundary>
        );
      default:
        return (
          <ErrorBoundary>
            <MetaTags
              title="Premier Multicultural Barbershop & Beauty Center"
              description="Change Up Cuts is a full service barbershop, hair salon and nail salon in a fun, family-friendly, multicultural environment. We are a one stop shop for the entire family with experienced stylists and barbers."
              type="business.business"
            />
            <Hero />
            <AsSeenOn />
            <About />
            <StoreInfo />
            <CTASection />
          </ErrorBoundary>
        );
    }
  };

  return (
    <ErrorBoundary
      onError={(error, errorInfo) => {
        // Log to error tracking service in production
        console.error('Global error caught:', error, errorInfo);
      }}
    >
      <NetworkErrorHandler>
        <AppLoader>
          <div className="font-primary text-gray-900 bg-white" lang="en">
            {/* SEO Preservation Safeguards - Critical for ranking protection */}
            <SEOSafeguards />
            
            {/* Skip Navigation Link for Screen Readers */}
            <a 
              href="#main-content" 
              className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 bg-[#1A3C1F] text-white px-4 py-2 rounded z-50"
              aria-label="Skip to main content"
            >
              Skip to main content
            </a>
            
            {/* Screen reader announcements */}
            <div 
              id="page-announcement" 
              className="sr-only" 
              aria-live="polite" 
              aria-atomic="true"
            ></div>
            
            <ErrorBoundary>
              <Navbar />
            </ErrorBoundary>
            
            <main id="main-content" role="main">
              {renderPage()}
            </main>
            
            <ErrorBoundary>
              <Footer />
            </ErrorBoundary>
            
            {/* Floating Phone Widget - Always visible */}
            <ErrorBoundary>
              <PhoneWidget />
            </ErrorBoundary>
          </div>
        </AppLoader>
      </NetworkErrorHandler>
    </ErrorBoundary>
  );
}

export default App;