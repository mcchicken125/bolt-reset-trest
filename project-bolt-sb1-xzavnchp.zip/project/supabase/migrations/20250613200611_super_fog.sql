/*
  # Job Applications Table Migration

  1. New Tables
    - `job_applications`
      - `id` (uuid, primary key)
      - `first_name` (text, required)
      - `last_name` (text, required)
      - `email` (text, required)
      - `phone` (text, optional)
      - `position` (text, required)
      - `experience_level` (text, required)
      - `availability` (text, optional)
      - `resume_url` (text, optional)
      - `message` (text, optional)
      - `status` (enum: new, reviewed, interviewed, hired, rejected)
      - `ip_address` (text, for tracking)
      - `user_agent` (text, for analytics)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `job_applications` table
    - Add policy for public to insert applications
    - Add policy for authenticated users (admins) to read/update applications

  3. Indexes
    - Email index for faster lookups
    - Status index for filtering
    - Created date index for sorting
*/

-- Create enum for application status
CREATE TYPE application_status AS ENUM ('new', 'reviewed', 'interviewed', 'hired', 'rejected');

-- Create job_applications table
CREATE TABLE IF NOT EXISTS job_applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  first_name text NOT NULL,
  last_name text NOT NULL,
  email text NOT NULL,
  phone text,
  position text NOT NULL,
  experience_level text NOT NULL,
  availability text,
  resume_url text,
  message text,
  status application_status DEFAULT 'new',
  ip_address text,
  user_agent text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE job_applications ENABLE ROW LEVEL SECURITY;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_job_applications_email ON job_applications(email);
CREATE INDEX IF NOT EXISTS idx_job_applications_status ON job_applications(status);
CREATE INDEX IF NOT EXISTS idx_job_applications_created_at ON job_applications(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_job_applications_position ON job_applications(position);

-- Policy: Allow public to insert new applications
CREATE POLICY "Anyone can submit job applications"
  ON job_applications
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- Policy: Allow authenticated users (admins) to read all applications
CREATE POLICY "Admins can read all job applications"
  ON job_applications
  FOR SELECT
  TO authenticated
  USING (true);

-- Policy: Allow authenticated users (admins) to update application status
CREATE POLICY "Admins can update job application status"
  ON job_applications
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Trigger to automatically update updated_at
CREATE TRIGGER update_job_applications_updated_at
    BEFORE UPDATE ON job_applications
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();